# Reglas de R8 / ProGuard para Punto de Venta QR
# Ofuscación agresiva del módulo de validación criptográfica de licencias y seguridad
-repackageclasses 'o.a'
-allowaccessmodification
-overloadaggressively

# Mantener entidades de Room y constructores
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers class * {
    @androidx.room.* <methods>;
}

# ML Kit Barcode Scanning (Bundled)
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.libraries.barhopper.** { *; }

# Apache POI & PDFBox
-dontwarn org.apache.poi.**
-dontwarn java.awt.**
-dontwarn javax.imageio.**
-dontwarn org.bouncycastle.**
-keep class org.apache.poi.** { *; }
-keep class com.tom_roush.** { *; }
