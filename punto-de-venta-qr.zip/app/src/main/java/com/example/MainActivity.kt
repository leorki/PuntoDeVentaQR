package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.security.EstadoVinculacionDispositivo
import com.example.ui.screens.ActivationScreen
import com.example.ui.screens.ActiveSaleScreen
import com.example.ui.screens.AdminBackupAndSettingsScreen
import com.example.ui.screens.AdminCatalogScreen
import com.example.ui.screens.AdminDailySummaryScreen
import com.example.ui.screens.AdminHistoryByDateScreen
import com.example.ui.screens.AdminLoginAndRecoveryDialog
import com.example.ui.screens.AdminQrGeneratorScreen
import com.example.ui.screens.CheckoutModalScreen
import com.example.ui.screens.DayStartScreen
import com.example.ui.screens.InitialSetupScreen
import com.example.ui.screens.MasterRecoveryCodeOneTimeDialog
import com.example.ui.screens.RecoverInterruptedSaleDialog
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.PosViewModel
import com.example.viewmodel.SeccionAdmin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PuntoDeVentaQrApp()
            }
        }
    }
}

@Composable
fun PuntoDeVentaQrApp(
    posViewModel: PosViewModel = viewModel()
) {
    val cargandoInicial by posViewModel.cargandoInicial.collectAsStateWithLifecycle()
    val estadoLicencia by posViewModel.estadoLicencia.collectAsStateWithLifecycle()
    val config by posViewModel.configuracionNegocio.collectAsStateWithLifecycle()
    val jornada by posViewModel.jornadaActiva.collectAsStateWithLifecycle()
    val catalogo by posViewModel.catalogoProductos.collectAsStateWithLifecycle()
    val historicoPrecios by posViewModel.historicoPrecios.collectAsStateWithLifecycle()
    val registroCambios by posViewModel.registroCambios.collectAsStateWithLifecycle()
    val carrito by posViewModel.carritoEnCurso.collectAsStateWithLifecycle()
    val historialDiario by posViewModel.historialDiario.collectAsStateWithLifecycle()
    val ventasDeHoy by posViewModel.ventasDeHoy.collectAsStateWithLifecycle()

    val fechaMostrar by posViewModel.fechaActualMostrar.collectAsStateWithLifecycle()
    val fechaIso by posViewModel.fechaActualIso.collectAsStateWithLifecycle()
    val horaExacta by posViewModel.horaActualExacta.collectAsStateWithLifecycle()

    val usarCamaraFrontal by posViewModel.usarCamaraFrontal.collectAsStateWithLifecycle()
    val escanerExpandido by posViewModel.escanerExpandido.collectAsStateWithLifecycle()
    val alertaEscaner by posViewModel.alertaEscaner.collectAsStateWithLifecycle()

    val mostrarPantallaCobrar by posViewModel.mostrarPantallaCobrar.collectAsStateWithLifecycle()
    val metodoPagoSeleccionado by posViewModel.metodoPagoSeleccionado.collectAsStateWithLifecycle()
    val horaResumenCobro by posViewModel.horaResumenCobro.collectAsStateWithLifecycle()

    val esModoAdmin by posViewModel.esModoAdmin.collectAsStateWithLifecycle()
    val seccionAdminActual by posViewModel.seccionAdminActual.collectAsStateWithLifecycle()
    val segundosRestantesAdmin by posViewModel.segundosRestantesSesionAdmin.collectAsStateWithLifecycle()

    val codigoMaestroUnaVez by posViewModel.codigoMaestroMostrarUnaVez.collectAsStateWithLifecycle()
    val mostrarPreguntaRecuperarVenta by posViewModel.mostrarPreguntaRecuperarVenta.collectAsStateWithLifecycle()
    val mensajeBanner by posViewModel.mensajeBanner.collectAsStateWithLifecycle()
    val ultimoArchivoGenerado by posViewModel.ultimoArchivoGenerado.collectAsStateWithLifecycle()

    var mostrarLoginAdminDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(mensajeBanner) {
        val msg = mensajeBanner
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            posViewModel.limpiarMensajeBanner()
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (cargandoInicial) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                return@Box
            }

            // 1. Verificar firma digital del APK y estado de activación por código único
            when (val licencia = estadoLicencia) {
                is EstadoVinculacionDispositivo.BloqueadoPorFirmaApkModificada -> {
                    FatalSecurityBlockScreen(mensaje = licencia.mensaje)
                }
                is EstadoVinculacionDispositivo.NoActivado -> {
                    ActivationScreen(
                        mensajeBloqueo = null,
                        onActivarCodigo = { posViewModel.activarAplicacionConCodigo(it) }
                    )
                }
                is EstadoVinculacionDispositivo.BloqueadoPorCopiaOClonacion -> {
                    ActivationScreen(
                        mensajeBloqueo = licencia.mensaje,
                        onActivarCodigo = { posViewModel.activarAplicacionConCodigo(it) }
                    )
                }
                is EstadoVinculacionDispositivo.BloqueadoPorVencimiento -> {
                    ActivationScreen(
                        mensajeBloqueo = licencia.mensaje,
                        onActivarCodigo = { posViewModel.activarAplicacionConCodigo(it) }
                    )
                }
                is EstadoVinculacionDispositivo.ActivadoValido -> {
                    // 2. Si es el primer día (no hay configuración guardada), mostrar Asistente Inicial
                    val configActual = config
                    if (configActual == null || !configActual.configuracionCompletada) {
                        InitialSetupScreen(
                            onProcesarLogo = { uri, cb -> posViewModel.procesarLogoSeleccionado(uri, cb) },
                            onGuardarConfiguracionInicial = {
                                nombreNegocio,
                                nombreDueno,
                                direccion,
                                telefono,
                                correo,
                                monedaCodigo,
                                monedaSimbolo,
                                simboloAntes,
                                separadorMiles,
                                separadorDecimales,
                                monedaVozSingular,
                                monedaVozPlural,
                                centavosVoz,
                                aplicaImpuesto,
                                porcentajeImpuesto,
                                rutaLogoInterno,
                                passwordAdmin,
                                preguntaSeguridad,
                                respuestaSeguridad,
                                idiomaVozPais,
                                almacenamientoPreferido ->
                                posViewModel.guardarConfiguracionInicialPrimerDia(
                                    nombreNegocio,
                                    nombreDueno,
                                    direccion,
                                    telefono,
                                    correo,
                                    monedaCodigo,
                                    monedaSimbolo,
                                    simboloAntes,
                                    separadorMiles,
                                    separadorDecimales,
                                    monedaVozSingular,
                                    monedaVozPlural,
                                    centavosVoz,
                                    aplicaImpuesto,
                                    porcentajeImpuesto,
                                    rutaLogoInterno,
                                    passwordAdmin,
                                    preguntaSeguridad,
                                    respuestaSeguridad,
                                    idiomaVozPais,
                                    almacenamientoPreferido
                                )
                            }
                        )
                    } else if (esModoAdmin) {
                        // 3. MODO ADMINISTRADOR (Dueño - acceso total con bloqueo a los 5 minutos de inactividad)
                        BackHandler {
                            posViewModel.cerrarSesionAdmin()
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    awaitPointerEventScope {
                                        while (true) {
                                            awaitPointerEvent()
                                            posViewModel.registrarActividadAdmin()
                                        }
                                    }
                                }
                        ) {
                            // Barra superior de sesión de Administrador con contador de inactividad (5 min)
                            Surface(
                                color = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "PANEL DE ADMINISTRACIÓN (DUEÑO)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        val mins = segundosRestantesAdmin / 60
                                        val segs = segundosRestantesAdmin % 60
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Timer,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "Auto-bloqueo por inactividad en %02d:%02d".format(mins, segs),
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }

                                    FilledTonalButton(
                                        onClick = { posViewModel.cerrarSesionAdmin() },
                                        modifier = Modifier.testTag("salir_admin_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Modo Vendedor")
                                    }
                                }
                            }

                            // Contenido de la sección activa de administración
                            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                when (seccionAdminActual) {
                                    SeccionAdmin.CATALOGO -> {
                                        AdminCatalogScreen(
                                            config = configActual,
                                            productos = catalogo,
                                            historicoPrecios = historicoPrecios,
                                            registroCambios = registroCambios,
                                            fechaHoyIso = fechaIso,
                                            onActividadAdmin = { posViewModel.registrarActividadAdmin() },
                                            onGuardarProducto = { esNuevo, codOrig, codNuevo, nom, gram, vol, precio, cb ->
                                                posViewModel.guardarProductoCatalogo(
                                                    esNuevo, codOrig, codNuevo, nom, gram, vol, precio, cb
                                                )
                                            },
                                            onEliminarProducto = { posViewModel.eliminarProductoDelCatalogo(it) },
                                            onImportarArchivoUri = { posViewModel.importarCatalogoDesdeArchivo(it) },
                                            onExportarCatalogoExcel = { posViewModel.exportarCatalogoAExcel() }
                                        )
                                    }
                                    SeccionAdmin.ETIQUETAS_QR -> {
                                        AdminQrGeneratorScreen(
                                            productos = catalogo,
                                            onActividadAdmin = { posViewModel.registrarActividadAdmin() },
                                            onExportarOImprimirQr = { prods, imprimir ->
                                                posViewModel.exportarPdfEtiquetasQr(prods, imprimir)
                                            }
                                        )
                                    }
                                    SeccionAdmin.RESUMEN_DIA -> {
                                        AdminDailySummaryScreen(
                                            config = configActual,
                                            jornada = jornada,
                                            ventasHoy = ventasDeHoy,
                                            historialDiario = historialDiario,
                                            fechaHoyIso = fechaIso,
                                            fechaHoyMostrar = fechaMostrar,
                                            onActividadAdmin = { posViewModel.registrarActividadAdmin() },
                                            onGenerarYSellarResumenDelDia = { efectivo, obs, cb ->
                                                posViewModel.generarYSellarResumenDelDia(efectivo, obs, cb)
                                            }
                                        )
                                    }
                                    SeccionAdmin.HISTORIAL_FECHA -> {
                                        AdminHistoryByDateScreen(
                                            config = configActual,
                                            historialDiario = historialDiario,
                                            fechaHoyIso = fechaIso,
                                            onActividadAdmin = { posViewModel.registrarActividadAdmin() },
                                            onConsultarFecha = { f, cb ->
                                                posViewModel.consultarHistorialPorFecha(f, cb)
                                            },
                                            onExportarOImprimirPdfFecha = { f, imp ->
                                                posViewModel.exportarOImprimirPdfDeFechaHistorica(f, imp)
                                            }
                                        )
                                    }
                                    SeccionAdmin.RESPALDO_Y_CONFIG -> {
                                        AdminBackupAndSettingsScreen(
                                            config = configActual,
                                            ultimoArchivoGenerado = ultimoArchivoGenerado,
                                            onActividadAdmin = { posViewModel.registrarActividadAdmin() },
                                            onExportarTodoZip = { posViewModel.ejecutarExportarTodoRespaldoCompleto() },
                                            onExportarVentasExcel = { posViewModel.exportarVentasAExcel() },
                                            onActualizarConfiguracion = { posViewModel.actualizarConfiguracionAdmin(it) },
                                            onProbarVoz = { posViewModel.probarVozEnConfiguracion() },
                                            onCambiarPassword = { act, nueva, cb ->
                                                posViewModel.cambiarPasswordAdminDesdePanel(act, nueva, cb)
                                            }
                                        )
                                    }
                                }
                            }

                            // Barra de navegación inferior del Administrador
                            NavigationBar(
                                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                            ) {
                                NavigationBarItem(
                                    selected = seccionAdminActual == SeccionAdmin.CATALOGO,
                                    onClick = { posViewModel.cambiarSeccionAdmin(SeccionAdmin.CATALOGO) },
                                    icon = { Icon(Icons.Default.Inventory, contentDescription = "Catálogo") },
                                    label = { Text("Catálogo") },
                                    modifier = Modifier.testTag("nav_admin_catalogo")
                                )
                                NavigationBarItem(
                                    selected = seccionAdminActual == SeccionAdmin.ETIQUETAS_QR,
                                    onClick = { posViewModel.cambiarSeccionAdmin(SeccionAdmin.ETIQUETAS_QR) },
                                    icon = { Icon(Icons.Default.QrCode2, contentDescription = "Etiquetas QR") },
                                    label = { Text("QR") },
                                    modifier = Modifier.testTag("nav_admin_qr")
                                )
                                NavigationBarItem(
                                    selected = seccionAdminActual == SeccionAdmin.RESUMEN_DIA,
                                    onClick = { posViewModel.cambiarSeccionAdmin(SeccionAdmin.RESUMEN_DIA) },
                                    icon = { Icon(Icons.Default.PictureAsPdf, contentDescription = "Resumen del día") },
                                    label = { Text("Resumen Día") },
                                    modifier = Modifier.testTag("nav_admin_resumen_dia")
                                )
                                NavigationBarItem(
                                    selected = seccionAdminActual == SeccionAdmin.HISTORIAL_FECHA,
                                    onClick = { posViewModel.cambiarSeccionAdmin(SeccionAdmin.HISTORIAL_FECHA) },
                                    icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "Historial") },
                                    label = { Text("Historial") },
                                    modifier = Modifier.testTag("nav_admin_historial")
                                )
                                NavigationBarItem(
                                    selected = seccionAdminActual == SeccionAdmin.RESPALDO_Y_CONFIG,
                                    onClick = { posViewModel.cambiarSeccionAdmin(SeccionAdmin.RESPALDO_Y_CONFIG) },
                                    icon = { Icon(Icons.Default.SettingsBackupRestore, contentDescription = "Respaldo y Config") },
                                    label = { Text("Respaldo") },
                                    modifier = Modifier.testTag("nav_admin_respaldo")
                                )
                            }
                        }
                    } else {
                        // 4. Si aún no se ha abierto la jornada de hoy, pedir nombre del vendedor del día
                        val jornadaHoyAbierta = jornada != null &&
                            jornada!!.jornadaAbierta &&
                            jornada!!.fechaIso == fechaIso

                        if (!jornadaHoyAbierta) {
                            DayStartScreen(
                                config = configActual,
                                fechaCompletaActual = fechaMostrar,
                                horaActual = horaExacta,
                                onIniciarDia = { posViewModel.iniciarJornadaDelDia(it) },
                                onAbrirAccesoAdmin = { mostrarLoginAdminDialog = true }
                            )
                        } else if (mostrarPantallaCobrar) {
                            // 5. Pantalla grande de RESUMEN DE COMPRA al tocar "Cobrar"
                            val sub = posViewModel.calcularSubtotalCarrito(carrito)
                            val imp = posViewModel.calcularImpuestoCarrito(sub, configActual)
                            val tot = posViewModel.calcularTotalAPagar(carrito, configActual)
                            CheckoutModalScreen(
                                config = configActual,
                                fechaCompleta = fechaMostrar,
                                horaCobro = horaResumenCobro.ifBlank { horaExacta },
                                nombreVendedor = jornada?.nombreVendedor ?: "Vendedor",
                                carrito = carrito,
                                subtotal = sub,
                                impuesto = imp,
                                totalAPagar = tot,
                                metodoPagoSeleccionado = metodoPagoSeleccionado,
                                onSeleccionarMetodoPago = { posViewModel.seleccionarMetodoPago(it) },
                                onRepetirTotalPorVoz = { posViewModel.repetirTotalPorVoz() },
                                onCerrarVentaDefinitiva = { posViewModel.cerrarVentaActual() },
                                onVolverAVentaEnCurso = { posViewModel.volverDeCobrarAVentaEnCurso() }
                            )
                        } else {
                            // 6. Pantalla principal del Vendedor: VENTA EN CURSO
                            val sub = posViewModel.calcularSubtotalCarrito(carrito)
                            val imp = posViewModel.calcularImpuestoCarrito(sub, configActual)
                            val tot = posViewModel.calcularTotalAPagar(carrito, configActual)
                            ActiveSaleScreen(
                                config = configActual,
                                fechaCompleta = fechaMostrar,
                                horaExacta = horaExacta,
                                nombreVendedor = jornada?.nombreVendedor ?: "Vendedor",
                                carrito = carrito,
                                catalogo = catalogo,
                                ventasDeHoy = ventasDeHoy,
                                usarCamaraFrontal = usarCamaraFrontal,
                                escanerExpandido = escanerExpandido,
                                alertaEscaner = alertaEscaner,
                                subtotalCarrito = sub,
                                impuestoCarrito = imp,
                                totalCarrito = tot,
                                onCambiarCamara = { posViewModel.alternarCamaraFrontalTrasera() },
                                onConmutarCamaraPorFallo = { frontal, msg ->
                                    posViewModel.conmutarCamaraAutomaticaPorFallo(frontal, msg)
                                },
                                onAlternarVisibilidadEscaner = { posViewModel.alternarVisibilidadEscaner() },
                                onCodigoQrEscaneado = { posViewModel.procesarCodigoQrEscaneado(it) },
                                onTimeoutEscaner3Segundos = { posViewModel.reportarTimeoutEscaner3Segundos() },
                                onQrDanado = { posViewModel.reportarQrDanadoIlegible() },
                                onAvisarAdminCodigoNoRegistrado = {
                                    posViewModel.avisarAdminProductoNoRegistrado(it)
                                },
                                onLimpiarAlertaEscaner = { posViewModel.limpiarAlertaEscaner() },
                                onAgregarProductoManual = { prod, cant ->
                                    posViewModel.agregarProductoManualAVenta(prod, cant)
                                },
                                onModificarCantidad = { cod, cant ->
                                    posViewModel.modificarCantidadProductoEnVenta(cod, cant)
                                },
                                onEliminarProducto = { posViewModel.eliminarProductoDeVenta(it) },
                                onCancelarVenta = { posViewModel.cancelarVentaEnCurso() },
                                onCobrar = { posViewModel.tocarBotonCobrar() },
                                onCerrarVenta = { posViewModel.cerrarVentaActual() },
                                onRepetirTotal = { posViewModel.repetirTotalPorVoz() },
                                onAbrirLoginAdmin = { mostrarLoginAdminDialog = true }
                            )
                        }
                    }

                    // Modal de código maestro mostrado una sola vez tras configurar el primer día
                    if (codigoMaestroUnaVez != null) {
                        MasterRecoveryCodeOneTimeDialog(
                            codigoMaestro = codigoMaestroUnaVez!!,
                            onConfirmarAnotado = { posViewModel.confirmarCodigoMaestroVisto() }
                        )
                    }

                    // Modal de recuperación de venta tras cierre inesperado ("¿Recuperar venta anterior?")
                    if (mostrarPreguntaRecuperarVenta && carrito.isNotEmpty() && configActual != null) {
                        RecoverInterruptedSaleDialog(
                            carritoPendiente = carrito,
                            config = configActual,
                            onResponder = { posViewModel.responderRecuperacionVenta(it) }
                        )
                    }

                    // Modal de inicio de sesión o recuperación de contraseña de Administrador
                    if (mostrarLoginAdminDialog && configActual != null) {
                        AdminLoginAndRecoveryDialog(
                            config = configActual,
                            onDismiss = { mostrarLoginAdminDialog = false },
                            onIntentarLogin = { posViewModel.iniciarSesionAdmin(it) },
                            onRecuperarConPregunta = { resp, nueva ->
                                posViewModel.recuperarPasswordConPreguntaSeguridad(resp, nueva)
                            },
                            onRecuperarConCodigoMaestro = { cod, nueva ->
                                posViewModel.recuperarPasswordConCodigoMaestro(cod, nueva)
                            },
                            onLoginExitoso = { mostrarLoginAdminDialog = false }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FatalSecurityBlockScreen(mensaje: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.errorContainer)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Error,
                    contentDescription = "Firma APK Modificada",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "EJECUCIÓN BLOQUEADA POR SEGURIDAD",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = mensaje,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
