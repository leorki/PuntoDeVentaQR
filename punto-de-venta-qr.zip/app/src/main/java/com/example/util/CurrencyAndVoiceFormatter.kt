package com.example.util

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import com.example.data.local.ConfiguracionNegocioEntity
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale
import kotlin.math.abs

data class MonedaPreset(
    val codigo: String,
    val nombreMostrar: String,
    val simbolo: String,
    val simboloAntes: Boolean,
    val separadorMiles: String,
    val separadorDecimales: String,
    val vozSingular: String,
    val vozPlural: String,
    val centavosVoz: String,
    val ejemplo: String
)

data class IdiomaVozPais(
    val codigoBcp47: String,
    val etiquetaPais: String
)

object CurrencyAndVoiceFormatter {

    /**
     * Lista exacta de las 6 monedas solicitadas:
     * 1. Peso Cubano (CUP): símbolo $, formato $1,234.56
     * 2. Dólar Americano (USD): símbolo $, formato $1,234.56
     * 3. Dólar Canadiense (CAD): símbolo C$, formato C$1,234.56
     * 4. Peso Mexicano (MXN): símbolo $, formato $1,234.56
     * 5. Euro (EUR): símbolo €, formato 1.234,56 €
     * 6. Libra Esterlina (GBP): símbolo £, formato £1,234.56
     */
    val MONEDAS_PREDEFINIDAS = listOf(
        MonedaPreset(
            codigo = "CUP",
            nombreMostrar = "Peso Cubano (CUP)",
            simbolo = "$",
            simboloAntes = true,
            separadorMiles = ",",
            separadorDecimales = ".",
            vozSingular = "peso cubano",
            vozPlural = "pesos cubanos",
            centavosVoz = "centavos",
            ejemplo = "$1,234.56"
        ),
        MonedaPreset(
            codigo = "USD",
            nombreMostrar = "Dólar Americano (USD)",
            simbolo = "$",
            simboloAntes = true,
            separadorMiles = ",",
            separadorDecimales = ".",
            vozSingular = "dólar",
            vozPlural = "dólares",
            centavosVoz = "centavos",
            ejemplo = "$1,234.56"
        ),
        MonedaPreset(
            codigo = "CAD",
            nombreMostrar = "Dólar Canadiense (CAD)",
            simbolo = "C$",
            simboloAntes = true,
            separadorMiles = ",",
            separadorDecimales = ".",
            vozSingular = "dólar canadiense",
            vozPlural = "dólares canadienses",
            centavosVoz = "centavos",
            ejemplo = "C$1,234.56"
        ),
        MonedaPreset(
            codigo = "MXN",
            nombreMostrar = "Peso Mexicano (MXN)",
            simbolo = "$",
            simboloAntes = true,
            separadorMiles = ",",
            separadorDecimales = ".",
            vozSingular = "peso mexicano",
            vozPlural = "pesos mexicanos",
            centavosVoz = "centavos",
            ejemplo = "$1,234.56"
        ),
        MonedaPreset(
            codigo = "EUR",
            nombreMostrar = "Euro (EUR)",
            simbolo = "€",
            simboloAntes = false,
            separadorMiles = ".",
            separadorDecimales = ",",
            vozSingular = "euro",
            vozPlural = "euros",
            centavosVoz = "centavos",
            ejemplo = "1.234,56 €"
        ),
        MonedaPreset(
            codigo = "GBP",
            nombreMostrar = "Libra Esterlina (GBP)",
            simbolo = "£",
            simboloAntes = true,
            separadorMiles = ",",
            separadorDecimales = ".",
            vozSingular = "libra esterlina",
            vozPlural = "libras esterlinas",
            centavosVoz = "centavos",
            ejemplo = "£1,234.56"
        )
    )

    val IDIOMAS_VOZ_ESPANOL = listOf(
        IdiomaVozPais("es-ES", "Español (España)"),
        IdiomaVozPais("es-MX", "Español (México / Latinoamérica)"),
        IdiomaVozPais("es-US", "Español (Estados Unidos / Caribe)"),
        IdiomaVozPais("es-CO", "Español (Colombia)"),
        IdiomaVozPais("es-AR", "Español (Argentina)"),
        IdiomaVozPais("es-PE", "Español (Perú)"),
        IdiomaVozPais("es-CL", "Español (Chile)")
    )

    /**
     * Formatea cualquier monto a 2 decimales exactos respetando el símbolo,
     * posición y separadores de miles/decimales configurados.
     * Ejemplos:
     * - CUP / USD / MXN: $1,234.56
     * - CAD: C$1,234.56
     * - EUR: 1.234,56 €
     * - GBP: £1,234.56
     */
    fun formatearMoneda(monto: Double, config: ConfiguracionNegocioEntity?): String {
        val simbolo = config?.monedaSimbolo ?: "$"
        val antes = config?.simboloAntes ?: true
        val sepMiles = config?.separadorMiles ?: ","
        val sepDec = config?.separadorDecimales ?: "."

        val negativo = monto < -0.0001
        val valorAbs = BigDecimal.valueOf(abs(monto)).setScale(2, RoundingMode.HALF_UP)
        val partes = valorAbs.toPlainString().split(".")
        val parteEnteraRaw = partes[0]
        val parteDecimal = partes.getOrElse(1) { "00" }.padEnd(2, '0').take(2)

        val parteEnteraConMiles = buildString {
            var contador = 0
            for (i in parteEnteraRaw.length - 1 downTo 0) {
                if (contador > 0 && contador % 3 == 0) {
                    append(sepMiles)
                }
                append(parteEnteraRaw[i])
                contador++
            }
        }.reversed()

        val numeroFormateado = "$parteEnteraConMiles$sepDec$parteDecimal"
        val conSimbolo = if (antes) {
            if (simbolo.endsWith(".") || simbolo.endsWith("/")) "$simbolo $numeroFormateado" else "$simbolo$numeroFormateado"
        } else {
            "$numeroFormateado $simbolo"
        }
        return if (negativo) "-$conSimbolo" else conSimbolo
    }

    /**
     * Construye la frase exacta en español para decir por voz al cobrar:
     * Ejemplo: "Total a pagar: trece dólares con sesenta centavos"
     */
    fun construirFraseTotalPorVoz(monto: Double, config: ConfiguracionNegocioEntity?): String {
        val valorRedondeado = BigDecimal.valueOf(abs(monto)).setScale(2, RoundingMode.HALF_UP)
        val enteros = valorRedondeado.toLong()
        val centavos = valorRedondeado.remainder(BigDecimal.ONE).movePointRight(2).toInt()

        val monedaSingular = config?.monedaVozSingular ?: "dólar"
        val monedaPlural = config?.monedaVozPlural ?: "dólares"
        val centavosNombre = config?.centavosVoz ?: "centavos"

        val textoEnteros = numeroEnteroALetras(enteros)
        val nombreMoneda = if (enteros == 1L) monedaSingular else monedaPlural

        return if (centavos > 0) {
            val textoCentavos = numeroEnteroALetras(centavos.toLong())
            "Total a pagar: $textoEnteros $nombreMoneda con $textoCentavos $centavosNombre"
        } else {
            "Total a pagar: $textoEnteros $nombreMoneda exactos"
        }
    }

    /**
     * Convierte números enteros (0 a 999,999,999) a palabras en español.
     */
    fun numeroEnteroALetras(numero: Long): String {
        if (numero == 0L) return "cero"
        if (numero < 0L) return "menos ${numeroEnteroALetras(-numero)}"

        val unidades = arrayOf(
            "", "un", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve",
            "diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve",
            "veinte", "veintiuno", "veintidós", "veintitrés", "veinticuatro", "veinticinco", "veintiséis", "veintisiete", "veintiocho", "veintinueve"
        )
        val decenas = arrayOf(
            "", "diez", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa"
        )
        val centenas = arrayOf(
            "", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos"
        )

        fun convertirMenorDeMil(n: Int): String {
            if (n == 0) return ""
            if (n == 100) return "cien"
            val c = n / 100
            val resto = n % 100
            val textoC = centenas[c]
            val textoResto = when {
                resto == 0 -> ""
                resto == 1 -> "uno"
                resto == 21 -> "veintiuno"
                resto < 30 -> unidades[resto]
                else -> {
                    val d = resto / 10
                    val u = resto % 10
                    if (u == 0) decenas[d]
                    else if (u == 1) "${decenas[d]} y uno"
                    else "${decenas[d]} y ${unidades[u]}"
                }
            }
            return listOf(textoC, textoResto).filter { it.isNotEmpty() }.joinToString(" ")
        }

        val millones = (numero / 1_000_000L).toInt()
        val miles = ((numero % 1_000_000L) / 1_000L).toInt()
        val resto = (numero % 1_000L).toInt()

        val partes = mutableListOf<String>()
        if (millones > 0) {
            if (millones == 1) partes.add("un millón")
            else partes.add("${convertirMenorDeMil(millones).replace("uno$", "un")} millones")
        }
        if (miles > 0) {
            if (miles == 1) partes.add("mil")
            else partes.add("${convertirMenorDeMil(miles).replace(Regex("uno$"), "un")} mil")
        }
        if (resto > 0) {
            partes.add(convertirMenorDeMil(resto))
        }
        return partes.joinToString(" ")
    }
}

/**
 * Controlador de síntesis de voz offline nativa de Android (TextToSpeech).
 */
class OfflineVoiceSpeaker(context: Context) {

    private var tts: TextToSpeech? = null
    private var listo = false
    private var codigoIdiomaActual = "es-MX"

    init {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    listo = true
                    aplicarIdioma(codigoIdiomaActual)
                }
            }
        } catch (_: Exception) {
            listo = false
        }
    }

    fun aplicarIdioma(codigoBcp47: String) {
        codigoIdiomaActual = codigoBcp47
        val motor = tts ?: return
        if (!listo) return
        try {
            val locale = Locale.forLanguageTag(codigoBcp47)
            val res = motor.setLanguage(locale)
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                motor.setLanguage(Locale.forLanguageTag("es"))
            }
        } catch (_: Exception) {
        }
    }

    fun hablarTexto(texto: String, volumen: Float = 1.0f, codigoIdioma: String = "es-MX") {
        val motor = tts ?: return
        if (!listo) return
        try {
            if (codigoIdioma != codigoIdiomaActual) {
                aplicarIdioma(codigoIdioma)
            }
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volumen.coerceIn(0.1f, 1.0f))
            }
            motor.speak(texto, TextToSpeech.QUEUE_FLUSH, params, "PDV_QR_TTS_${System.currentTimeMillis()}")
        } catch (_: Exception) {
        }
    }

    fun liberar() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
    }
}
