package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.BuildConfig
import com.example.R
import com.example.data.local.CierreDiarioEntity
import com.example.data.local.ConfiguracionNegocioEntity
import com.example.data.local.DetalleVentaEntity
import com.example.data.local.HistoricoPrecioEntity
import com.example.data.local.ProductoEntity
import com.example.data.local.RegistroCambioEntity
import com.example.data.local.VentaEntity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.DataFormatter
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.min

data class ProductoImportadoDto(
    val codigo: String,
    val nombre: String,
    val gramaje: String,
    val volumen: String,
    val precio: Double
)

data class ResumenProductoDia(
    val codigo: String,
    val nombre: String,
    val presentacion: String,
    val cantidadVendida: Int,
    val precioUnitario: Double,
    val totalRecaudado: Double
)

object PdfAndExcelExporter {

    fun inicializarPdfBox(context: Context) {
        runCatching {
            if (!PDFBoxResourceLoader.isReady()) {
                PDFBoxResourceLoader.init(context.applicationContext)
            }
        }
    }

    /**
     * Determina la carpeta de destino según la preferencia del usuario (Memoria Interna o Micro SD).
     */
    fun obtenerDirectorioExportacion(
        context: Context,
        preferenciaAlmacenamiento: String,
        subcarpeta: String
    ): File {
        val dirsExternos = ContextCompat.getExternalFilesDirs(context, null).filterNotNull()
        val baseDir = if (preferenciaAlmacenamiento.equals("SD", ignoreCase = true) && dirsExternos.size > 1) {
            dirsExternos[1] // Tarjeta Micro SD removible
        } else if (dirsExternos.isNotEmpty()) {
            dirsExternos[0] // Memoria interna compartida de la app
        } else {
            context.filesDir
        }
        val carpeta = File(baseDir, "PuntoDeVentaQR/$subcarpeta")
        if (!carpeta.exists()) {
            carpeta.mkdirs()
        }
        return carpeta
    }

    fun tieneTarjetaSdDisponible(context: Context): Boolean {
        val dirs = ContextCompat.getExternalFilesDirs(context, null).filterNotNull()
        return dirs.size > 1
    }

    /**
     * Guarda el logo del negocio en la carpeta interna de la app, redimensionando a máx 500x500 px
     * y comprimiendo automáticamente si supera 2 MB.
     */
    fun procesarYGuardarLogoNegocio(context: Context, uri: Uri): Result<String> {
        return runCatching {
            val bytesOriginales = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalArgumentException("No se pudo abrir la imagen seleccionada.")

            val bitmapOriginal = BitmapFactory.decodeByteArray(bytesOriginales, 0, bytesOriginales.size)
                ?: throw IllegalArgumentException("Formato de imagen no soportado. Usa PNG, JPG o JPEG.")

            val maxDim = 500
            val ancho = bitmapOriginal.width
            val alto = bitmapOriginal.height
            val escala = min(maxDim.toFloat() / ancho.toFloat(), maxDim.toFloat() / alto.toFloat()).coerceAtMost(1f)
            val nuevoAncho = (ancho * escala).toInt().coerceAtLeast(1)
            val nuevoAlto = (alto * escala).toInt().coerceAtLeast(1)

            val bitmapEscala = if (escala < 1f) {
                Bitmap.createScaledBitmap(bitmapOriginal, nuevoAncho, nuevoAlto, true)
            } else {
                bitmapOriginal
            }

            val baos = ByteArrayOutputStream()
            var calidad = 92
            bitmapEscala.compress(Bitmap.CompressFormat.JPEG, calidad, baos)
            while (baos.size() > 2 * 1024 * 1024 && calidad > 30) {
                baos.reset()
                calidad -= 15
                bitmapEscala.compress(Bitmap.CompressFormat.JPEG, calidad, baos)
            }

            val archivoDestino = File(context.filesDir, "logo_negocio_interno.jpg")
            FileOutputStream(archivoDestino).use { it.write(baos.toByteArray()) }
            archivoDestino.absolutePath
        }
    }

    private fun cargarBitmapLogo(context: Context, config: ConfiguracionNegocioEntity?): Bitmap? {
        val ruta = config?.rutaLogoInterno
        if (!ruta.isNullOrBlank()) {
            val file = File(ruta)
            if (file.exists()) {
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) return bmp
            }
        }
        return runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.img_default_store_logo)
        }.getOrNull()
    }

    /**
     * Genera el PDF contable completo del Resumen del Día (Encabezado, Cuerpo con 5 secciones y Pie con firmas y versión).
     */
    fun generarPdfResumenDelDia(
        context: Context,
        config: ConfiguracionNegocioEntity,
        cierre: CierreDiarioEntity,
        ventasDelDia: List<VentaEntity>,
        detallesDelDia: List<DetalleVentaEntity>
    ): File {
        inicializarPdfBox(context)
        val documento = PdfDocument()
        val pageWidth = 595 // A4 width en puntos
        val pageHeight = 842 // A4 height en puntos
        val margin = 36f

        var numeroPagina = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, numeroPagina).create()
        var page = documento.startPage(pageInfo)
        var canvas = page.canvas
        var y = margin

        val paintTitulo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(6, 78, 59)
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val paintSubtitulo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val paintTexto = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 41, 59)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val paintMono = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }
        val paintMonoBold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(6, 78, 59)
            textSize = 10f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val paintLinea = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }
        val paintFondoSeccion = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(236, 253, 245)
            style = Paint.Style.FILL
        }

        fun verificarSaltoPagina(altoRequerido: Float) {
            if (y + altoRequerido > pageHeight - 95f) {
                dibujarPieDePagina(canvas, pageWidth, pageHeight, margin, cierre.vendedor, config.nombreDueno, numeroPagina)
                documento.finishPage(page)
                numeroPagina++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, numeroPagina).create()
                page = documento.startPage(pageInfo)
                canvas = page.canvas
                y = margin
            }
        }

        // ==================== ENCABEZADO ====================
        val logoBmp = cargarBitmapLogo(context, config)
        if (logoBmp != null) {
            val destRect = RectF(margin, y, margin + 62f, y + 62f)
            canvas.drawBitmap(logoBmp, null, destRect, null)
        }
        val xHeader = if (logoBmp != null) margin + 74f else margin
        canvas.drawText(config.nombreNegocio.uppercase(Locale.getDefault()), xHeader, y + 16f, paintTitulo)
        canvas.drawText("Dueño / Administrador: ${config.nombreDueno}", xHeader, y + 31f, paintTexto)
        canvas.drawText("Dirección: ${config.direccion}", xHeader, y + 44f, paintTexto)
        canvas.drawText("Tel: ${config.telefono}  |  Correo: ${config.correo}", xHeader, y + 57f, paintTexto)

        y += 74f
        canvas.drawLine(margin, y, pageWidth - margin, y, paintLinea)
        y += 14f

        // Banda de datos de la jornada
        canvas.drawRect(margin, y, pageWidth - margin, y + 40f, paintFondoSeccion)
        canvas.drawText("REPORTE CONTABLE DE RESUMEN DEL DÍA", margin + 10f, y + 15f, paintSubtitulo)
        canvas.drawText(
            "Fecha: ${cierre.fechaMostrar}   |   Apertura: ${cierre.horaApertura}   |   Cierre: ${cierre.horaCierre}   |   Vendedor: ${cierre.vendedor}",
            margin + 10f,
            y + 31f,
            paintTexto
        )
        y += 52f

        // ==================== 1. RESUMEN GENERAL ====================
        canvas.drawText("1. RESUMEN GENERAL DE LA JORNADA", margin, y, paintSubtitulo)
        y += 14f
        val fmt = { m: Double -> CurrencyAndVoiceFormatter.formatearMoneda(m, config) }
        canvas.drawText("Total Vendido: ${fmt(cierre.totalVendido)}", margin + 8f, y, paintMonoBold)
        canvas.drawText("Clientes Atendidos (Ventas): ${cierre.clientesAtendidos}", margin + 210f, y, paintTexto)
        canvas.drawText("Ticket Promedio: ${fmt(cierre.ticketPromedio)}", margin + 380f, y, paintTexto)
        y += 14f
        if (config.aplicaImpuesto) {
            canvas.drawText(
                "Impuestos incluidos (${config.porcentajeImpuesto}%): ${fmt(cierre.impuestosTotales)}",
                margin + 8f,
                y,
                paintTexto
            )
            y += 14f
        }
        canvas.drawLine(margin, y, pageWidth - margin, y, paintLinea)
        y += 16f

        // ==================== 2. DESGLOSE POR MÉTODO DE PAGO ====================
        canvas.drawText("2. DESGLOSE POR MÉTODO DE PAGO", margin, y, paintSubtitulo)
        y += 15f
        canvas.drawText("• Efectivo: ${fmt(cierre.totalEfectivo)}", margin + 8f, y, paintMono)
        canvas.drawText("• Transferencia: ${fmt(cierre.totalTransferencia)}", margin + 270f, y, paintMono)
        y += 14f
        canvas.drawText("• Tarjeta: ${fmt(cierre.totalTarjeta)}", margin + 8f, y, paintMono)
        canvas.drawText("• Crédito: ${fmt(cierre.totalCredito)}", margin + 270f, y, paintMono)
        y += 12f
        canvas.drawLine(margin, y, pageWidth - margin, y, paintLinea)
        y += 16f

        // ==================== 3. CIERRE DE CAJA (ARQUEO DE EFECTIVO) ====================
        canvas.drawText("3. CIERRE DE CAJA Y CONCILIACIÓN DE EFECTIVO", margin, y, paintSubtitulo)
        y += 15f
        canvas.drawText("Efectivo esperado por ventas en efectivo: ${fmt(cierre.totalEfectivo)}", margin + 8f, y, paintMono)
        y += 14f
        canvas.drawText("Efectivo contado físicamente en caja:     ${fmt(cierre.efectivoContado)}", margin + 8f, y, paintMonoBold)
        y += 14f
        val estadoDif = when {
            kotlin.math.abs(cierre.diferenciaCaja) < 0.005 -> "CUADRE EXACTO"
            cierre.diferenciaCaja > 0 -> "SOBRANTE (+${fmt(cierre.diferenciaCaja)})"
            else -> "FALTANTE (${fmt(cierre.diferenciaCaja)})"
        }
        canvas.drawText("Diferencia de caja: $estadoDif   |   Saldo Final Total: ${fmt(cierre.saldoFinal)}", margin + 8f, y, paintMonoBold)
        y += 14f
        if (cierre.observaciones.isNotBlank()) {
            canvas.drawText("Observaciones: ${cierre.observaciones.take(95)}", margin + 8f, y, paintTexto)
            y += 14f
        }
        canvas.drawLine(margin, y, pageWidth - margin, y, paintLinea)
        y += 16f

        // ==================== 4. DETALLE POR PRODUCTO ====================
        verificarSaltoPagina(60f)
        canvas.drawText("4. DETALLE POR PRODUCTO VENDIDO", margin, y, paintSubtitulo)
        y += 15f
        canvas.drawText("CÓDIGO   PRODUCTO                      CANT.     P. UNIT.      TOTAL RECAUDADO", margin + 4f, y, paintMonoBold)
        y += 6f
        canvas.drawLine(margin, y, pageWidth - margin, y, paintLinea)
        y += 13f

        val agrupadoProductos = detallesDelDia.groupBy { it.codigoProducto }.map { (codigo, lista) ->
            val primero = lista.first()
            val cantTotal = lista.sumOf { it.cantidad }
            val montoTotal = lista.sumOf { it.subtotal }
            ResumenProductoDia(
                codigo = codigo,
                nombre = primero.nombreProducto,
                presentacion = primero.presentacion,
                cantidadVendida = cantTotal,
                precioUnitario = primero.precioUnitario,
                totalRecaudado = montoTotal
            )
        }

        if (agrupadoProductos.isEmpty()) {
            canvas.drawText("Sin productos vendidos en esta jornada.", margin + 8f, y, paintTexto)
            y += 16f
        } else {
            agrupadoProductos.forEach { prod ->
                verificarSaltoPagina(18f)
                val etiquetaProd = "${prod.nombre} (${prod.presentacion})".take(26).padEnd(28, ' ')
                val codPad = prod.codigo.take(7).padEnd(8, ' ')
                val cantPad = "x${prod.cantidadVendida}".padEnd(9, ' ')
                val unitPad = fmt(prod.precioUnitario).padEnd(13, ' ')
                val totPad = fmt(prod.totalRecaudado)
                canvas.drawText("$codPad $etiquetaProd $cantPad $unitPad $totPad", margin + 4f, y, paintMono)
                y += 14f
            }
        }
        y += 6f
        canvas.drawLine(margin, y, pageWidth - margin, y, paintLinea)
        y += 16f

        // ==================== 5. DETALLE POR VENTA (CLIENTE POR CLIENTE) ====================
        verificarSaltoPagina(60f)
        canvas.drawText("5. DETALLE POR VENTA (CLIENTE POR CLIENTE)", margin, y, paintSubtitulo)
        y += 15f
        canvas.drawText("CLIENTE / VENTA    HORA EXACTA   MÉTODO PAGO      TOTAL       PRODUCTOS", margin + 4f, y, paintMonoBold)
        y += 6f
        canvas.drawLine(margin, y, pageWidth - margin, y, paintLinea)
        y += 13f

        if (ventasDelDia.isEmpty()) {
            canvas.drawText("No se registraron ventas individuales en esta fecha.", margin + 8f, y, paintTexto)
            y += 16f
        } else {
            ventasDelDia.forEachIndexed { idx, venta ->
                verificarSaltoPagina(20f)
                val cliPad = "Cliente #${idx + 1}".padEnd(18, ' ')
                val horaPad = venta.hora.padEnd(13, ' ')
                val metPad = venta.metodoPago.take(14).padEnd(16, ' ')
                val totPad = fmt(venta.total).padEnd(11, ' ')
                val itemsResumen = venta.resumenItems.take(32)
                canvas.drawText("$cliPad $horaPad $metPad $totPad $itemsResumen", margin + 4f, y, paintMono)
                y += 14f
            }
        }

        // ==================== PIE DE PÁGINA CON FIRMAS Y VERSIÓN ====================
        dibujarPieDePagina(canvas, pageWidth, pageHeight, margin, cierre.vendedor, config.nombreDueno, numeroPagina)
        documento.finishPage(page)

        val carpeta = obtenerDirectorioExportacion(context, config.almacenamientoExportacion, "PDFs")
        val nombreArchivo = "Resumen_Dia_${cierre.fechaIso}.pdf"
        val archivoPdf = File(carpeta, nombreArchivo)
        FileOutputStream(archivoPdf).use { out ->
            documento.writeTo(out)
        }
        documento.close()
        return archivoPdf
    }

    private fun dibujarPieDePagina(
        canvas: Canvas,
        pageWidth: Int,
        pageHeight: Int,
        margin: Float,
        nombreVendedor: String,
        nombreDueno: String,
        numeroPagina: Int
    ) {
        val yBase = pageHeight - 75f
        val paintLinea = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(100, 116, 139)
            strokeWidth = 1f
        }
        val paintPie = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(71, 85, 105)
            textSize = 8.5f
        }
        val paintPieBold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        // Líneas de firma
        canvas.drawLine(margin + 20f, yBase, margin + 210f, yBase, paintLinea)
        canvas.drawLine(pageWidth - margin - 210f, yBase, pageWidth - margin - 20f, yBase, paintLinea)

        canvas.drawText("Firma Vendedor: $nombreVendedor", margin + 30f, yBase + 13f, paintPieBold)
        canvas.drawText("Firma Dueño: $nombreDueno", pageWidth - margin - 200f, yBase + 13f, paintPieBold)

        canvas.drawText(
            "Nota legal y de control: Documento contable inmutable generado 100% offline en el dispositivo.",
            margin,
            yBase + 32f,
            paintPie
        )
        canvas.drawText(
            "Punto de Venta QR - Versión ${BuildConfig.VERSION_NAME}   |   Página $numeroPagina",
            margin,
            yBase + 45f,
            paintPieBold
        )
    }

    /**
     * Genera un archivo PDF con las etiquetas QR de los productos seleccionados (o todo el catálogo).
     * IMPORTANTE: El QR codifica ÚNICAMENTE el código (ej. P001), sin nombre, ni precio, ni gramaje.
     */
    fun generarPdfEtiquetasQr(
        context: Context,
        productos: List<ProductoEntity>,
        preferenciaAlmacenamiento: String,
        nombreArchivoPersonalizado: String? = null
    ): File {
        inicializarPdfBox(context)
        val documento = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 36f

        val columnas = 3
        val filasPorPagina = 4
        val porPagina = columnas * filasPorPagina
        val cellWidth = (pageWidth - margin * 2) / columnas
        val cellHeight = (pageHeight - margin * 2 - 50f) / filasPorPagina

        val paintHeader = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(6, 78, 59)
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val paintCodigo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 12f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val paintSub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(71, 85, 105)
            textSize = 9f
            textAlign = Paint.Align.CENTER
        }
        val paintBorde = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(203, 213, 225)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }

        val paginas = productos.chunked(porPagina).ifEmpty { listOf(emptyList()) }
        paginas.forEachIndexed { pageIndex, lote ->
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            val page = documento.startPage(pageInfo)
            val canvas = page.canvas

            canvas.drawText(
                "ETIQUETAS QR DE CATÁLOGO (CONTENIDO QR: SOLO CÓDIGO) - Pág. ${pageIndex + 1}/${paginas.size}",
                margin,
                margin + 14f,
                paintHeader
            )

            lote.forEachIndexed { idx, prod ->
                val col = idx % columnas
                val row = idx / columnas
                val x = margin + col * cellWidth
                val y = margin + 32f + row * cellHeight

                val rectCelda = RectF(x + 6f, y + 6f, x + cellWidth - 6f, y + cellHeight - 6f)
                canvas.drawRoundRect(rectCelda, 8f, 8f, paintBorde)

                // El QR contiene exclusivamente prod.codigo (ej. P001)
                val qrBmp = QrCodeBitmapGenerator.generarQrSoloCodigo(prod.codigo, 240)
                val qrSize = min(cellWidth - 36f, cellHeight - 54f)
                val qrLeft = x + (cellWidth - qrSize) / 2f
                val qrTop = y + 14f
                canvas.drawBitmap(qrBmp, null, RectF(qrLeft, qrTop, qrLeft + qrSize, qrTop + qrSize), null)

                val centerX = x + cellWidth / 2f
                canvas.drawText(prod.codigo, centerX, qrTop + qrSize + 15f, paintCodigo)
                canvas.drawText(prod.nombre.take(20), centerX, qrTop + qrSize + 28f, paintSub)
            }

            documento.finishPage(page)
        }

        val carpeta = obtenerDirectorioExportacion(context, preferenciaAlmacenamiento, "EtiquetasQR")
        val nombreFinal = nombreArchivoPersonalizado
            ?: "Etiquetas_QR_Catalogo_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.pdf"
        val archivoPdf = File(carpeta, nombreFinal)
        FileOutputStream(archivoPdf).use { out ->
            documento.writeTo(out)
        }
        documento.close()
        return archivoPdf
    }

    /**
     * Envía cualquier PDF generado al gestor de impresión nativo de Android.
     */
    fun imprimirArchivoPdf(context: Context, archivoPdf: File, nombreTrabajo: String): Result<Unit> {
        return runCatching {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val adapter = object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = PrintDocumentInfo.Builder(archivoPdf.name)
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .build()
                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor?,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    try {
                        FileInputStream(archivoPdf).use { input ->
                            FileOutputStream(destination?.fileDescriptor).use { output ->
                                input.copyTo(output)
                            }
                        }
                        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    }
                }
            }
            printManager.print(nombreTrabajo, adapter, PrintAttributes.Builder().build())
        }
    }

    /**
     * Abre o comparte un archivo PDF, Excel o ZIP mediante FileProvider.
     */
    fun abrirOCompartirArchivo(context: Context, archivo: File, mimeType: String): Result<Unit> {
        return runCatching {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                archivo
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Punto de Venta QR - ${archivo.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Exportar / Compartir ${archivo.name}").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        }
    }

    /**
     * Prepara el envío del respaldo nocturno (PDF + Logo del negocio) al correo del dueño.
     */
    fun enviarRespaldoAlCorreoDueno(
        context: Context,
        config: ConfiguracionNegocioEntity,
        archivoPdf: File
    ): Result<Unit> {
        return runCatching {
            val uris = ArrayList<Uri>()
            val pdfUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                archivoPdf
            )
            uris.add(pdfUri)

            config.rutaLogoInterno?.let { rutaLogo ->
                val logoFile = File(rutaLogo)
                if (logoFile.exists()) {
                    val logoUri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        logoFile
                    )
                    uris.add(logoUri)
                }
            }

            val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_EMAIL, arrayOf(config.correo))
                putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Respaldo Diario ${config.nombreNegocio} - ${archivoPdf.nameWithoutExtension}"
                )
                putExtra(
                    Intent.EXTRA_TEXT,
                    "Adjunto se encuentra el reporte contable PDF del día y el respaldo del logo de ${config.nombreNegocio} (Versión ${BuildConfig.VERSION_NAME})."
                )
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Enviar respaldo al correo del dueño").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        }
    }

    // ==================== EXPORTACIÓN E IMPORTACIÓN EXCEL (APACHE POI) Y CSV ====================

    /**
     * Exporta el catálogo completo a un archivo Excel (.xls) real usando Apache POI.
     */
    fun exportarCatalogoAExcelPoi(
        context: Context,
        productos: List<ProductoEntity>,
        preferenciaAlmacenamiento: String
    ): File {
        val workbook = HSSFWorkbook()
        val sheet = workbook.createSheet("Catalogo_Productos")

        val header = sheet.createRow(0)
        val columnas = listOf("codigo", "nombre", "gramaje", "volumen", "fecha_ultimo_cambio", "precio_actual")
        columnas.forEachIndexed { idx, col ->
            header.createCell(idx).setCellValue(col)
        }

        productos.forEachIndexed { index, prod ->
            val row = sheet.createRow(index + 1)
            row.createCell(0).setCellValue(prod.codigo)
            row.createCell(1).setCellValue(prod.nombre)
            row.createCell(2).setCellValue(prod.gramaje)
            row.createCell(3).setCellValue(prod.volumen)
            row.createCell(4).setCellValue(prod.fecha_ultimo_cambio)
            row.createCell(5).setCellValue(prod.precio_actual)
        }

        val carpeta = obtenerDirectorioExportacion(context, preferenciaAlmacenamiento, "Excel")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val archivoXls = File(carpeta, "Catalogo_Productos_$stamp.xls")
        FileOutputStream(archivoXls).use { out ->
            workbook.write(out)
        }
        workbook.close()
        return archivoXls
    }

    /**
     * Exporta las ventas e historial diario a un libro Excel (.xls) con múltiples hojas usando Apache POI.
     */
    fun exportarVentasYHistorialAExcelPoi(
        context: Context,
        ventas: List<VentaEntity>,
        detalles: List<DetalleVentaEntity>,
        cierres: List<CierreDiarioEntity>,
        preferenciaAlmacenamiento: String
    ): File {
        val workbook = HSSFWorkbook()

        // Hoja 1: Ventas individuales
        val sheetVentas = workbook.createSheet("Ventas")
        val hVentas = sheetVentas.createRow(0)
        listOf("ID", "Fecha", "Hora", "Vendedor", "Metodo_Pago", "Subtotal", "Impuesto", "Total", "Productos").forEachIndexed { i, t ->
            hVentas.createCell(i).setCellValue(t)
        }
        ventas.forEachIndexed { idx, v ->
            val r = sheetVentas.createRow(idx + 1)
            r.createCell(0).setCellValue(v.id.toDouble())
            r.createCell(1).setCellValue(v.fechaMostrar)
            r.createCell(2).setCellValue(v.hora)
            r.createCell(3).setCellValue(v.vendedor)
            r.createCell(4).setCellValue(v.metodoPago)
            r.createCell(5).setCellValue(v.subtotal)
            r.createCell(6).setCellValue(v.impuesto)
            r.createCell(7).setCellValue(v.total)
            r.createCell(8).setCellValue(v.resumenItems)
        }

        // Hoja 2: Detalle por línea
        val sheetDetalles = workbook.createSheet("Detalle_Productos_Vendidos")
        val hDet = sheetDetalles.createRow(0)
        listOf("Venta_ID", "Fecha", "Codigo", "Producto", "Presentacion", "Cantidad", "Precio_Unitario", "Subtotal").forEachIndexed { i, t ->
            hDet.createCell(i).setCellValue(t)
        }
        detalles.forEachIndexed { idx, d ->
            val r = sheetDetalles.createRow(idx + 1)
            r.createCell(0).setCellValue(d.ventaId.toDouble())
            r.createCell(1).setCellValue(d.fechaIso)
            r.createCell(2).setCellValue(d.codigoProducto)
            r.createCell(3).setCellValue(d.nombreProducto)
            r.createCell(4).setCellValue(d.presentacion)
            r.createCell(5).setCellValue(d.cantidad.toDouble())
            r.createCell(6).setCellValue(d.precioUnitario)
            r.createCell(7).setCellValue(d.subtotal)
        }

        // Hoja 3: Cierres Diarios Sellados
        val sheetCierres = workbook.createSheet("Cierres_Diarios")
        val hCierres = sheetCierres.createRow(0)
        listOf(
            "Fecha", "Vendedor", "Apertura", "Cierre", "Clientes", "Total_Vendido",
            "Efectivo_Esperado", "Efectivo_Contado", "Diferencia", "Transferencia", "Tarjeta", "Credito", "Observaciones"
        ).forEachIndexed { i, t ->
            hCierres.createCell(i).setCellValue(t)
        }
        cierres.forEachIndexed { idx, c ->
            val r = sheetCierres.createRow(idx + 1)
            r.createCell(0).setCellValue(c.fechaMostrar)
            r.createCell(1).setCellValue(c.vendedor)
            r.createCell(2).setCellValue(c.horaApertura)
            r.createCell(3).setCellValue(c.horaCierre)
            r.createCell(4).setCellValue(c.clientesAtendidos.toDouble())
            r.createCell(5).setCellValue(c.totalVendido)
            r.createCell(6).setCellValue(c.totalEfectivo)
            r.createCell(7).setCellValue(c.efectivoContado)
            r.createCell(8).setCellValue(c.diferenciaCaja)
            r.createCell(9).setCellValue(c.totalTransferencia)
            r.createCell(10).setCellValue(c.totalTarjeta)
            r.createCell(11).setCellValue(c.totalCredito)
            r.createCell(12).setCellValue(c.observaciones)
        }

        val carpeta = obtenerDirectorioExportacion(context, preferenciaAlmacenamiento, "Excel")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val archivoXls = File(carpeta, "Reporte_Contable_Ventas_$stamp.xls")
        FileOutputStream(archivoXls).use { out ->
            workbook.write(out)
        }
        workbook.close()
        return archivoXls
    }

    /**
     * Importa productos desde un archivo Excel (.xls con Apache POI) o CSV con columnas:
     * codigo | nombre | gramaje | volumen | precio
     */
    fun importarProductosDesdeUri(context: Context, uri: Uri): Result<List<ProductoImportadoDto>> {
        return runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalArgumentException("No se pudo leer el archivo seleccionado.")

            // Detectar si es un archivo binario OLE2 (.xls de Excel) por su cabecera mágica D0 CF 11 E0
            val esXlsBinario = bytes.size > 8 &&
                bytes[0] == 0xD0.toByte() &&
                bytes[1] == 0xCF.toByte() &&
                bytes[2] == 0x11.toByte() &&
                bytes[3] == 0xE0.toByte()

            if (esXlsBinario) {
                importarDesdeExcelPoiBytes(bytes)
            } else {
                importarDesdeTextoCsv(bytes)
            }
        }
    }

    private fun importarDesdeExcelPoiBytes(bytes: ByteArray): List<ProductoImportadoDto> {
        val resultado = mutableListOf<ProductoImportadoDto>()
        val formatter = DataFormatter()
        bytes.inputStream().use { input ->
            val workbook = HSSFWorkbook(input)
            val sheet = workbook.getSheetAt(0)
            for (rowIndex in 0..sheet.lastRowNum) {
                val row = sheet.getRow(rowIndex) ?: continue
                val col0 = formatter.formatCellValue(row.getCell(0)).trim()
                if (col0.isEmpty() || col0.equals("codigo", ignoreCase = true) || col0.equals("código", ignoreCase = true)) {
                    continue
                }
                val nombre = formatter.formatCellValue(row.getCell(1)).trim()
                val gramaje = formatter.formatCellValue(row.getCell(2)).trim().ifEmpty { "-" }
                val volumen = formatter.formatCellValue(row.getCell(3)).trim().ifEmpty { "-" }
                // Soportar tanto 5 columnas (codigo|nombre|gramaje|volumen|precio) como 6 columnas (con fecha_ultimo_cambio)
                val celda4 = formatter.formatCellValue(row.getCell(4)).trim()
                val celda5 = formatter.formatCellValue(row.getCell(5)).trim()
                val precioTexto = if (celda5.isNotEmpty() && celda4.contains("-")) celda5 else celda4
                val precio = precioTexto.replace(",", ".").replace("[^0-9.]".toRegex(), "").toDoubleOrNull() ?: 0.0
                if (nombre.isNotEmpty() && precio > 0.0) {
                    resultado.add(
                        ProductoImportadoDto(
                            codigo = col0.uppercase(Locale.getDefault()),
                            nombre = nombre,
                            gramaje = gramaje,
                            volumen = volumen,
                            precio = precio
                        )
                    )
                }
            }
            workbook.close()
        }
        return resultado
    }

    private fun importarDesdeTextoCsv(bytes: ByteArray): List<ProductoImportadoDto> {
        val resultado = mutableListOf<ProductoImportadoDto>()
        BufferedReader(InputStreamReader(bytes.inputStream(), Charsets.UTF_8)).useLines { lines ->
            lines.forEach { lineaRaw ->
                val linea = lineaRaw.trim()
                if (linea.isNotEmpty()) {
                    val delimitador = when {
                        linea.contains("|") -> "|"
                        linea.contains(";") -> ";"
                        else -> ","
                    }
                    val partes = linea.split(delimitador).map { it.trim() }
                    if (partes.size >= 5) {
                        val codigo = partes[0]
                        if (!codigo.equals("codigo", ignoreCase = true) && !codigo.equals("código", ignoreCase = true)) {
                            val nombre = partes[1]
                            val gramaje = partes[2].ifEmpty { "-" }
                            val volumen = partes[3].ifEmpty { "-" }
                            val precioRaw = if (partes.size >= 6 && partes[4].contains("-")) partes[5] else partes[4]
                            val precio = precioRaw.replace(",", ".").replace("[^0-9.]".toRegex(), "").toDoubleOrNull() ?: 0.0
                            if (codigo.isNotEmpty() && nombre.isNotEmpty() && precio > 0.0) {
                                resultado.add(
                                    ProductoImportadoDto(
                                        codigo = codigo.uppercase(Locale.getDefault()),
                                        nombre = nombre,
                                        gramaje = gramaje,
                                        volumen = volumen,
                                        precio = precio
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
        return resultado
    }

    /**
     * Botón "Exportar todo": Genera un paquete ZIP completo en Memoria Interna o Micro SD
     * con la base de datos SQLite, Excels, CSVs, PDFs e imagen del logo del negocio.
     */
    fun exportarTodoRespaldoZip(
        context: Context,
        config: ConfiguracionNegocioEntity,
        productos: List<ProductoEntity>,
        historicoPrecios: List<HistoricoPrecioEntity>,
        ventas: List<VentaEntity>,
        detalles: List<DetalleVentaEntity>,
        cierres: List<CierreDiarioEntity>,
        cambios: List<RegistroCambioEntity>
    ): File {
        val pref = config.almacenamientoExportacion
        val excelCatalogo = exportarCatalogoAExcelPoi(context, productos, pref)
        val excelVentas = exportarVentasYHistorialAExcelPoi(context, ventas, detalles, cierres, pref)

        val carpetaRespaldos = obtenerDirectorioExportacion(context, pref, "Respaldos")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val archivoZip = File(carpetaRespaldos, "Respaldo_Total_PDVQR_$stamp.zip")

        ZipOutputStream(FileOutputStream(archivoZip)).use { zos ->
            fun agregarArchivoAlZip(file: File, nombreEnZip: String) {
                if (!file.exists()) return
                zos.putNextEntry(ZipEntry(nombreEnZip))
                FileInputStream(file).use { input -> input.copyTo(zos) }
                zos.closeEntry()
            }

            fun agregarTextoAlZip(contenido: String, nombreEnZip: String) {
                zos.putNextEntry(ZipEntry(nombreEnZip))
                zos.write(contenido.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }

            // 1. Excels generados con Apache POI
            agregarArchivoAlZip(excelCatalogo, "excel/${excelCatalogo.name}")
            agregarArchivoAlZip(excelVentas, "excel/${excelVentas.name}")

            // 2. CSV de catálogo e históricos
            val csvCatalogo = buildString {
                appendLine("codigo|nombre|gramaje|volumen|fecha_ultimo_cambio|precio_actual")
                productos.forEach { p ->
                    appendLine("${p.codigo}|${p.nombre}|${p.gramaje}|${p.volumen}|${p.fecha_ultimo_cambio}|${p.precio_actual}")
                }
            }
            agregarTextoAlZip(csvCatalogo, "csv/catalogo_productos.csv")

            val csvHistoricoPrecios = buildString {
                appendLine("codigo|nombre|precio_anterior|precio_nuevo|fecha_cambio")
                historicoPrecios.forEach { h ->
                    appendLine("${h.codigo}|${h.nombre}|${h.precio_anterior}|${h.precio_nuevo}|${h.fecha_cambio}")
                }
            }
            agregarTextoAlZip(csvHistoricoPrecios, "csv/historico_precios.csv")

            val csvAuditoria = buildString {
                appendLine("fecha|hora|tipo|codigo_producto|detalle")
                cambios.forEach { c ->
                    appendLine("${c.fecha}|${c.hora}|${c.tipo}|${c.codigoProducto}|${c.detalle}")
                }
            }
            agregarTextoAlZip(csvAuditoria, "csv/registro_auditoria_cambios.csv")

            // 3. Logo del negocio incluido en el respaldo
            config.rutaLogoInterno?.let { rutaLogo ->
                val logoFile = File(rutaLogo)
                if (logoFile.exists()) {
                    agregarArchivoAlZip(logoFile, "logo/logo_negocio.jpg")
                }
            }

            // 4. Todos los PDFs contables y de etiquetas QR generados
            val carpetaPdfs = obtenerDirectorioExportacion(context, pref, "PDFs")
            carpetaPdfs.listFiles()?.forEach { pdf ->
                if (pdf.isFile && pdf.name.endsWith(".pdf")) {
                    agregarArchivoAlZip(pdf, "pdfs/${pdf.name}")
                }
            }

            // 5. Copia directa del archivo SQLite interno
            val dbFile = context.getDatabasePath("punto_de_venta_qr_interno.db")
            if (dbFile.exists()) {
                agregarArchivoAlZip(dbFile, "sqlite/punto_de_venta_qr_interno.db")
            }
        }

        return archivoZip
    }
}
