package com.example.util

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.concurrent.Executors

object QrCodeBitmapGenerator {

    /**
     * Genera el bitmap del QR de un producto conteniendo ÚNICAMENTE el código (ej. P001).
     * No incluye nombre, ni precio, ni gramaje dentro del QR.
     */
    fun generarQrSoloCodigo(codigoProducto: String, tamanoPx: Int = 400): Bitmap {
        val contenidoLimpio = codigoProducto.trim()
        val hints = mapOf(
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 1
        )
        val bitMatrix = QRCodeWriter().encode(
            contenidoLimpio,
            BarcodeFormat.QR_CODE,
            tamanoPx,
            tamanoPx,
            hints
        )
        val width = bitMatrix.width
        val height = bitMatrix.height
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            val offset = y * width
            for (x in 0 until width) {
                pixels[offset + x] = if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE
            }
        }
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, width, 0, 0, width, height)
        }
    }
}

/**
 * Vista de escáner CameraX + Google ML Kit (versión bundled 100% offline)
 * con soporte para cámara trasera (por defecto) y frontal, y conmutación automática
 * a la otra cámara si una falla.
 */
@SuppressLint("UnsafeOptInUsageError")
@Composable
fun OfflineQrCameraScanner(
    usarCamaraFrontal: Boolean,
    escaneoActivo: Boolean,
    onCodigoDetectado: (String) -> Unit,
    onQrDanadoDetectado: () -> Unit,
    onFalloCamaraConmutar: (Boolean, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnCodigo by rememberUpdatedState(onCodigoDetectado)
    val currentOnDanado by rememberUpdatedState(onQrDanadoDetectado)
    val currentOnFallo by rememberUpdatedState(onFalloCamaraConmutar)

    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val barcodeScanner = remember {
        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE, Barcode.FORMAT_ALL_FORMATS)
            .build()
        BarcodeScanning.getClient(options)
    }

    var ultimoCodigoLeido by remember { mutableStateOf("") }
    var ultimoTiempoLectura by remember { mutableStateOf(0L) }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { barcodeScanner.close() }
            runCatching { cameraExecutor.shutdown() }
        }
    }

    LaunchedEffect(usarCamaraFrontal, escaneoActivo) {
        if (!escaneoActivo) return@LaunchedEffect

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = runCatching { cameraProviderFuture.get() }.getOrNull() ?: return@addListener

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val imageAnalysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val mediaImage = imageProxy.image
                if (mediaImage != null && escaneoActivo) {
                    val inputImage = InputImage.fromMediaImage(
                        mediaImage,
                        imageProxy.imageInfo.rotationDegrees
                    )
                    barcodeScanner.process(inputImage)
                        .addOnSuccessListener { barcodes ->
                            if (barcodes.isNotEmpty()) {
                                val barcode = barcodes.first()
                                val raw = barcode.rawValue
                                val ahora = System.currentTimeMillis()
                                if (raw == null || raw.isBlank()) {
                                    if (ahora - ultimoTiempoLectura > 1800L) {
                                        ultimoTiempoLectura = ahora
                                        currentOnDanado()
                                    }
                                } else {
                                    val limpio = raw.trim()
                                    if (limpio != ultimoCodigoLeido || (ahora - ultimoTiempoLectura > 1400L)) {
                                        ultimoCodigoLeido = limpio
                                        ultimoTiempoLectura = ahora
                                        currentOnCodigo(limpio)
                                    }
                                }
                            }
                        }
                        .addOnCompleteListener {
                            imageProxy.close()
                        }
                } else {
                    imageProxy.close()
                }
            }

            val selectorDeseado = if (usarCamaraFrontal) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

            val selectorAlternativo = if (usarCamaraFrontal) {
                CameraSelector.DEFAULT_BACK_CAMERA
            } else {
                CameraSelector.DEFAULT_FRONT_CAMERA
            }

            try {
                cameraProvider.unbindAll()
                if (cameraProvider.hasCamera(selectorDeseado)) {
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        selectorDeseado,
                        preview,
                        imageAnalysis
                    )
                } else if (cameraProvider.hasCamera(selectorAlternativo)) {
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        selectorAlternativo,
                        preview,
                        imageAnalysis
                    )
                    currentOnFallo(
                        !usarCamaraFrontal,
                        "La cámara seleccionada no está disponible; se cambió automáticamente a la otra cámara."
                    )
                }
            } catch (e: Exception) {
                // Si una cámara falla al enlazar, intentar con la otra automáticamente
                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        selectorAlternativo,
                        preview,
                        imageAnalysis
                    )
                    currentOnFallo(
                        !usarCamaraFrontal,
                        "Fallo detectado en cámara; se conmutó automáticamente a la cámara alternativa."
                    )
                } catch (_: Exception) {
                }
            }
        }, ContextCompat.getMainExecutor(context))
    }

    AndroidView(
        factory = { previewView },
        modifier = modifier.fillMaxSize()
    )
}
