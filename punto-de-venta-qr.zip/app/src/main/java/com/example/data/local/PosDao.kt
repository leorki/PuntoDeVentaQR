package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PosDao {

    // ==================== ACTIVACIÓN Y LICENCIA ====================
    @Query("SELECT * FROM licencia_activacion WHERE id = 1 LIMIT 1")
    suspend fun obtenerLicenciaSync(): LicenciaActivacionEntity?

    @Query("SELECT * FROM licencia_activacion WHERE id = 1 LIMIT 1")
    fun observarLicencia(): Flow<LicenciaActivacionEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardarLicencia(licencia: LicenciaActivacionEntity)

    // ==================== CONFIGURACIÓN DEL NEGOCIO ====================
    @Query("SELECT * FROM configuracion_negocio WHERE id = 1 LIMIT 1")
    fun observarConfiguracion(): Flow<ConfiguracionNegocioEntity?>

    @Query("SELECT * FROM configuracion_negocio WHERE id = 1 LIMIT 1")
    suspend fun obtenerConfiguracionSync(): ConfiguracionNegocioEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardarConfiguracion(config: ConfiguracionNegocioEntity)

    // ==================== JORNADA DIARIA ====================
    @Query("SELECT * FROM jornada_activa WHERE id = 1 LIMIT 1")
    fun observarJornadaActiva(): Flow<JornadaActivaEntity?>

    @Query("SELECT * FROM jornada_activa WHERE id = 1 LIMIT 1")
    suspend fun obtenerJornadaActivaSync(): JornadaActivaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardarJornadaActiva(jornada: JornadaActivaEntity)

    // ==================== CATÁLOGO DE PRODUCTOS ====================
    @Query("SELECT * FROM productos ORDER BY codigo ASC")
    fun observarProductos(): Flow<List<ProductoEntity>>

    @Query("SELECT * FROM productos ORDER BY codigo ASC")
    suspend fun obtenerTodosProductosSync(): List<ProductoEntity>

    @Query("SELECT * FROM productos WHERE UPPER(codigo) = UPPER(:codigo) LIMIT 1")
    suspend fun buscarProductoPorCodigo(codigo: String): ProductoEntity?

    @Query("SELECT COUNT(*) FROM productos")
    suspend fun contarProductos(): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarProducto(producto: ProductoEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarOActualizarProducto(producto: ProductoEntity)

    @Update
    suspend fun actualizarProducto(producto: ProductoEntity)

    @Query("DELETE FROM productos WHERE codigo = :codigo")
    suspend fun eliminarProductoPorCodigo(codigo: String)

    // ==================== HISTÓRICO DE PRECIOS ====================
    @Query("SELECT * FROM historico_precios ORDER BY id DESC")
    fun observarHistoricoPrecios(): Flow<List<HistoricoPrecioEntity>>

    @Query("SELECT * FROM historico_precios ORDER BY id DESC")
    suspend fun obtenerHistoricoPreciosSync(): List<HistoricoPrecioEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarHistoricoPrecio(historico: HistoricoPrecioEntity)

    // ==================== REGISTRO DE CAMBIOS Y AUDITORÍA ====================
    @Query("SELECT * FROM registro_cambios ORDER BY id DESC")
    fun observarRegistroCambios(): Flow<List<RegistroCambioEntity>>

    @Query("SELECT * FROM registro_cambios ORDER BY id DESC")
    suspend fun obtenerRegistroCambiosSync(): List<RegistroCambioEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarRegistroCambio(registro: RegistroCambioEntity)

    // ==================== CARRITO TEMPORAL (RECUPERACIÓN DE VENTA) ====================
    @Query("SELECT * FROM carrito_temporal ORDER BY codigo ASC")
    fun observarCarritoTemporal(): Flow<List<CarritoTemporalEntity>>

    @Query("SELECT * FROM carrito_temporal ORDER BY codigo ASC")
    suspend fun obtenerCarritoTemporalSync(): List<CarritoTemporalEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardarItemCarritoTemporal(item: CarritoTemporalEntity)

    @Query("DELETE FROM carrito_temporal WHERE codigo = :codigo")
    suspend fun eliminarItemCarritoTemporal(codigo: String)

    @Query("DELETE FROM carrito_temporal")
    suspend fun limpiarCarritoTemporal()

    // ==================== VENTAS Y DETALLE DE VENTAS ====================
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarVenta(venta: VentaEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarDetallesVenta(detalles: List<DetalleVentaEntity>)

    @Query("SELECT * FROM ventas WHERE fecha_iso = :fechaIso ORDER BY id DESC")
    fun observarVentasPorFecha(fechaIso: String): Flow<List<VentaEntity>>

    @Query("SELECT * FROM ventas WHERE fecha_iso = :fechaIso ORDER BY id ASC")
    suspend fun obtenerVentasPorFechaSync(fechaIso: String): List<VentaEntity>

    @Query("SELECT * FROM ventas ORDER BY id DESC")
    suspend fun obtenerTodasVentasSync(): List<VentaEntity>

    @Query("SELECT * FROM detalle_ventas WHERE fecha_iso = :fechaIso ORDER BY id ASC")
    suspend fun obtenerDetallesPorFechaSync(fechaIso: String): List<DetalleVentaEntity>

    @Query("SELECT * FROM detalle_ventas ORDER BY id ASC")
    suspend fun obtenerTodosDetallesSync(): List<DetalleVentaEntity>

    // ==================== HISTORIAL DIARIO SELLADO (INMUTABLE) ====================
    @Query("SELECT * FROM historial_diario ORDER BY fecha_iso DESC")
    fun observarHistorialDiario(): Flow<List<CierreDiarioEntity>>

    @Query("SELECT * FROM historial_diario ORDER BY fecha_iso DESC")
    suspend fun obtenerTodoHistorialDiarioSync(): List<CierreDiarioEntity>

    @Query("SELECT * FROM historial_diario WHERE fecha_iso = :fechaIso LIMIT 1")
    suspend fun obtenerCierrePorFechaSync(fechaIso: String): CierreDiarioEntity?

    // OnConflictStrategy.IGNORE garantiza que un día sellado sea inmutable y nunca se sobreescriba
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun sellarCierreDiarioInmutable(cierre: CierreDiarioEntity): Long
}
