package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        LicenciaActivacionEntity::class,
        ConfiguracionNegocioEntity::class,
        JornadaActivaEntity::class,
        ProductoEntity::class,
        HistoricoPrecioEntity::class,
        RegistroCambioEntity::class,
        CarritoTemporalEntity::class,
        VentaEntity::class,
        DetalleVentaEntity::class,
        CierreDiarioEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PosDatabase : RoomDatabase() {

    abstract fun posDao(): PosDao

    companion object {
        @Volatile
        private var INSTANCE: PosDatabase? = null

        fun getInstance(context: Context): PosDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PosDatabase::class.java,
                    "punto_de_venta_qr_interno.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                // Precargar catálogo inicial de prueba si la tabla está vacía
                CoroutineScope(Dispatchers.IO).launch {
                    precargarCatalogoInicialSiVacio(instance.posDao())
                }
                instance
            }
        }

        suspend fun precargarCatalogoInicialSiVacio(dao: PosDao) {
            if (dao.contarProductos() == 0) {
                val productosIniciales = listOf(
                    ProductoEntity(
                        codigo = "P001",
                        nombre = "Arroz",
                        gramaje = "1kg",
                        volumen = "-",
                        fecha_ultimo_cambio = "2026-10-07",
                        precio_actual = 2.50
                    ),
                    ProductoEntity(
                        codigo = "P002",
                        nombre = "Aceite",
                        gramaje = "-",
                        volumen = "1L",
                        fecha_ultimo_cambio = "2026-10-05",
                        precio_actual = 5.00
                    ),
                    ProductoEntity(
                        codigo = "P003",
                        nombre = "Leche",
                        gramaje = "-",
                        volumen = "1L",
                        fecha_ultimo_cambio = "2026-10-07",
                        precio_actual = 1.20
                    ),
                    ProductoEntity(
                        codigo = "P004",
                        nombre = "Azúcar Refinada",
                        gramaje = "1kg",
                        volumen = "-",
                        fecha_ultimo_cambio = "2026-10-07",
                        precio_actual = 1.80
                    ),
                    ProductoEntity(
                        codigo = "P005",
                        nombre = "Café Molido Tradicional",
                        gramaje = "500g",
                        volumen = "-",
                        fecha_ultimo_cambio = "2026-10-07",
                        precio_actual = 4.50
                    ),
                    ProductoEntity(
                        codigo = "P006",
                        nombre = "Harina de Maíz",
                        gramaje = "1kg",
                        volumen = "-",
                        fecha_ultimo_cambio = "2026-10-07",
                        precio_actual = 1.50
                    ),
                    ProductoEntity(
                        codigo = "P007",
                        nombre = "Agua Mineral",
                        gramaje = "-",
                        volumen = "1.5L",
                        fecha_ultimo_cambio = "2026-10-07",
                        precio_actual = 0.90
                    ),
                    ProductoEntity(
                        codigo = "P008",
                        nombre = "Refresco Familiar",
                        gramaje = "-",
                        volumen = "2L",
                        fecha_ultimo_cambio = "2026-10-07",
                        precio_actual = 2.20
                    )
                )
                productosIniciales.forEach { prod ->
                    runCatching { dao.insertarProducto(prod) }
                }
            }
        }
    }
}
