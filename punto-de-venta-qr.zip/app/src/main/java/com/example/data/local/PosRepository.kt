package com.example.data.local

import kotlinx.coroutines.flow.Flow

/**
 * Repositorio de acceso a datos siguiendo el patrón Repository para Room.
 */
class PosRepository(private val dao: PosDao) {

    val licenciaFlow: Flow<LicenciaActivacionEntity?> = dao.observarLicencia()
    val configuracionFlow: Flow<ConfiguracionNegocioEntity?> = dao.observarConfiguracion()
    val jornadaActivaFlow: Flow<JornadaActivaEntity?> = dao.observarJornadaActiva()
    val productosFlow: Flow<List<ProductoEntity>> = dao.observarProductos()
    val historicoPreciosFlow: Flow<List<HistoricoPrecioEntity>> = dao.observarHistoricoPrecios()
    val registroCambiosFlow: Flow<List<RegistroCambioEntity>> = dao.observarRegistroCambios()
    val carritoTemporalFlow: Flow<List<CarritoTemporalEntity>> = dao.observarCarritoTemporal()
    val historialDiarioFlow: Flow<List<CierreDiarioEntity>> = dao.observarHistorialDiario()

    fun observarVentasDeFecha(fechaIso: String): Flow<List<VentaEntity>> =
        dao.observarVentasPorFecha(fechaIso)

    suspend fun obtenerLicenciaSync() = dao.obtenerLicenciaSync()
    suspend fun guardarLicencia(licencia: LicenciaActivacionEntity) = dao.guardarLicencia(licencia)

    suspend fun obtenerConfiguracionSync() = dao.obtenerConfiguracionSync()
    suspend fun guardarConfiguracion(config: ConfiguracionNegocioEntity) = dao.guardarConfiguracion(config)

    suspend fun obtenerJornadaActivaSync() = dao.obtenerJornadaActivaSync()
    suspend fun guardarJornadaActiva(jornada: JornadaActivaEntity) = dao.guardarJornadaActiva(jornada)

    suspend fun obtenerTodosProductosSync() = dao.obtenerTodosProductosSync()
    suspend fun buscarProductoPorCodigo(codigo: String) = dao.buscarProductoPorCodigo(codigo.trim())
    suspend fun insertarProducto(producto: ProductoEntity) = dao.insertarProducto(producto)
    suspend fun insertarOActualizarProducto(producto: ProductoEntity) = dao.insertarOActualizarProducto(producto)
    suspend fun actualizarProducto(producto: ProductoEntity) = dao.actualizarProducto(producto)
    suspend fun eliminarProductoPorCodigo(codigo: String) = dao.eliminarProductoPorCodigo(codigo)

    suspend fun insertarHistoricoPrecio(historico: HistoricoPrecioEntity) = dao.insertarHistoricoPrecio(historico)
    suspend fun obtenerHistoricoPreciosSync() = dao.obtenerHistoricoPreciosSync()

    suspend fun insertarRegistroCambio(registro: RegistroCambioEntity) = dao.insertarRegistroCambio(registro)
    suspend fun obtenerRegistroCambiosSync() = dao.obtenerRegistroCambiosSync()

    suspend fun obtenerCarritoTemporalSync() = dao.obtenerCarritoTemporalSync()
    suspend fun guardarItemCarritoTemporal(item: CarritoTemporalEntity) = dao.guardarItemCarritoTemporal(item)
    suspend fun eliminarItemCarritoTemporal(codigo: String) = dao.eliminarItemCarritoTemporal(codigo)
    suspend fun limpiarCarritoTemporal() = dao.limpiarCarritoTemporal()

    suspend fun registrarVentaCompleta(
        venta: VentaEntity,
        detalles: List<DetalleVentaEntity>
    ): Long {
        val ventaId = dao.insertarVenta(venta)
        val detallesConId = detalles.map { it.copy(ventaId = ventaId) }
        dao.insertarDetallesVenta(detallesConId)
        dao.limpiarCarritoTemporal()
        return ventaId
    }

    suspend fun obtenerVentasPorFechaSync(fechaIso: String) = dao.obtenerVentasPorFechaSync(fechaIso)
    suspend fun obtenerDetallesPorFechaSync(fechaIso: String) = dao.obtenerDetallesPorFechaSync(fechaIso)
    suspend fun obtenerTodasVentasSync() = dao.obtenerTodasVentasSync()
    suspend fun obtenerTodosDetallesSync() = dao.obtenerTodosDetallesSync()

    suspend fun obtenerCierrePorFechaSync(fechaIso: String) = dao.obtenerCierrePorFechaSync(fechaIso)
    suspend fun obtenerTodoHistorialDiarioSync() = dao.obtenerTodoHistorialDiarioSync()
    suspend fun sellarCierreDiarioInmutable(cierre: CierreDiarioEntity): Long =
        dao.sellarCierreDiarioInmutable(cierre)
}
