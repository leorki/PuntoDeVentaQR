package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Estado de activación cifrado (AES-256-GCM) vinculado al hardware del dispositivo.
 */
@Entity(tableName = "licencia_activacion")
data class LicenciaActivacionEntity(
    @PrimaryKey val id: Int = 1,
    @ColumnInfo(name = "codigo_cifrado") val codigoCifrado: String,
    @ColumnInfo(name = "id_licencia_cifrado") val idLicenciaCifrado: String,
    @ColumnInfo(name = "huella_dispositivo_cifrada") val huellaDispositivoCifrada: String,
    @ColumnInfo(name = "vencimiento_cifrado") val vencimientoCifrado: String,
    @ColumnInfo(name = "fecha_activacion") val fechaActivacion: String,
    @ColumnInfo(name = "firma_integridad") val firmaIntegridad: String
)

/**
 * Configuración inicial del negocio (se solicita obligatoriamente el primer día).
 */
@Entity(tableName = "configuracion_negocio")
data class ConfiguracionNegocioEntity(
    @PrimaryKey val id: Int = 1,
    @ColumnInfo(name = "nombre_negocio") val nombreNegocio: String,
    @ColumnInfo(name = "nombre_dueno") val nombreDueno: String,
    @ColumnInfo(name = "direccion") val direccion: String,
    @ColumnInfo(name = "telefono") val telefono: String,
    @ColumnInfo(name = "correo") val correo: String,
    @ColumnInfo(name = "moneda_codigo") val monedaCodigo: String, // USD, EUR, VES, MXN, COP, PEN, ARS, CLP
    @ColumnInfo(name = "moneda_simbolo") val monedaSimbolo: String, // $, €, Bs., S/
    @ColumnInfo(name = "simbolo_antes") val simboloAntes: Boolean, // true: $2.50, false: 2,50 €
    @ColumnInfo(name = "separador_miles") val separadorMiles: String, // "," o "."
    @ColumnInfo(name = "separador_decimales") val separadorDecimales: String, // "." o ","
    @ColumnInfo(name = "moneda_voz_singular") val monedaVozSingular: String, // dólar, euro, bolívar, peso, sol
    @ColumnInfo(name = "moneda_voz_plural") val monedaVozPlural: String, // dólares, euros, bolívares, pesos, soles
    @ColumnInfo(name = "centavos_voz") val centavosVoz: String, // centavos, céntimos
    @ColumnInfo(name = "aplica_impuesto") val aplicaImpuesto: Boolean,
    @ColumnInfo(name = "porcentaje_impuesto") val porcentajeImpuesto: Double,
    @ColumnInfo(name = "ruta_logo_interno") val rutaLogoInterno: String?, // nulo si usa ícono genérico
    @ColumnInfo(name = "hash_password_admin") val hashPasswordAdmin: String,
    @ColumnInfo(name = "salt_password") val saltPassword: String,
    @ColumnInfo(name = "pregunta_seguridad") val preguntaSeguridad: String,
    @ColumnInfo(name = "hash_respuesta_seguridad") val hashRespuestaSeguridad: String,
    @ColumnInfo(name = "hash_codigo_maestro") val hashCodigoMaestro: String,
    @ColumnInfo(name = "idioma_voz_pais") val idiomaVozPais: String, // es-ES, es-MX, es-CO, es-AR, es-VE, es-PE, es-CL
    @ColumnInfo(name = "volumen_voz") val volumenVoz: Float = 1.0f,
    @ColumnInfo(name = "almacenamiento_exportacion") val almacenamientoExportacion: String = "INTERNO", // INTERNO o SD
    @ColumnInfo(name = "respaldo_nocturno_correo") val respaldoNocturnoCorreo: Boolean = false,
    @ColumnInfo(name = "configuracion_completada") val configuracionCompletada: Boolean = true
)

/**
 * Registro de apertura del día laboral actual.
 */
@Entity(tableName = "jornada_activa")
data class JornadaActivaEntity(
    @PrimaryKey val id: Int = 1,
    @ColumnInfo(name = "fecha_iso") val fechaIso: String, // YYYY-MM-DD
    @ColumnInfo(name = "fecha_completa") val fechaCompleta: String, // dd/MM/yyyy
    @ColumnInfo(name = "nombre_vendedor") val nombreVendedor: String,
    @ColumnInfo(name = "hora_apertura") val horaApertura: String, // HH:mm:ss
    @ColumnInfo(name = "jornada_abierta") val jornadaAbierta: Boolean = true
)

/**
 * Tabla interna de catálogo de productos con las columnas exactas solicitadas:
 * codigo | nombre | gramaje | volumen | fecha_ultimo_cambio | precio_actual
 */
@Entity(
    tableName = "productos",
    indices = [Index(value = ["codigo"], unique = true)]
)
data class ProductoEntity(
    @PrimaryKey
    @ColumnInfo(name = "codigo") val codigo: String,
    @ColumnInfo(name = "nombre") val nombre: String,
    @ColumnInfo(name = "gramaje") val gramaje: String,
    @ColumnInfo(name = "volumen") val volumen: String,
    @ColumnInfo(name = "fecha_ultimo_cambio") val fecha_ultimo_cambio: String,
    @ColumnInfo(name = "precio_actual") val precio_actual: Double
)

/**
 * Tabla aparte de histórico de precios con las columnas exactas solicitadas:
 * codigo | nombre | precio_anterior | precio_nuevo | fecha_cambio
 */
@Entity(tableName = "historico_precios")
data class HistoricoPrecioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "codigo") val codigo: String,
    @ColumnInfo(name = "nombre") val nombre: String,
    @ColumnInfo(name = "precio_anterior") val precio_anterior: Double,
    @ColumnInfo(name = "precio_nuevo") val precio_nuevo: Double,
    @ColumnInfo(name = "fecha_cambio") val fecha_cambio: String
)

/**
 * Registro de auditoría de cambios en catálogo, configuración y avisos de vendedor al admin.
 */
@Entity(tableName = "registro_cambios")
data class RegistroCambioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "fecha") val fecha: String, // dd/MM/yyyy
    @ColumnInfo(name = "hora") val hora: String, // HH:mm:ss
    @ColumnInfo(name = "tipo") val tipo: String, // EDICION_CATALOGO, CAMBIO_PRECIO, ALERTA_VENDEDOR, CONFIGURACION
    @ColumnInfo(name = "codigo_producto") val codigoProducto: String,
    @ColumnInfo(name = "detalle") val detalle: String
)

/**
 * Tabla de persistencia de venta en curso para recuperación ante cierres inesperados.
 */
@Entity(tableName = "carrito_temporal")
data class CarritoTemporalEntity(
    @PrimaryKey
    @ColumnInfo(name = "codigo") val codigo: String,
    @ColumnInfo(name = "nombre") val nombre: String,
    @ColumnInfo(name = "gramaje") val gramaje: String,
    @ColumnInfo(name = "volumen") val volumen: String,
    @ColumnInfo(name = "precio_unitario") val precioUnitario: Double,
    @ColumnInfo(name = "cantidad") val cantidad: Int,
    @ColumnInfo(name = "vendedor") val vendedor: String,
    @ColumnInfo(name = "fecha_inicio") val fechaInicio: String,
    @ColumnInfo(name = "hora_inicio") val horaInicio: String,
    @ColumnInfo(name = "recuperacion_pendiente") val recuperacionPendiente: Boolean = true
)

/**
 * Ventas cerradas del punto de venta.
 */
@Entity(tableName = "ventas")
data class VentaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "fecha_iso") val fechaIso: String, // YYYY-MM-DD
    @ColumnInfo(name = "fecha_mostrar") val fechaMostrar: String, // dd/MM/yyyy
    @ColumnInfo(name = "hora") val hora: String, // HH:mm:ss
    @ColumnInfo(name = "vendedor") val vendedor: String,
    @ColumnInfo(name = "metodo_pago") val metodoPago: String, // Efectivo, Transferencia, Tarjeta, Crédito
    @ColumnInfo(name = "subtotal") val subtotal: Double,
    @ColumnInfo(name = "impuesto") val impuesto: Double,
    @ColumnInfo(name = "total") val total: Double,
    @ColumnInfo(name = "resumen_items") val resumenItems: String
)

/**
 * Líneas de detalle de cada venta cerrada.
 */
@Entity(tableName = "detalle_ventas")
data class DetalleVentaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "venta_id") val ventaId: Long,
    @ColumnInfo(name = "fecha_iso") val fechaIso: String,
    @ColumnInfo(name = "codigo_producto") val codigoProducto: String,
    @ColumnInfo(name = "nombre_producto") val nombreProducto: String,
    @ColumnInfo(name = "presentacion") val presentacion: String, // gramaje o volumen
    @ColumnInfo(name = "cantidad") val cantidad: Int,
    @ColumnInfo(name = "precio_unitario") val precioUnitario: Double,
    @ColumnInfo(name = "subtotal") val subtotal: Double
)

/**
 * Historial diario sellado e inmutable (un registro por fecha, nunca se sobreescribe).
 */
@Entity(tableName = "historial_diario")
data class CierreDiarioEntity(
    @PrimaryKey
    @ColumnInfo(name = "fecha_iso") val fechaIso: String, // YYYY-MM-DD
    @ColumnInfo(name = "fecha_mostrar") val fechaMostrar: String, // dd/MM/yyyy
    @ColumnInfo(name = "vendedor") val vendedor: String,
    @ColumnInfo(name = "hora_apertura") val horaApertura: String,
    @ColumnInfo(name = "hora_cierre") val horaCierre: String,
    @ColumnInfo(name = "total_vendido") val totalVendido: Double,
    @ColumnInfo(name = "impuestos_totales") val impuestosTotales: Double,
    @ColumnInfo(name = "clientes_atendidos") val clientesAtendidos: Int,
    @ColumnInfo(name = "ticket_promedio") val ticketPromedio: Double,
    @ColumnInfo(name = "total_efectivo") val totalEfectivo: Double,
    @ColumnInfo(name = "total_transferencia") val totalTransferencia: Double,
    @ColumnInfo(name = "total_tarjeta") val totalTarjeta: Double,
    @ColumnInfo(name = "total_credito") val totalCredito: Double,
    @ColumnInfo(name = "efectivo_contado") val efectivoContado: Double,
    @ColumnInfo(name = "diferencia_caja") val diferenciaCaja: Double,
    @ColumnInfo(name = "saldo_final") val saldoFinal: Double,
    @ColumnInfo(name = "observaciones") val observaciones: String,
    @ColumnInfo(name = "productos_vendidos_resumen") val productosVendidosResumen: String,
    @ColumnInfo(name = "ruta_pdf") val rutaPdf: String,
    @ColumnInfo(name = "timestamp_sello") val timestampSello: Long
)
