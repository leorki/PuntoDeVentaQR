package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.CarritoTemporalEntity
import com.example.data.local.ConfiguracionNegocioEntity
import com.example.data.local.ProductoEntity
import com.example.data.local.VentaEntity
import com.example.util.CurrencyAndVoiceFormatter
import com.example.util.OfflineQrCameraScanner
import com.example.viewmodel.AlertaEscaner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ActiveSaleScreen(
    config: ConfiguracionNegocioEntity,
    fechaCompleta: String,
    horaExacta: String,
    nombreVendedor: String,
    carrito: List<CarritoTemporalEntity>,
    catalogo: List<ProductoEntity>,
    ventasDeHoy: List<VentaEntity>,
    usarCamaraFrontal: Boolean,
    escanerExpandido: Boolean,
    alertaEscaner: AlertaEscaner,
    subtotalCarrito: Double,
    impuestoCarrito: Double,
    totalCarrito: Double,
    onCambiarCamara: () -> Unit,
    onConmutarCamaraPorFallo: (Boolean, String) -> Unit,
    onAlternarVisibilidadEscaner: () -> Unit,
    onCodigoQrEscaneado: (String) -> Unit,
    onTimeoutEscaner3Segundos: () -> Unit,
    onQrDanado: () -> Unit,
    onAvisarAdminCodigoNoRegistrado: (String) -> Unit,
    onLimpiarAlertaEscaner: () -> Unit,
    onAgregarProductoManual: (ProductoEntity, Int) -> Unit,
    onModificarCantidad: (String, Int) -> Unit,
    onEliminarProducto: (String) -> Unit,
    onCancelarVenta: () -> Unit,
    onCobrar: () -> Unit,
    onCerrarVenta: () -> Unit,
    onRepetirTotal: () -> Unit,
    onAbrirLoginAdmin: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tienePermisoCamara by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val launcherPermisoCamara = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { concedido ->
        tienePermisoCamara = concedido
    }

    var mostrarModalBuscarManual by remember { mutableStateOf(false) }
    var filtroBusquedaInicial by remember { mutableStateOf("") }
    var itemEditarCantidadManual by remember { mutableStateOf<CarritoTemporalEntity?>(null) }
    var mostrarConfirmarCancelar by remember { mutableStateOf(false) }
    var buscandoQrConTimeout by remember { mutableStateOf(false) }

    val totalDelDiaAcumulado = remember(ventasDeHoy) { ventasDeHoy.sumOf { it.total } }
    val fmt = { m: Double -> CurrencyAndVoiceFormatter.formatearMoneda(m, config) }

    // Temporizador de 3 segundos cuando el vendedor activa la búsqueda focalizada de QR
    LaunchedEffect(buscandoQrConTimeout, carrito.size) {
        if (buscandoQrConTimeout) {
            delay(3000L)
            if (buscandoQrConTimeout) {
                buscandoQrConTimeout = false
                onTimeoutEscaner3Segundos()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // ==================== ENCABEZADO SUPERIOR: VENTA EN CURSO ====================
        Surface(
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "VENTA EN CURSO",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Fecha: $fechaCompleta  •  Hora: $horaExacta",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.92f)
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Botón de cambio de cámara siempre visible
                        FilledTonalButton(
                            onClick = onCambiarCamara,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("cambiar_camara_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cameraswitch,
                                contentDescription = "Cambiar cámara",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (usarCamaraFrontal) "Frontal" else "Trasera",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }

                        IconButton(
                            onClick = onAbrirLoginAdmin,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f))
                                .testTag("abrir_admin_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Administración",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Vendedor: $nombreVendedor",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "Total del día: ${fmt(totalDelDiaAcumulado)} (${ventasDeHoy.size} ventas)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        // ==================== PANEL DE ESCÁNER QR (CAMERAX + ML KIT BUNDLED) ====================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (usarCamaraFrontal) "Escáner QR Activo (Cámara Frontal)" else "Escáner QR Activo (Cámara Trasera)",
                            style = MaterialTheme.typography.titleSmall
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = {
                                onLimpiarAlertaEscaner()
                                buscandoQrConTimeout = true
                            },
                            modifier = Modifier.testTag("intentar_lectura_3s_button")
                        ) {
                            Text(if (buscandoQrConTimeout) "Leyendo (3s)..." else "Leer QR")
                        }
                        IconButton(onClick = onAlternarVisibilidadEscaner) {
                            Icon(
                                imageVector = if (escanerExpandido) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Mostrar u ocultar visor de cámara"
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = escanerExpandido) {
                    Column {
                        if (tienePermisoCamara) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(128.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                            ) {
                                OfflineQrCameraScanner(
                                    usarCamaraFrontal = usarCamaraFrontal,
                                    escaneoActivo = true,
                                    onCodigoDetectado = { codigo ->
                                        buscandoQrConTimeout = false
                                        onCodigoQrEscaneado(codigo)
                                    },
                                    onQrDanadoDetectado = {
                                        buscandoQrConTimeout = false
                                        onQrDanado()
                                    },
                                    onFalloCamaraConmutar = onConmutarCamaraPorFallo,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Surface(
                                    color = Color.Black.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(bottomEnd = 8.dp),
                                    modifier = Modifier.align(Alignment.TopStart)
                                ) {
                                    Text(
                                        text = "ML Kit Offline (<1s) • Enfoca el código QR",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Activa el permiso de cámara para escanear códigos QR con la cámara frontal o trasera.",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { launcherPermisoCamara.launch(Manifest.permission.CAMERA) },
                                    modifier = Modifier.testTag("conceder_permiso_camara_button")
                                ) {
                                    Text("Activar Cámara")
                                }
                            }
                        }

                        // Barra de simulación rápida para pruebas en Emulador / Demo
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            FilterChip(
                                selected = false,
                                onClick = {
                                    buscandoQrConTimeout = false
                                    onCodigoQrEscaneado("P001")
                                },
                                label = { Text("QR P001 (Arroz)") },
                                modifier = Modifier.testTag("scan_qr_p001_chip")
                            )
                            FilterChip(
                                selected = false,
                                onClick = {
                                    buscandoQrConTimeout = false
                                    onCodigoQrEscaneado("P002")
                                },
                                label = { Text("QR P002 (Aceite)") },
                                modifier = Modifier.testTag("scan_qr_p002_chip")
                            )
                            FilterChip(
                                selected = false,
                                onClick = {
                                    buscandoQrConTimeout = false
                                    onCodigoQrEscaneado("P003")
                                },
                                label = { Text("QR P003 (Leche)") },
                                modifier = Modifier.testTag("scan_qr_p003_chip")
                            )
                            FilterChip(
                                selected = false,
                                onClick = {
                                    buscandoQrConTimeout = false
                                    onCodigoQrEscaneado("P999")
                                },
                                label = { Text("QR No Reg. (P999)") },
                                modifier = Modifier.testTag("scan_qr_no_registrado_chip")
                            )
                            FilterChip(
                                selected = false,
                                onClick = {
                                    buscandoQrConTimeout = false
                                    onQrDanado()
                                },
                                label = { Text("QR Dañado") },
                                modifier = Modifier.testTag("scan_qr_danado_chip")
                            )
                        }
                    }
                }

                // Manejo de alertas y errores del escáner
                when (alertaEscaner) {
                    is AlertaEscaner.TimeoutLectura -> {
                        Spacer(modifier = Modifier.height(6.dp))
                        ScannerErrorBanner(
                            texto = "No se pudo leer, intenta de nuevo",
                            accionTexto = "Reintentar",
                            onAccion = {
                                onLimpiarAlertaEscaner()
                                buscandoQrConTimeout = true
                            }
                        )
                    }
                    is AlertaEscaner.CodigoIlegible -> {
                        Spacer(modifier = Modifier.height(6.dp))
                        ScannerErrorBanner(
                            texto = "Código ilegible, usa agregar manual",
                            accionTexto = "Agregar manual",
                            onAccion = {
                                onLimpiarAlertaEscaner()
                                filtroBusquedaInicial = ""
                                mostrarModalBuscarManual = true
                            }
                        )
                    }
                    is AlertaEscaner.ProductoNoRegistrado -> {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.ErrorOutline,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Producto no registrado (${alertaEscaner.codigo})",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            filtroBusquedaInicial = ""
                                            mostrarModalBuscarManual = true
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Buscar manual")
                                    }
                                    Button(
                                        onClick = { onAvisarAdminCodigoNoRegistrado(alertaEscaner.codigo) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Avisar al admin")
                                    }
                                }
                            }
                        }
                    }
                    is AlertaEscaner.ProductoEscaneadoExito -> {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "✓ Añadido: ${alertaEscaner.nombre} [${alertaEscaner.codigo}] (x${alertaEscaner.cantidadTotal})",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                TextButton(onClick = onLimpiarAlertaEscaner) {
                                    Text("OK")
                                }
                            }
                        }
                    }
                    AlertaEscaner.Ninguna -> {}
                }
            }
        }

        // ==================== LISTA DE PRODUCTOS DE LA VENTA EN CURSO ====================
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
        ) {
            if (carrito.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.AddShoppingCart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Escanea un código QR o toca \"Agregar manual\" para iniciar la venta",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(carrito, key = { it.codigo }) { item ->
                        val presentacion = if (item.gramaje != "-" && item.gramaje.isNotBlank()) item.gramaje else item.volumen
                        val subtotalLinea = item.precioUnitario * item.cantidad
                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("linea_venta_${item.codigo}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "· ${item.nombre} ${if (presentacion != "-") presentacion else ""}".trim(),
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Código: ${item.codigo}  |  Unitario: ${fmt(item.precioUnitario)}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // Control de cantidad: botones - / + y tocar la cantidad para editarla manualmente
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    IconButton(
                                        onClick = { onModificarCantidad(item.codigo, item.cantidad - 1) },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("restar_cantidad_${item.codigo}")
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Restar cantidad")
                                    }

                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .clickable { itemEditarCantidadManual = item }
                                            .testTag("editar_cantidad_${item.codigo}")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "x${item.cantidad}",
                                                style = MaterialTheme.typography.titleMedium,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = "Editar cantidad manualmente",
                                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                modifier = Modifier.size(13.dp)
                                            )
                                        }
                                    }

                                    IconButton(
                                        onClick = { onModificarCantidad(item.codigo, item.cantidad + 1) },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("sumar_cantidad_${item.codigo}")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Sumar cantidad")
                                    }
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                Text(
                                    text = fmt(subtotalLinea),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.widthIn(min = 68.dp),
                                    textAlign = TextAlign.End
                                )

                                IconButton(
                                    onClick = { onEliminarProducto(item.codigo) },
                                    modifier = Modifier.testTag("eliminar_producto_${item.codigo}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Eliminar producto",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==================== PANEL INFERIOR DE TOTAL Y BOTONES DE ACCIÓN ====================
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "Productos: ${carrito.sumOf { it.cantidad }} unid.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (config.aplicaImpuesto) {
                            Text(
                                text = "Subtotal: ${fmt(subtotalCarrito)} + Imp. (${config.porcentajeImpuesto}%): ${fmt(impuestoCarrito)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        text = "Total: ${fmt(totalCarrito)}",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.testTag("total_acumulado_text")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Fila 1 de acciones: Agregar manual, Repetir total, Cancelar venta
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            filtroBusquedaInicial = ""
                            mostrarModalBuscarManual = true
                        },
                        modifier = Modifier
                            .weight(1.1f)
                            .testTag("agregar_manual_button")
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Agregar manual", maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = onRepetirTotal,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("repetir_total_button")
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Repetir total", maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = {
                            if (carrito.isNotEmpty()) {
                                mostrarConfirmarCancelar = true
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cancelar_venta_button")
                    ) {
                        Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Cancelar venta", maxLines = 1)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Fila 2 de acciones principales: Cobrar y Cerrar venta
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onCobrar,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("cobrar_button")
                    ) {
                        Icon(Icons.Default.Payments, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Cobrar", style = MaterialTheme.typography.titleMedium)
                    }

                    Button(
                        onClick = onCerrarVenta,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("cerrar_venta_button")
                    ) {
                        Icon(Icons.Default.PointOfSale, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Cerrar venta", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }

    // Modal para agregar producto manualmente buscando por nombre o código
    if (mostrarModalBuscarManual) {
        ManualProductSearchDialog(
            catalogo = catalogo,
            config = config,
            busquedaInicial = filtroBusquedaInicial,
            onDismiss = { mostrarModalBuscarManual = false },
            onSeleccionarProducto = { producto, cant ->
                onAgregarProductoManual(producto, cant)
                mostrarModalBuscarManual = false
            }
        )
    }

    // Modal para editar manualmente la cantidad al tocar el número de unidades
    if (itemEditarCantidadManual != null) {
        val itemActual = itemEditarCantidadManual!!
        var textoCantidad by remember(itemActual) { mutableStateOf(itemActual.cantidad.toString()) }
        AlertDialog(
            onDismissRequest = { itemEditarCantidadManual = null },
            title = { Text("Modificar Cantidad: ${itemActual.nombre}") },
            text = {
                Column {
                    Text(
                        text = "Introduce la cantidad exacta de unidades para este producto:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = textoCantidad,
                        onValueChange = { textoCantidad = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Cantidad") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_cantidad_manual")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val nueva = textoCantidad.toIntOrNull() ?: 1
                        onModificarCantidad(itemActual.codigo, nueva)
                        itemEditarCantidadManual = null
                    }
                ) {
                    Text("Actualizar")
                }
            },
            dismissButton = {
                TextButton(onClick = { itemEditarCantidadManual = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    if (mostrarConfirmarCancelar) {
        AlertDialog(
            onDismissRequest = { mostrarConfirmarCancelar = false },
            title = { Text("¿Cancelar venta completa?") },
            text = { Text("Se limpiará la pantalla sin guardar ningún producto de la venta actual.") },
            confirmButton = {
                Button(
                    onClick = {
                        mostrarConfirmarCancelar = false
                        onCancelarVenta()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Sí, cancelar venta")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarConfirmarCancelar = false }) {
                    Text("Volver")
                }
            }
        )
    }
}

@Composable
private fun ScannerErrorBanner(
    texto: String,
    accionTexto: String,
    onAccion: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = texto,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            TextButton(onClick = onAccion) {
                Text(accionTexto)
            }
        }
    }
}

/**
 * Pantalla grande de RESUMEN DE COMPRA al tocar "Cobrar".
 * Permanece visible hasta que el vendedor seleccione método de pago y toque "Cerrar venta".
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CheckoutModalScreen(
    config: ConfiguracionNegocioEntity,
    fechaCompleta: String,
    horaCobro: String,
    nombreVendedor: String,
    carrito: List<CarritoTemporalEntity>,
    subtotal: Double,
    impuesto: Double,
    totalAPagar: Double,
    metodoPagoSeleccionado: String,
    onSeleccionarMetodoPago: (String) -> Unit,
    onRepetirTotalPorVoz: () -> Unit,
    onCerrarVentaDefinitiva: () -> Unit,
    onVolverAVentaEnCurso: () -> Unit
) {
    BackHandler {
        onVolverAVentaEnCurso()
    }

    val fmt = { m: Double -> CurrencyAndVoiceFormatter.formatearMoneda(m, config) }
    val fraseVoz = remember(totalAPagar, config) {
        CurrencyAndVoiceFormatter.construirFraseTotalPorVoz(totalAPagar, config)
    }
    val metodosPago = listOf("Efectivo", "Transferencia", "Tarjeta", "Crédito")

    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 600.dp)
            ) {
                // Encabezado en grande: RESUMEN DE COMPRA
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "RESUMEN DE COMPRA",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Fecha: $fechaCompleta  •  Hora: $horaCobro",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Vendedor: $nombreVendedor",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Lista clara de productos comprados
                ElevatedCard(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(carrito, key = { it.codigo }) { item ->
                            val pres = if (item.gramaje != "-" && item.gramaje.isNotBlank()) item.gramaje else item.volumen
                            val sub = item.precioUnitario * item.cantidad
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "· ${item.nombre} ${if (pres != "-") pres else ""}".trim(),
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "x${item.cantidad}",
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(horizontal = 14.dp)
                                )
                                Text(
                                    text = fmt(sub),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            HorizontalDivider()
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bloque de TOTAL A PAGAR en grande + Voz
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (config.aplicaImpuesto) {
                            Text(
                                text = "Subtotal: ${fmt(subtotal)}  |  Impuestos (${config.porcentajeImpuesto}%): ${fmt(impuesto)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        Text(
                            text = "TOTAL A PAGAR: ${fmt(totalAPagar)}",
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.testTag("resumen_total_a_pagar_text")
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "🔊 \"$fraseVoz\"",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Selector obligatorio de método de pago
                Text(
                    text = "Selecciona el método de pago (obligatorio):",
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    metodosPago.forEach { metodo ->
                        val seleccionado = metodoPagoSeleccionado == metodo
                        FilterChip(
                            selected = seleccionado,
                            onClick = { onSeleccionarMetodoPago(metodo) },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (seleccionado) Icons.Default.CheckCircle else Icons.Default.CreditCard,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = metodo,
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            },
                            modifier = Modifier.testTag("metodo_pago_${metodo.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Botones: Repetir total, Volver y Cerrar venta
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onVolverAVentaEnCurso,
                        modifier = Modifier.weight(0.8f).height(52.dp)
                    ) {
                        Text("Seguir editando")
                    }

                    OutlinedButton(
                        onClick = onRepetirTotalPorVoz,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("checkout_repetir_total_button")
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Repetir total")
                    }

                    Button(
                        onClick = onCerrarVentaDefinitiva,
                        enabled = metodoPagoSeleccionado.isNotBlank(),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(52.dp)
                            .testTag("checkout_cerrar_venta_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cerrar venta")
                    }
                }
            }
        }
    }
}

@Composable
fun ManualProductSearchDialog(
    catalogo: List<ProductoEntity>,
    config: ConfiguracionNegocioEntity,
    busquedaInicial: String = "",
    onDismiss: () -> Unit,
    onSeleccionarProducto: (ProductoEntity, Int) -> Unit
) {
    var consulta by remember { mutableStateOf(busquedaInicial) }
    var cantidadTexto by remember { mutableStateOf("1") }
    val fmt = { m: Double -> CurrencyAndVoiceFormatter.formatearMoneda(m, config) }

    val filtrados = remember(catalogo, consulta) {
        if (consulta.isBlank()) {
            catalogo
        } else {
            val q = consulta.trim().lowercase()
            catalogo.filter {
                it.codigo.lowercase().contains(q) || it.nombre.lowercase().contains(q)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agregar Producto Manualmente") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = consulta,
                    onValueChange = { consulta = it },
                    label = { Text("Buscar por nombre o código (ej. P001, Arroz)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("buscar_producto_manual_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = cantidadTexto,
                    onValueChange = { cantidadTexto = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Cantidad a agregar") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                Box(modifier = Modifier.height(260.dp)) {
                    if (filtrados.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No se encontraron productos con esa búsqueda.")
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(filtrados, key = { it.codigo }) { prod ->
                                val pres = if (prod.gramaje != "-") prod.gramaje else prod.volumen
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val cant = cantidadTexto.toIntOrNull()?.coerceAtLeast(1) ?: 1
                                            onSeleccionarProducto(prod, cant)
                                        }
                                        .testTag("seleccionar_manual_${prod.codigo}")
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${prod.codigo} • ${prod.nombre}",
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text(
                                                text = "Presentación: $pres",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(
                                            text = fmt(prod.precio_actual),
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar")
            }
        }
    )
}

@Composable
fun RecoverInterruptedSaleDialog(
    carritoPendiente: List<CarritoTemporalEntity>,
    config: ConfiguracionNegocioEntity?,
    onResponder: (Boolean) -> Unit
) {
    val total = carritoPendiente.sumOf { it.precioUnitario * it.cantidad }
    val fmt = CurrencyAndVoiceFormatter.formatearMoneda(total, config)

    AlertDialog(
        onDismissRequest = {},
        icon = {
            Icon(
                imageVector = Icons.Default.Restore,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = { Text("¿Recuperar venta anterior?") },
        text = {
            Column {
                Text(
                    text = "Se detectó una venta en curso que no fue cerrada antes de salir (${carritoPendiente.sumOf { it.cantidad }} productos • Subtotal: $fmt).",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "¿Deseas restaurar la venta en curso o descartarla?",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onResponder(true) },
                modifier = Modifier.testTag("recuperar_venta_si_button")
            ) {
                Text("Sí, recuperar")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = { onResponder(false) },
                modifier = Modifier.testTag("recuperar_venta_no_button")
            ) {
                Text("No, descartar")
            }
        }
    )
}
