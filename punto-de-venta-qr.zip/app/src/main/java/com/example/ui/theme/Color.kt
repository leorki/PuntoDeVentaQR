package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta Comercial de Alto Contraste "Punto de Venta QR" (Esmeralda Industrial, Ámbar y Pizarra)
val EmeraldPrimary = Color(0xFF047857)
val EmeraldDark = Color(0xFF064E3B)
val EmeraldLight = Color(0xFFD1FAE5)
val EmeraldAccent = Color(0xFF10B981)

val AmberSecondary = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)
val AmberOnContainer = Color(0xFF78350F)

val SlateBackground = Color(0xFFF8FAFC)
val SlateSurface = Color(0xFFFFFFFF)
val SlateSurfaceVariant = Color(0xFFF1F5F9)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF475569)
val SlateOutline = Color(0xFFCBD5E1)

val ErrorRed = Color(0xFFDC2626)
val ErrorContainerLight = Color(0xFFFEE2E2)
val WarningOrange = Color(0xFFEA580C)
val SuccessGreen = Color(0xFF16A34A)
val InfoBlue = Color(0xFF0284C7)

// Modo Oscuro
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val EmeraldDarkThemePrimary = Color(0xFF34D399)
val AmberDarkThemeSecondary = Color(0xFFFBBF24)
