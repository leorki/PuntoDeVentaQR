package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.ConfiguracionNegocioEntity
import com.example.data.local.HistoricoPrecioEntity
import com.example.data.local.ProductoEntity
import com.example.data.local.RegistroCambioEntity
import com.example.util.CurrencyAndVoiceFormatter
import com.example.util.QrCodeBitmapGenerator

@Composable
fun AdminLoginAndRecoveryDialog(
    config: ConfiguracionNegocioEntity,
    onDismiss: () -> Unit,
    onIntentarLogin: (String) -> Boolean,
    onRecuperarConPregunta: (String, String) -> Boolean,
    onRecuperarConCodigoMaestro: (String, String) -> Boolean,
    onLoginExitoso: () -> Unit
) {
    var modoRecuperacion by remember { mutableStateOf(false) }
    var usarCodigoMaestro by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }
    var respuestaInput by remember { mutableStateOf("") }
    var codigoMaestroInput by remember { mutableStateOf("") }
    var nuevaPasswordInput by remember { mutableStateOf("") }
    var mensajeError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text(
                if (!modoRecuperacion) "Acceso de Administrador (Dueño)"
                else "Recuperar Contraseña de Administrador"
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (!modoRecuperacion) {
                    Text(
                        text = "Introduce la contraseña del dueño para acceder al catálogo, reportes PDF, arqueo de caja y configuración.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            mensajeError = null
                        },
                        label = { Text("Contraseña de Administrador") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_login_password_input")
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    TextButton(
                        onClick = {
                            modoRecuperacion = true
                            mensajeError = null
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("¿Olvidaste tu contraseña?")
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !usarCodigoMaestro,
                            onClick = { usarCodigoMaestro = false },
                            label = { Text("Pregunta de Seguridad") }
                        )
                        FilterChip(
                            selected = usarCodigoMaestro,
                            onClick = { usarCodigoMaestro = true },
                            label = { Text("Código Maestro") }
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (!usarCodigoMaestro) {
                        Text(
                            text = "Pregunta: ${config.preguntaSeguridad}",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = respuestaInput,
                            onValueChange = { respuestaInput = it },
                            label = { Text("Tu respuesta") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        OutlinedTextField(
                            value = codigoMaestroInput,
                            onValueChange = { codigoMaestroInput = it },
                            label = { Text("Código Maestro (MSTR-XXXX-XXXX)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nuevaPasswordInput,
                        onValueChange = { nuevaPasswordInput = it },
                        label = { Text("Nueva contraseña (mín. 4 caracteres)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (mensajeError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = mensajeError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!modoRecuperacion) {
                        if (onIntentarLogin(passwordInput)) {
                            onLoginExitoso()
                        } else {
                            mensajeError = "Contraseña incorrecta."
                        }
                    } else {
                        val exito = if (!usarCodigoMaestro) {
                            onRecuperarConPregunta(respuestaInput, nuevaPasswordInput)
                        } else {
                            onRecuperarConCodigoMaestro(codigoMaestroInput, nuevaPasswordInput)
                        }
                        if (exito) {
                            onIntentarLogin(nuevaPasswordInput)
                            onLoginExitoso()
                        } else {
                            mensajeError = "Datos de recuperación incorrectos o contraseña menor a 4 caracteres."
                        }
                    }
                },
                modifier = Modifier.testTag("admin_login_confirm_button")
            ) {
                Text(if (!modoRecuperacion) "Ingresar" else "Restablecer e Ingresar")
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    if (modoRecuperacion) {
                        modoRecuperacion = false
                        mensajeError = null
                    } else {
                        onDismiss()
                    }
                }
            ) {
                Text(if (modoRecuperacion) "Volver" else "Cancelar")
            }
        }
    )
}

@Composable
fun AdminCatalogScreen(
    config: ConfiguracionNegocioEntity,
    productos: List<ProductoEntity>,
    historicoPrecios: List<HistoricoPrecioEntity>,
    registroCambios: List<RegistroCambioEntity>,
    fechaHoyIso: String,
    onActividadAdmin: () -> Unit,
    onGuardarProducto: (Boolean, String, String, String, String, String, Double, (Boolean, String) -> Unit) -> Unit,
    onEliminarProducto: (ProductoEntity) -> Unit,
    onImportarArchivoUri: (Uri) -> Unit,
    onExportarCatalogoExcel: () -> Unit
) {
    var tabSeleccionada by remember { mutableIntStateOf(0) }
    var filtroBusqueda by remember { mutableStateOf("") }

    var mostrarModalEditor by remember { mutableStateOf(false) }
    var esCreacionNueva by remember { mutableStateOf(true) }
    var productoEditando by remember { mutableStateOf<ProductoEntity?>(null) }
    var codigoPrefill by remember { mutableStateOf("") }

    val launcherImportar = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportarArchivoUri(uri)
        }
    }

    val fmt = { m: Double -> CurrencyAndVoiceFormatter.formatearMoneda(m, config) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        TabRow(selectedTabIndex = tabSeleccionada) {
            Tab(
                selected = tabSeleccionada == 0,
                onClick = {
                    onActividadAdmin()
                    tabSeleccionada = 0
                },
                text = { Text("Catálogo (${productos.size})") },
                icon = { Icon(Icons.Default.Inventory, contentDescription = null) }
            )
            Tab(
                selected = tabSeleccionada == 1,
                onClick = {
                    onActividadAdmin()
                    tabSeleccionada = 1
                },
                text = { Text("Histórico Precios (${historicoPrecios.size})") },
                icon = { Icon(Icons.Default.History, contentDescription = null) }
            )
            Tab(
                selected = tabSeleccionada == 2,
                onClick = {
                    onActividadAdmin()
                    tabSeleccionada = 2
                },
                text = { Text("Auditoría (${registroCambios.size})") }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (tabSeleccionada) {
            0 -> {
                // Barra de herramientas del catálogo
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = filtroBusqueda,
                        onValueChange = {
                            onActividadAdmin()
                            filtroBusqueda = it
                        },
                        label = { Text("Filtrar código o nombre") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            onActividadAdmin()
                            esCreacionNueva = true
                            productoEditando = null
                            codigoPrefill = "P%03d".format(productos.size + 1)
                            mostrarModalEditor = true
                        },
                        modifier = Modifier.testTag("nuevo_producto_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Nuevo")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onActividadAdmin()
                            launcherImportar.launch(arrayOf("*/*"))
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Importar Excel/CSV")
                    }
                    OutlinedButton(
                        onClick = {
                            onActividadAdmin()
                            onExportarCatalogoExcel()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Exportar Excel (.xls)")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Encabezado exacto de columnas de la tabla productos
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Columnas: codigo | nombre | gramaje | volumen | fecha_ultimo_cambio | precio_actual",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val listaFiltrada = remember(productos, filtroBusqueda) {
                    if (filtroBusqueda.isBlank()) productos
                    else {
                        val q = filtroBusqueda.trim().lowercase()
                        productos.filter {
                            it.codigo.lowercase().contains(q) || it.nombre.lowercase().contains(q)
                        }
                    }
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(listaFiltrada, key = { it.codigo }) { prod ->
                        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${prod.codigo}  |  ${prod.nombre}",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "gramaje: ${prod.gramaje}  |  volumen: ${prod.volumen}  |  fecha_ultimo_cambio: ${prod.fecha_ultimo_cambio}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = fmt(prod.precio_actual),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                IconButton(
                                    onClick = {
                                        onActividadAdmin()
                                        esCreacionNueva = false
                                        productoEditando = prod
                                        codigoPrefill = prod.codigo
                                        mostrarModalEditor = true
                                    },
                                    modifier = Modifier.testTag("editar_producto_${prod.codigo}")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Editar producto")
                                }
                                IconButton(
                                    onClick = {
                                        onActividadAdmin()
                                        onEliminarProducto(prod)
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Eliminar producto",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Tabla aparte: Histórico de precios (codigo | nombre | precio_anterior | precio_nuevo | fecha_cambio)
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Tabla Histórico: codigo | nombre | precio_anterior | precio_nuevo | fecha_cambio",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                if (historicoPrecios.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Aún no se han registrado cambios de precio en el catálogo.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(historicoPrecios, key = { it.id }) { hist ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${hist.codigo} | ${hist.nombre}",
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = "fecha_cambio: ${hist.fecha_cambio}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "Anterior: ${fmt(hist.precio_anterior)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "Nuevo: ${fmt(hist.precio_nuevo)}",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Registro de auditoría de cambios y avisos del vendedor
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(registroCambios, key = { it.id }) { reg ->
                        val esAlertaVendedor = reg.tipo == "ALERTA_VENDEDOR"
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (esAlertaVendedor) MaterialTheme.colorScheme.errorContainer
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "[${reg.tipo}] Código: ${reg.codigoProducto}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (esAlertaVendedor) MaterialTheme.colorScheme.onErrorContainer
                                        else MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "${reg.fecha} ${reg.hora}",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = reg.detalle,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (esAlertaVendedor) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Button(
                                        onClick = {
                                            esCreacionNueva = true
                                            productoEditando = null
                                            codigoPrefill = reg.codigoProducto
                                            mostrarModalEditor = true
                                        }
                                    ) {
                                        Text("Crear producto ${reg.codigoProducto} ahora")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (mostrarModalEditor) {
        var codigo by remember { mutableStateOf(productoEditando?.codigo ?: codigoPrefill) }
        var nombre by remember { mutableStateOf(productoEditando?.nombre ?: "") }
        var gramaje by remember { mutableStateOf(productoEditando?.gramaje ?: "-") }
        var volumen by remember { mutableStateOf(productoEditando?.volumen ?: "-") }
        var precioTexto by remember { mutableStateOf(productoEditando?.precio_actual?.toString() ?: "") }
        var errorLocal by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { mostrarModalEditor = false },
            title = {
                Text(if (esCreacionNueva) "Nuevo Producto del Catálogo" else "Editar Producto ${productoEditando?.codigo}")
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = codigo,
                        onValueChange = {
                            codigo = it.uppercase()
                            errorLocal = null
                        },
                        label = { Text("codigo (ej. P001) *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_producto_codigo")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nombre,
                        onValueChange = { nombre = it },
                        label = { Text("nombre (ej. Arroz) *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_producto_nombre")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = gramaje,
                            onValueChange = { gramaje = it },
                            label = { Text("gramaje (ej. 1kg o -)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = volumen,
                            onValueChange = { volumen = it },
                            label = { Text("volumen (ej. 1L o -)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = precioTexto,
                        onValueChange = {
                            precioTexto = it
                            errorLocal = null
                        },
                        label = { Text("precio_actual *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_producto_precio")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = productoEditando?.fecha_ultimo_cambio ?: fechaHoyIso,
                        onValueChange = {},
                        enabled = false,
                        label = { Text("fecha_ultimo_cambio (Automática, no editable a mano)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (errorLocal != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorLocal!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val precio = precioTexto.replace(",", ".").toDoubleOrNull() ?: 0.0
                        onGuardarProducto(
                            esCreacionNueva,
                            productoEditando?.codigo ?: "",
                            codigo,
                            nombre,
                            gramaje,
                            volumen,
                            precio
                        ) { exito, msg ->
                            if (exito) {
                                mostrarModalEditor = false
                            } else {
                                errorLocal = msg
                            }
                        }
                    },
                    modifier = Modifier.testTag("guardar_producto_catalogo_button")
                ) {
                    Text("Guardar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalEditor = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun AdminQrGeneratorScreen(
    productos: List<ProductoEntity>,
    onActividadAdmin: () -> Unit,
    onExportarOImprimirQr: (List<ProductoEntity>, Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "GENERADOR DE ETIQUETAS QR DEL CATÁLOGO",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = "Regla estricta: El código QR generado contiene ÚNICAMENTE el código del producto (ej. P001). No lleva nombre, ni precio, ni gramaje dentro del QR.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onActividadAdmin()
                            onExportarOImprimirQr(productos, false)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("generar_todos_qr_pdf_button")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Todos los QR en 1 PDF")
                    }
                    OutlinedButton(
                        onClick = {
                            onActividadAdmin()
                            onExportarOImprimirQr(productos, true)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Imprimir Catálogo QR")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(productos, key = { it.codigo }) { prod ->
                val qrBitmap = remember(prod.codigo) {
                    QrCodeBitmapGenerator.generarQrSoloCodigo(prod.codigo, 220)
                }
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "QR ${prod.codigo}",
                            modifier = Modifier
                                .size(76.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                .background(androidx.compose.ui.graphics.Color.White)
                                .padding(4.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Contenido QR: \"${prod.codigo}\"",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Referencia catálogo: ${prod.nombre}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row {
                            IconButton(
                                onClick = {
                                    onActividadAdmin()
                                    onExportarOImprimirQr(listOf(prod), false)
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = "Exportar QR a PDF",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(
                                onClick = {
                                    onActividadAdmin()
                                    onExportarOImprimirQr(listOf(prod), true)
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Print,
                                    contentDescription = "Imprimir etiqueta QR",
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
