package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.local.CierreDiarioEntity
import com.example.data.local.ConfiguracionNegocioEntity
import com.example.data.local.DetalleVentaEntity
import com.example.data.local.JornadaActivaEntity
import com.example.data.local.VentaEntity
import com.example.util.CurrencyAndVoiceFormatter
import com.example.util.PdfAndExcelExporter
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun AdminDailySummaryScreen(
    config: ConfiguracionNegocioEntity,
    jornada: JornadaActivaEntity?,
    ventasHoy: List<VentaEntity>,
    historialDiario: List<CierreDiarioEntity>,
    fechaHoyIso: String,
    fechaHoyMostrar: String,
    onActividadAdmin: () -> Unit,
    onGenerarYSellarResumenDelDia: (Double, String, (File, CierreDiarioEntity) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val fmt = { m: Double -> CurrencyAndVoiceFormatter.formatearMoneda(m, config) }

    val totalVendido = remember(ventasHoy) { ventasHoy.sumOf { it.total } }
    val clientesAtendidos = ventasHoy.size
    val ticketPromedio = if (clientesAtendidos > 0) totalVendido / clientesAtendidos else 0.0

    val totalEfectivoEsperado = remember(ventasHoy) {
        ventasHoy.filter { it.metodoPago.equals("Efectivo", true) }.sumOf { it.total }
    }
    val totalTransferencia = remember(ventasHoy) {
        ventasHoy.filter { it.metodoPago.equals("Transferencia", true) }.sumOf { it.total }
    }
    val totalTarjeta = remember(ventasHoy) {
        ventasHoy.filter { it.metodoPago.equals("Tarjeta", true) }.sumOf { it.total }
    }
    val totalCredito = remember(ventasHoy) {
        ventasHoy.filter { it.metodoPago.contains("Cr", true) }.sumOf { it.total }
    }

    val cierreHoyExistente = remember(historialDiario, fechaHoyIso) {
        historialDiario.find { it.fechaIso == fechaHoyIso }
    }

    var efectivoContadoTexto by remember(totalEfectivoEsperado, cierreHoyExistente) {
        mutableStateOf(
            cierreHoyExistente?.efectivoContado?.toString()
                ?: String.format(Locale.US, "%.2f", totalEfectivoEsperado)
        )
    }
    var observacionesTexto by remember(cierreHoyExistente) {
        mutableStateOf(cierreHoyExistente?.observaciones ?: "")
    }
    var archivoPdfGenerado by remember { mutableStateOf<File?>(null) }

    val efectivoContadoVal = efectivoContadoTexto.replace(",", ".").toDoubleOrNull() ?: 0.0
    val diferenciaCalculada = efectivoContadoVal - totalEfectivoEsperado
    val saldoFinalCalculado = efectivoContadoVal + totalTransferencia + totalTarjeta + totalCredito

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Encabezado del día
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "RESUMEN DEL DÍA Y CIERRE DE CAJA ($fechaHoyMostrar)",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = "Vendedor: ${jornada?.nombreVendedor ?: "Sin iniciar"}  |  Apertura: ${jornada?.horaApertura ?: "--:--:--"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                if (cierreHoyExistente != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "✓ Este día ya fue sellado de forma inmutable a las ${cierreHoyExistente.horaCierre}.",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Resumen General y Desglose por Método de Pago
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("1. Resumen General de Ventas Hoy", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Total Vendido", style = MaterialTheme.typography.labelMedium)
                        Text(
                            text = fmt(totalVendido),
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Clientes (Ventas)", style = MaterialTheme.typography.labelMedium)
                        Text(
                            text = "$clientesAtendidos",
                            style = MaterialTheme.typography.headlineSmall
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Ticket Promedio", style = MaterialTheme.typography.labelMedium)
                        Text(
                            text = fmt(ticketPromedio),
                            style = MaterialTheme.typography.headlineSmall
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(8.dp))
                Text("Desglose por Método de Pago:", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("• Efectivo: ${fmt(totalEfectivoEsperado)}", style = MaterialTheme.typography.bodyMedium)
                    Text("• Transferencia: ${fmt(totalTransferencia)}", style = MaterialTheme.typography.bodyMedium)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("• Tarjeta: ${fmt(totalTarjeta)}", style = MaterialTheme.typography.bodyMedium)
                    Text("• Crédito: ${fmt(totalCredito)}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        // Arqueo de Caja: Efectivo contado físicamente + Observaciones
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "2. Arqueo y Cierre de Caja (Requerido antes del PDF)",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Efectivo esperado según ventas en efectivo: ${fmt(totalEfectivoEsperado)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = efectivoContadoTexto,
                    onValueChange = {
                        onActividadAdmin()
                        efectivoContadoTexto = it
                    },
                    label = { Text("Efectivo contado físicamente en caja *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("efectivo_contado_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = observacionesTexto,
                    onValueChange = {
                        onActividadAdmin()
                        observacionesTexto = it
                    },
                    label = { Text("Observaciones del cierre (opcional)") },
                    placeholder = { Text("Ej. Cierre conforme sin novedades") },
                    minLines = 2,
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("observaciones_cierre_input")
                )

                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        val etiquetaDif = when {
                            kotlin.math.abs(diferenciaCalculada) < 0.005 -> "CUADRE EXACTO (${fmt(0.0)})"
                            diferenciaCalculada > 0 -> "SOBRANTE (+${fmt(diferenciaCalculada)})"
                            else -> "FALTANTE (${fmt(diferenciaCalculada)})"
                        }
                        Text(
                            text = "Diferencia calculada: $etiquetaDif",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "Saldo Final Total del Día: ${fmt(saldoFinalCalculado)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        onGenerarYSellarResumenDelDia(efectivoContadoVal, observacionesTexto) { pdfFile, _ ->
                            archivoPdfGenerado = pdfFile
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("resumen_del_dia_button")
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Resumen del día (Sellar y Generar PDF)")
                }

                if (archivoPdfGenerado != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                PdfAndExcelExporter.abrirOCompartirArchivo(
                                    context,
                                    archivoPdfGenerado!!,
                                    "application/pdf"
                                )
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Abrir / Exportar PDF")
                        }
                        OutlinedButton(
                            onClick = {
                                PdfAndExcelExporter.imprimirArchivoPdf(
                                    context,
                                    archivoPdfGenerado!!,
                                    "Resumen del Dia $fechaHoyIso"
                                )
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Imprimir PDF")
                        }
                    }
                }
            }
        }

        // Detalle de ventas individuales de hoy
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("3. Detalle por Venta Hoy (${ventasHoy.size} clientes)", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                if (ventasHoy.isEmpty()) {
                    Text(
                        text = "Aún no hay ventas cerradas hoy.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    ventasHoy.forEachIndexed { idx, v ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Cliente #${idx + 1} • Hora: ${v.hora} • ${v.metodoPago}",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = v.resumenItems,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = fmt(v.total),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AdminHistoryByDateScreen(
    config: ConfiguracionNegocioEntity,
    historialDiario: List<CierreDiarioEntity>,
    fechaHoyIso: String,
    onActividadAdmin: () -> Unit,
    onConsultarFecha: (String, (CierreDiarioEntity?, List<VentaEntity>, List<DetalleVentaEntity>) -> Unit) -> Unit,
    onExportarOImprimirPdfFecha: (String, Boolean) -> Unit
) {
    var fechaSeleccionadaIso by remember { mutableStateOf(fechaHoyIso) }
    var mostrarCalendario by remember { mutableStateOf(false) }

    var cierreConsultado by remember { mutableStateOf<CierreDiarioEntity?>(null) }
    var ventasConsultadas by remember { mutableStateOf<List<VentaEntity>>(emptyList()) }
    var detallesConsultados by remember { mutableStateOf<List<DetalleVentaEntity>>(emptyList()) }

    val fmt = { m: Double -> CurrencyAndVoiceFormatter.formatearMoneda(m, config) }

    LaunchedEffect(fechaSeleccionadaIso) {
        onConsultarFecha(fechaSeleccionadaIso) { cierre, ventas, detalles ->
            cierreConsultado = cierre
            ventasConsultadas = ventas
            detallesConsultados = detalles
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "HISTORIAL DIARIO INMUTABLE",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Fecha consultada: $fechaSeleccionadaIso",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Button(
                        onClick = {
                            onActividadAdmin()
                            mostrarCalendario = true
                        },
                        modifier = Modifier.testTag("buscar_por_fecha_button")
                    ) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Buscar por fecha")
                    }
                }

                if (historialDiario.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Días sellados en el historial:",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        historialDiario.forEach { registro ->
                            FilterChip(
                                selected = fechaSeleccionadaIso == registro.fechaIso,
                                onClick = {
                                    onActividadAdmin()
                                    fechaSeleccionadaIso = registro.fechaIso
                                },
                                label = { Text("${registro.fechaMostrar} (${fmt(registro.totalVendido)})") }
                            )
                        }
                    }
                }
            }
        }

        // Resumen completo en pantalla del día elegido
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Resumen del Día: $fechaSeleccionadaIso",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(8.dp))

                val totalDia = cierreConsultado?.totalVendido ?: ventasConsultadas.sumOf { it.total }
                val vendedorDia = cierreConsultado?.vendedor ?: ventasConsultadas.firstOrNull()?.vendedor ?: "Sin ventas registradas"

                Text("Vendedor: $vendedorDia", style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = "Total Vendido: ${fmt(totalDia)}  |  Ventas: ${ventasConsultadas.size}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                if (cierreConsultado != null) {
                    val c = cierreConsultado!!
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Horario: ${c.horaApertura} a ${c.horaCierre}  |  Efectivo Contado: ${fmt(c.efectivoContado)}  |  Diferencia: ${fmt(c.diferenciaCaja)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (c.productosVendidosResumen.isNotBlank()) {
                        Text(
                            text = "Productos vendidos: ${c.productosVendidosResumen}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onExportarOImprimirPdfFecha(fechaSeleccionadaIso, false) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Exportar PDF del Día")
                    }
                    OutlinedButton(
                        onClick = { onExportarOImprimirPdfFecha(fechaSeleccionadaIso, true) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Imprimir PDF Original")
                    }
                }

                if (ventasConsultadas.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Ventas registradas en esta fecha:", style = MaterialTheme.typography.titleSmall)
                    ventasConsultadas.forEachIndexed { idx, v ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "#${idx + 1} [${v.hora}] ${v.metodoPago} - ${v.resumenItems}",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = fmt(v.total),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }

    if (mostrarCalendario) {
        val datePickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { mostrarCalendario = false },
            confirmButton = {
                Button(
                    onClick = {
                        val millis = datePickerState.selectedDateMillis
                        if (millis != null) {
                            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                                timeZone = TimeZone.getTimeZone("UTC")
                            }
                            fechaSeleccionadaIso = sdf.format(Date(millis))
                        }
                        mostrarCalendario = false
                    }
                ) {
                    Text("Seleccionar Fecha")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarCalendario = false }) {
                    Text("Cancelar")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminBackupAndSettingsScreen(
    config: ConfiguracionNegocioEntity,
    ultimoArchivoGenerado: File?,
    onActividadAdmin: () -> Unit,
    onExportarTodoZip: () -> Unit,
    onExportarVentasExcel: () -> Unit,
    onActualizarConfiguracion: (ConfiguracionNegocioEntity) -> Unit,
    onProbarVoz: () -> Unit,
    onCambiarPassword: (String, String, (Boolean, String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val tieneSd = remember { PdfAndExcelExporter.tieneTarjetaSdDisponible(context) }

    var nombreNegocio by remember(config) { mutableStateOf(config.nombreNegocio) }
    var nombreDueno by remember(config) { mutableStateOf(config.nombreDueno) }
    var direccion by remember(config) { mutableStateOf(config.direccion) }
    var telefono by remember(config) { mutableStateOf(config.telefono) }
    var correo by remember(config) { mutableStateOf(config.correo) }
    var monedaPresetSeleccionada by remember(config) {
        mutableStateOf(
            CurrencyAndVoiceFormatter.MONEDAS_PREDEFINIDAS.find { it.codigo == config.monedaCodigo }
                ?: CurrencyAndVoiceFormatter.MONEDAS_PREDEFINIDAS.first()
        )
    }
    var aplicaImpuesto by remember(config) { mutableStateOf(config.aplicaImpuesto) }
    var porcentajeImpuesto by remember(config) { mutableStateOf(config.porcentajeImpuesto.toString()) }
    var volumenVoz by remember(config) { mutableFloatStateOf(config.volumenVoz) }
    var almacenamiento by remember(config) { mutableStateOf(config.almacenamientoExportacion) }
    var respaldoCorreoNocturno by remember(config) { mutableStateOf(config.respaldoNocturnoCorreo) }

    var passActual by remember { mutableStateOf("") }
    var passNueva by remember { mutableStateOf("") }
    var mensajePassword by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Guardado y Respaldo ("Exportar todo" a SD o PC)
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SdCard, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("1. Guardado, Almacenamiento y Respaldo Total", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Base de datos SQLite: Siempre protegida en memoria interna.\n• PDFs y Excels: Memoria Interna o Tarjeta Micro SD (${if (tieneSd) "Micro SD detectada" else "Usando almacenamiento del dispositivo"}).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(
                        selected = almacenamiento == "INTERNO",
                        onClick = {
                            onActividadAdmin()
                            almacenamiento = "INTERNO"
                            onActualizarConfiguracion(config.copy(almacenamientoExportacion = "INTERNO"))
                        },
                        label = { Text("Memoria Interna") }
                    )
                    FilterChip(
                        selected = almacenamiento == "SD",
                        onClick = {
                            onActividadAdmin()
                            almacenamiento = "SD"
                            onActualizarConfiguracion(config.copy(almacenamientoExportacion = "SD"))
                        },
                        label = { Text("Tarjeta Micro SD") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Respaldo automático nocturno por correo", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "Envía el PDF del cierre diario y el logo a ${config.correo}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = respaldoCorreoNocturno,
                        onCheckedChange = {
                            onActividadAdmin()
                            respaldoCorreoNocturno = it
                            onActualizarConfiguracion(config.copy(respaldoNocturnoCorreo = it))
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onExportarTodoZip,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("exportar_todo_button")
                ) {
                    Icon(Icons.Default.Archive, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Exportar todo (ZIP: SQLite + PDFs + Excels + Logo)")
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onExportarVentasExcel,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.TableView, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Exportar Historial de Ventas a Excel (.xls Apache POI)")
                }
            }
        }

        // 2. Configuración de Voz (Volumen ajustable solo por admin) y Datos del Negocio
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("2. Configuración del Negocio, Moneda y Voz (TTS)", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))

                Text("Volumen de la voz al cobrar: ${(volumenVoz * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Slider(
                        value = volumenVoz,
                        onValueChange = {
                            onActividadAdmin()
                            volumenVoz = it
                        },
                        valueRange = 0.1f..1.0f,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(onClick = onProbarVoz) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Probar")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = nombreNegocio,
                    onValueChange = { nombreNegocio = it },
                    label = { Text("Nombre del negocio") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = nombreDueno,
                    onValueChange = { nombreDueno = it },
                    label = { Text("Nombre del dueño") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = direccion,
                    onValueChange = { direccion = it },
                    label = { Text("Dirección") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = telefono,
                        onValueChange = { telefono = it },
                        label = { Text("Teléfono") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = correo,
                        onValueChange = { correo = it },
                        label = { Text("Correo") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Moneda del negocio (6 opciones):", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CurrencyAndVoiceFormatter.MONEDAS_PREDEFINIDAS.forEach { preset ->
                        FilterChip(
                            selected = monedaPresetSeleccionada.codigo == preset.codigo,
                            onClick = {
                                onActividadAdmin()
                                monedaPresetSeleccionada = preset
                            },
                            label = { Text("${preset.nombreMostrar} (${preset.ejemplo})") }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = porcentajeImpuesto,
                    onValueChange = { porcentajeImpuesto = it },
                    label = { Text("Impuesto (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        val impVal = porcentajeImpuesto.replace(",", ".").toDoubleOrNull() ?: 0.0
                        onActualizarConfiguracion(
                            config.copy(
                                nombreNegocio = nombreNegocio.trim(),
                                nombreDueno = nombreDueno.trim(),
                                direccion = direccion.trim(),
                                telefono = telefono.trim(),
                                correo = correo.trim(),
                                monedaCodigo = monedaPresetSeleccionada.codigo,
                                monedaSimbolo = monedaPresetSeleccionada.simbolo,
                                simboloAntes = monedaPresetSeleccionada.simboloAntes,
                                separadorMiles = monedaPresetSeleccionada.separadorMiles,
                                separadorDecimales = monedaPresetSeleccionada.separadorDecimales,
                                monedaVozSingular = monedaPresetSeleccionada.vozSingular,
                                monedaVozPlural = monedaPresetSeleccionada.vozPlural,
                                centavosVoz = monedaPresetSeleccionada.centavosVoz,
                                aplicaImpuesto = impVal > 0.0,
                                porcentajeImpuesto = impVal,
                                volumenVoz = volumenVoz,
                                almacenamientoExportacion = almacenamiento,
                                respaldoNocturnoCorreo = respaldoCorreoNocturno
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Guardar Cambios de Configuración")
                }
            }
        }

        // 3. Cambiar Contraseña de Administrador
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("3. Cambiar Contraseña de Administrador", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = passActual,
                        onValueChange = { passActual = it },
                        label = { Text("Contraseña actual") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = passNueva,
                        onValueChange = { passNueva = it },
                        label = { Text("Nueva contraseña") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (mensajePassword != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = mensajePassword!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        onCambiarPassword(passActual, passNueva) { exito, msg ->
                            mensajePassword = msg
                            if (exito) {
                                passActual = ""
                                passNueva = ""
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Actualizar Contraseña")
                }
            }
        }

        // 4. Información de Versión y Estado Offline
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Punto de Venta QR • Versión ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Compatibilidad: Android 7.0 (API 24) a Android 15+ (API 35+) • 100% Offline • Sin conexión a internet • ML Kit Bundled + SQLite Room + PDF/Apache POI.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
