package com.example.ui.screens

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.data.local.ConfiguracionNegocioEntity
import com.example.security.LicenseSecurityManager
import com.example.security.ResultadoValidacionCodigo
import com.example.util.CurrencyAndVoiceFormatter
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@Composable
fun ActivationScreen(
    mensajeBloqueo: String?,
    onActivarCodigo: (String) -> ResultadoValidacionCodigo
) {
    val context = LocalContext.current
    val huellaResumen = remember { LicenseSecurityManager.obtenerResumenHuellaDispositivo(context) }
    var codigoInput by remember { mutableStateOf("") }
    var mensajeError by remember { mutableStateOf(mensajeBloqueo) }
    var mostrarLotePruebas by remember { mutableStateOf(true) }
    var mostrarInfoScriptPc by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .imePadding()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 560.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(76.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "Activación Criptográfica",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(42.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "PUNTO DE VENTA QR",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Activación por Código Único • Criptografía Asimétrica RSA-2048",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer,
                shape = RoundedCornerShape(50),
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Text(
                    text = "ID Hardware Dispositivo: $huellaResumen  |  Versión ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Introduce tu Código de Licencia",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Este código se verifica sin internet contra la clave pública embebida y queda vinculado de forma cifrada (AES-256-GCM) exclusivamente a este teléfono.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = codigoInput,
                        onValueChange = {
                            codigoInput = it
                            mensajeError = null
                        },
                        label = { Text("Código de activación firmado (PDV1...)") },
                        placeholder = { Text("PDV1.TElDLTAwMDAx...") },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("codigo_activacion_input")
                    )

                    if (!mensajeError.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = "Error",
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = mensajeError!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            when (val res = onActivarCodigo(codigoInput)) {
                                is ResultadoValidacionCodigo.Valido -> {
                                    mensajeError = null
                                }
                                is ResultadoValidacionCodigo.Invalido -> {
                                    mensajeError = res.motivo
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("activar_licencia_button")
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Validar y Vincular a este Dispositivo")
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tarjeta de ayuda para probar códigos firmados reales o ver el generador externo de PC
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { mostrarLotePruebas = !mostrarLotePruebas },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Códigos Firmados con Clave Privada del Dueño",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (mostrarLotePruebas) "Ocultar" else "Mostrar",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    AnimatedVisibility(visible = mostrarLotePruebas) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            Text(
                                text = "Toca cualquiera de estas licencias emitidas con la clave privada RSA-2048 para cargarla o probar la validación criptográfica:",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LicenseSecurityManager.CODIGOS_DEMO_FIRMADOS.forEachIndexed { idx, item ->
                                OutlinedButton(
                                    onClick = {
                                        codigoInput = item.codigo
                                        mensajeError = null
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .testTag("cargar_licencia_demo_${idx + 1}")
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("${item.etiqueta} [${item.idLicencia}]")
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    codigoInput = LicenseSecurityManager.CODIGO_DEMO_VENCIDO
                                    mensajeError = null
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .testTag("cargar_licencia_vencida_button")
                            ) {
                                Icon(Icons.Default.ErrorOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Probar Código Vencido (LIC-VENCIDA • 2022)")
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            TextButton(
                                onClick = { mostrarInfoScriptPc = true },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Ver Script Generador de 100,000 Códigos para PC")
                            }
                        }
                    }
                }
            }
        }
    }

    if (mostrarInfoScriptPc) {
        AlertDialog(
            onDismissRequest = { mostrarInfoScriptPc = false },
            title = { Text("Generación Externa de Licencias (PC)") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "La aplicación NUNCA genera códigos ni incluye la clave privada. En la carpeta '/tools/generador_licencias/' del proyecto se incluyen los scripts listos para la computadora del dueño:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Python 3:\npython3 generar_codigos.py --cantidad 100000 --vencimiento 2099-12-31 --salida lote_100k.csv\n\n• Node.js:\nnode generar_codigos.js 100000 2099-12-31 lote_100k.csv",
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { mostrarInfoScriptPc = false }) {
                    Text("Entendido")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InitialSetupScreen(
    onProcesarLogo: (android.net.Uri, (String?) -> Unit) -> Unit,
    onGuardarConfiguracionInicial: (
        nombreNegocio: String,
        nombreDueno: String,
        direccion: String,
        telefono: String,
        correo: String,
        monedaCodigo: String,
        monedaSimbolo: String,
        simboloAntes: Boolean,
        separadorMiles: String,
        separadorDecimales: String,
        monedaVozSingular: String,
        monedaVozPlural: String,
        centavosVoz: String,
        aplicaImpuesto: Boolean,
        porcentajeImpuesto: Double,
        rutaLogoInterno: String?,
        passwordAdmin: String,
        preguntaSeguridad: String,
        respuestaSeguridad: String,
        idiomaVozPais: String,
        almacenamientoPreferido: String
    ) -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()

    var nombreNegocio by remember { mutableStateOf("") }
    var nombreDueno by remember { mutableStateOf("") }
    var direccion by remember { mutableStateOf("") }
    var telefono by remember { mutableStateOf("") }
    var correo by remember { mutableStateOf("") }

    // Por defecto la primera de las 6 monedas exactas (Peso Cubano CUP o Dólar USD)
    var monedaSeleccionada by remember { mutableStateOf(CurrencyAndVoiceFormatter.MONEDAS_PREDEFINIDAS.first()) }

    var aplicaImpuesto by remember { mutableStateOf(false) }
    var porcentajeImpuestoTexto by remember { mutableStateOf("16.0") }

    // Logo es 100% opcional (null = usa ícono genérico de tienda automáticamente)
    var rutaLogoInterno by remember { mutableStateOf<String?>(null) }

    var passwordAdmin by remember { mutableStateOf("") }
    var confirmarPassword by remember { mutableStateOf("") }
    var preguntaSeguridad by remember { mutableStateOf("¿Cuál es el nombre de tu primera mascota o ciudad natal?") }
    var respuestaSeguridad by remember { mutableStateOf("") }

    var idiomaVozPais by remember { mutableStateOf("es-ES") }
    var almacenamientoPreferido by remember { mutableStateOf("INTERNO") }
    var errorValidacion by remember { mutableStateOf<String?>(null) }

    val validarYGuardar: () -> Unit = {
        focusManager.clearFocus()
        when {
            nombreNegocio.isBlank() || nombreDueno.isBlank() || direccion.isBlank() || telefono.isBlank() || correo.isBlank() -> {
                errorValidacion = "Completa los datos obligatorios de la sección 1 (Nombre del negocio, dueño, dirección, teléfono y correo)."
                coroutineScope.launch { scrollState.animateScrollTo(0) }
                Unit
            }
            passwordAdmin.length < 4 -> {
                errorValidacion = "Completa la sección 4: La contraseña de administrador debe tener al menos 4 caracteres."
                coroutineScope.launch { scrollState.animateScrollTo(scrollState.maxValue) }
                Unit
            }
            passwordAdmin != confirmarPassword -> {
                errorValidacion = "Las contraseñas de administrador no coinciden en la sección 4."
                coroutineScope.launch { scrollState.animateScrollTo(scrollState.maxValue) }
                Unit
            }
            preguntaSeguridad.isBlank() || respuestaSeguridad.isBlank() -> {
                errorValidacion = "Completa la pregunta y respuesta de seguridad en la sección 4."
                coroutineScope.launch { scrollState.animateScrollTo(scrollState.maxValue) }
                Unit
            }
            else -> {
                errorValidacion = null
                val porc = porcentajeImpuestoTexto.replace(",", ".").toDoubleOrNull() ?: 0.0
                onGuardarConfiguracionInicial(
                    nombreNegocio,
                    nombreDueno,
                    direccion,
                    telefono,
                    correo,
                    monedaSeleccionada.codigo,
                    monedaSeleccionada.simbolo,
                    monedaSeleccionada.simboloAntes,
                    monedaSeleccionada.separadorMiles,
                    monedaSeleccionada.separadorDecimales,
                    monedaSeleccionada.vozSingular,
                    monedaSeleccionada.vozPlural,
                    monedaSeleccionada.centavosVoz,
                    aplicaImpuesto,
                    porc,
                    rutaLogoInterno, // null si no subió logo (100% opcional)
                    passwordAdmin,
                    preguntaSeguridad,
                    respuestaSeguridad,
                    idiomaVozPais,
                    almacenamientoPreferido
                )
            }
        }
    }

    // Selector de Galería (Photo Picker sin permisos de almacenamiento)
    val launcherGaleria = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onProcesarLogo(uri) { ruta -> rutaLogoInterno = ruta }
        }
    }

    // Selector desde Carpeta específica / Documentos
    val launcherCarpeta = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onProcesarLogo(uri) { ruta -> rutaLogoInterno = ruta }
        }
    }

    // Captura de Logo desde Cámara
    val launcherCamaraLogo = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            val archivo = File(context.filesDir, "logo_negocio_interno.jpg")
            FileOutputStream(archivo).use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, out)
            }
            rutaLogoInterno = archivo.absolutePath
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .imePadding()
    ) {
        // Contenido con Scroll Vertical completo para cualquier tamaño de pantalla
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.widthIn(max = 640.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "CONFIGURACIÓN INICIAL",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Desliza hacia abajo para completar las 5 secciones o toca 'Guardar y continuar'",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "v${BuildConfig.VERSION_NAME}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ==================== 1. DATOS DEL NEGOCIO Y PROPIETARIO ====================
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Business, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("1. Datos del Negocio y Propietario", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = nombreNegocio,
                            onValueChange = {
                                nombreNegocio = it
                                errorValidacion = null
                            },
                            label = { Text("Nombre del negocio *") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_nombre_negocio")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = nombreDueno,
                            onValueChange = {
                                nombreDueno = it
                                errorValidacion = null
                            },
                            label = { Text("Nombre del dueño (Administrador) *") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_nombre_dueno")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = direccion,
                            onValueChange = {
                                direccion = it
                                errorValidacion = null
                            },
                            label = { Text("Dirección del negocio *") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_direccion")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = telefono,
                                onValueChange = {
                                    telefono = it
                                    errorValidacion = null
                                },
                                label = { Text("Teléfono *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("setup_telefono")
                            )
                            OutlinedTextField(
                                value = correo,
                                onValueChange = {
                                    correo = it
                                    errorValidacion = null
                                },
                                label = { Text("Correo electrónico *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("setup_correo")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ==================== 2. LISTA EXACTA DE LAS 6 MONEDAS E IMPUESTOS ====================
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("2. Moneda y Formato Decimal (6 opciones)", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(6.dp))

                        CurrencyAndVoiceFormatter.MONEDAS_PREDEFINIDAS.forEachIndexed { index, preset ->
                            val seleccionada = monedaSeleccionada.codigo == preset.codigo
                            Surface(
                                color = if (seleccionada) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clickable { monedaSeleccionada = preset }
                                    .testTag("moneda_opcion_${preset.codigo}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        RadioButton(
                                            selected = seleccionada,
                                            onClick = { monedaSeleccionada = preset }
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "${index + 1}. ${preset.nombreMostrar}",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = if (seleccionada) FontWeight.Bold else FontWeight.Medium
                                            )
                                            Text(
                                                text = "Símbolo: ${preset.simbolo}  •  Formato: ${preset.ejemplo}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Text(
                                        text = preset.ejemplo,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("¿Aplica Impuestos?", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = aplicaImpuesto, onCheckedChange = { aplicaImpuesto = it })
                        }
                        AnimatedVisibility(visible = aplicaImpuesto) {
                            OutlinedTextField(
                                value = porcentajeImpuestoTexto,
                                onValueChange = { porcentajeImpuestoTexto = it },
                                label = { Text("Porcentaje de impuesto (%)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ==================== 3. LOGO DEL NEGOCIO (100% OPCIONAL) ====================
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("3. Logo del Negocio (Opcional)", style = MaterialTheme.typography.titleMedium)
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = "100% Opcional",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No es obligatorio subir un logo para continuar. Si no cargas uno, se usará automáticamente el ícono genérico de tienda (máx. 2 MB, 500x500 px).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                val bmpCargado = remember(rutaLogoInterno) {
                                    rutaLogoInterno?.let { BitmapFactory.decodeFile(it) }
                                }
                                if (bmpCargado != null) {
                                    Image(
                                        bitmap = bmpCargado.asImageBitmap(),
                                        contentDescription = "Logo del negocio",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Image(
                                        painter = painterResource(id = R.drawable.img_default_store_logo),
                                        contentDescription = "Ícono genérico de tienda",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            launcherGaleria.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Galería")
                                    }
                                    OutlinedButton(
                                        onClick = { launcherCamaraLogo.launch(null) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Cámara")
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(
                                        onClick = { launcherCarpeta.launch(arrayOf("image/png", "image/jpeg", "image/jpg")) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Carpeta")
                                    }
                                    if (rutaLogoInterno != null) {
                                        OutlinedButton(
                                            onClick = { rutaLogoInterno = null },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Quitar")
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = {
                                focusManager.clearFocus()
                                coroutineScope.launch { scrollState.animateScrollTo(scrollState.maxValue) }
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Omitir logo e ir a Contraseña y Guardar ↓")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ==================== 4. SEGURIDAD DE ADMINISTRADOR ====================
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("4. Contraseña de Administrador y Recuperación", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = passwordAdmin,
                                onValueChange = {
                                    passwordAdmin = it
                                    errorValidacion = null
                                },
                                label = { Text("Contraseña Admin *") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("setup_password_admin")
                            )
                            OutlinedTextField(
                                value = confirmarPassword,
                                onValueChange = {
                                    confirmarPassword = it
                                    errorValidacion = null
                                },
                                label = { Text("Confirmar contraseña *") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("setup_confirmar_password")
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = preguntaSeguridad,
                            onValueChange = {
                                preguntaSeguridad = it
                                errorValidacion = null
                            },
                            label = { Text("Pregunta de seguridad (para recuperar contraseña) *") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_pregunta_seguridad")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = respuestaSeguridad,
                            onValueChange = {
                                respuestaSeguridad = it
                                errorValidacion = null
                            },
                            label = { Text("Respuesta de seguridad *") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_respuesta_seguridad")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ==================== 5. IDIOMA DE VOZ Y ALMACENAMIENTO ====================
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("5. Idioma de Voz (Español) y Almacenamiento", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CurrencyAndVoiceFormatter.IDIOMAS_VOZ_ESPANOL.forEach { idioma ->
                                FilterChip(
                                    selected = idiomaVozPais == idioma.codigoBcp47,
                                    onClick = { idiomaVozPais = idioma.codigoBcp47 },
                                    label = { Text(idioma.etiquetaPais) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Destino de PDFs y Excels (SQLite siempre en memoria interna):", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FilterChip(
                                selected = almacenamientoPreferido == "INTERNO",
                                onClick = { almacenamientoPreferido = "INTERNO" },
                                label = { Text("Memoria Interna") }
                            )
                            FilterChip(
                                selected = almacenamientoPreferido == "SD",
                                onClick = { almacenamientoPreferido = "SD" },
                                label = { Text("Tarjeta Micro SD") }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Botón adicional al final del contenido con scroll
                Button(
                    onClick = validarYGuardar,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Guardar y continuar", style = MaterialTheme.typography.titleMedium)
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }

        // ==================== BARRA INFERIOR FIJA SIEMPRE VISIBLE ("Guardar y continuar") ====================
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            shadowElevation = 10.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(modifier = Modifier.widthIn(max = 640.dp)) {
                    if (errorValidacion != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = errorValidacion!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }

                    Button(
                        onClick = validarYGuardar,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("guardar_config_inicial_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Guardar y continuar", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun MasterRecoveryCodeOneTimeDialog(
    codigoMaestro: String,
    onConfirmarAnotado: () -> Unit
) {
    AlertDialog(
        onDismissRequest = {},
        icon = {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = { Text("Código Maestro de Recuperación") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "IMPORTANTE: Este código maestro se muestra UNA SOLA VEZ. Anótalo y guárdalo en un lugar seguro para recuperar el acceso de administrador en caso de olvidar la contraseña:",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = codigoMaestro,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmarAnotado,
                modifier = Modifier.testTag("confirmar_codigo_maestro_button")
            ) {
                Text("Ya lo anoté, continuar")
            }
        }
    )
}

@Composable
fun DayStartScreen(
    config: ConfiguracionNegocioEntity,
    fechaCompletaActual: String,
    horaActual: String,
    onIniciarDia: (String) -> Unit,
    onAbrirAccesoAdmin: () -> Unit
) {
    var nombreVendedor by remember { mutableStateOf("") }
    var mostrarErrorVacio by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .imePadding()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 500.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val bmpLogo = remember(config.rutaLogoInterno) {
                    config.rutaLogoInterno?.let { BitmapFactory.decodeFile(it) }
                }
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                ) {
                    if (bmpLogo != null) {
                        Image(
                            bitmap = bmpLogo.asImageBitmap(),
                            contentDescription = "Logo del negocio",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.img_default_store_logo),
                            contentDescription = "Logo de tienda",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = config.nombreNegocio,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Apertura de Jornada Laboral Diaria",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Fecha completa (automática): $fechaCompletaActual",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Hora de apertura (automática): $horaActual",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = nombreVendedor,
                    onValueChange = {
                        nombreVendedor = it
                        mostrarErrorVacio = false
                    },
                    label = { Text("Nombre del vendedor del día *") },
                    placeholder = { Text("Ej. Juan Pérez") },
                    leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                    isError = mostrarErrorVacio,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("nombre_vendedor_input")
                )

                if (mostrarErrorVacio) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "El nombre del vendedor es obligatorio para abrir la jornada.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (nombreVendedor.trim().isEmpty()) {
                            mostrarErrorVacio = true
                        } else {
                            onIniciarDia(nombreVendedor.trim())
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("iniciar_jornada_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Abrir Punto de Venta")
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Versión ${BuildConfig.VERSION_NAME} • 100% Offline",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(
                        onClick = onAbrirAccesoAdmin,
                        modifier = Modifier.testTag("acceso_admin_apertura_button")
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Administrador")
                    }
                }
            }
        }
    }
}
