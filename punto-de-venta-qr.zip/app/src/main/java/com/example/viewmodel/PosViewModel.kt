package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CarritoTemporalEntity
import com.example.data.local.CierreDiarioEntity
import com.example.data.local.ConfiguracionNegocioEntity
import com.example.data.local.DetalleVentaEntity
import com.example.data.local.HistoricoPrecioEntity
import com.example.data.local.JornadaActivaEntity
import com.example.data.local.PosDatabase
import com.example.data.local.PosRepository
import com.example.data.local.ProductoEntity
import com.example.data.local.RegistroCambioEntity
import com.example.data.local.VentaEntity
import com.example.security.EstadoVinculacionDispositivo
import com.example.security.LicenseSecurityManager
import com.example.security.ResultadoValidacionCodigo
import com.example.util.CurrencyAndVoiceFormatter
import com.example.util.OfflineVoiceSpeaker
import com.example.util.PdfAndExcelExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class AlertaEscaner {
    object Ninguna : AlertaEscaner()
    object TimeoutLectura : AlertaEscaner() // "No se pudo leer, intenta de nuevo"
    object CodigoIlegible : AlertaEscaner() // "Código ilegible, usa agregar manual"
    data class ProductoNoRegistrado(val codigo: String) : AlertaEscaner() // "Producto no registrado"
    data class ProductoEscaneadoExito(val codigo: String, val nombre: String, val cantidadTotal: Int) : AlertaEscaner()
}

enum class SeccionAdmin {
    CATALOGO,
    ETIQUETAS_QR,
    RESUMEN_DIA,
    HISTORIAL_FECHA,
    RESPALDO_Y_CONFIG
}

class PosViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PosRepository
    private val voiceSpeaker: OfflineVoiceSpeaker

    // Reloj en tiempo real (fecha y hora exacta HH:mm:ss)
    private val _fechaActualMostrar = MutableStateFlow(obtenerFechaMostrarActual())
    val fechaActualMostrar: StateFlow<String> = _fechaActualMostrar.asStateFlow()

    private val _fechaActualIso = MutableStateFlow(obtenerFechaIsoActual())
    val fechaActualIso: StateFlow<String> = _fechaActualIso.asStateFlow()

    private val _horaActualExacta = MutableStateFlow(obtenerHoraExactaActual())
    val horaActualExacta: StateFlow<String> = _horaActualExacta.asStateFlow()

    // Estado de activación y vinculación criptográfica al dispositivo
    private val _estadoLicencia = MutableStateFlow<EstadoVinculacionDispositivo>(EstadoVinculacionDispositivo.NoActivado)
    val estadoLicencia: StateFlow<EstadoVinculacionDispositivo> = _estadoLicencia.asStateFlow()

    private val _cargandoInicial = MutableStateFlow(true)
    val cargandoInicial: StateFlow<Boolean> = _cargandoInicial.asStateFlow()

    // Código maestro que se muestra una sola vez al terminar la configuración inicial
    private val _codigoMaestroMostrarUnaVez = MutableStateFlow<String?>(null)
    val codigoMaestroMostrarUnaVez: StateFlow<String?> = _codigoMaestroMostrarUnaVez.asStateFlow()

    // Recuperación de venta tras cierre inesperado
    private val _mostrarPreguntaRecuperarVenta = MutableStateFlow(false)
    val mostrarPreguntaRecuperarVenta: StateFlow<Boolean> = _mostrarPreguntaRecuperarVenta.asStateFlow()
    private var verificacionRecuperacionRealizada = false

    // Cámara y escáner QR
    private val _usarCamaraFrontal = MutableStateFlow(false) // Trasera por defecto
    val usarCamaraFrontal: StateFlow<Boolean> = _usarCamaraFrontal.asStateFlow()

    private val _escanerExpandido = MutableStateFlow(true)
    val escanerExpandido: StateFlow<Boolean> = _escanerExpandido.asStateFlow()

    private val _alertaEscaner = MutableStateFlow<AlertaEscaner>(AlertaEscaner.Ninguna)
    val alertaEscaner: StateFlow<AlertaEscaner> = _alertaEscaner.asStateFlow()

    // Pantalla de Cobrar ("RESUMEN DE COMPRA")
    private val _mostrarPantallaCobrar = MutableStateFlow(false)
    val mostrarPantallaCobrar: StateFlow<Boolean> = _mostrarPantallaCobrar.asStateFlow()

    private val _metodoPagoSeleccionado = MutableStateFlow("")
    val metodoPagoSeleccionado: StateFlow<String> = _metodoPagoSeleccionado.asStateFlow()

    private val _horaResumenCobro = MutableStateFlow("")
    val horaResumenCobro: StateFlow<String> = _horaResumenCobro.asStateFlow()

    // Sesión de Administrador y bloqueo automático tras 5 minutos de inactividad
    private val _esModoAdmin = MutableStateFlow(false)
    val esModoAdmin: StateFlow<Boolean> = _esModoAdmin.asStateFlow()

    private val _seccionAdminActual = MutableStateFlow(SeccionAdmin.CATALOGO)
    val seccionAdminActual: StateFlow<SeccionAdmin> = _seccionAdminActual.asStateFlow()

    private val _segundosRestantesSesionAdmin = MutableStateFlow(300)
    val segundosRestantesSesionAdmin: StateFlow<Int> = _segundosRestantesSesionAdmin.asStateFlow()
    private var ultimaActividadAdminMs: Long = System.currentTimeMillis()

    // Mensajes informativos / alertas globales en UI
    private val _mensajeBanner = MutableStateFlow<String?>(null)
    val mensajeBanner: StateFlow<String?> = _mensajeBanner.asStateFlow()

    private val _ultimoArchivoGenerado = MutableStateFlow<File?>(null)
    val ultimoArchivoGenerado: StateFlow<File?> = _ultimoArchivoGenerado.asStateFlow()

    // Flows de base de datos SQLite Room
    val configuracionNegocio: StateFlow<ConfiguracionNegocioEntity?>
    val jornadaActiva: StateFlow<JornadaActivaEntity?>
    val catalogoProductos: StateFlow<List<ProductoEntity>>
    val historicoPrecios: StateFlow<List<HistoricoPrecioEntity>>
    val registroCambios: StateFlow<List<RegistroCambioEntity>>
    val carritoEnCurso: StateFlow<List<CarritoTemporalEntity>>
    val historialDiario: StateFlow<List<CierreDiarioEntity>>
    val ventasDeHoy: StateFlow<List<VentaEntity>>

    init {
        val db = PosDatabase.getInstance(application)
        repository = PosRepository(db.posDao())
        voiceSpeaker = OfflineVoiceSpeaker(application)

        configuracionNegocio = repository.configuracionFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), null
        )
        jornadaActiva = repository.jornadaActivaFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), null
        )
        catalogoProductos = repository.productosFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        historicoPrecios = repository.historicoPreciosFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        registroCambios = repository.registroCambiosFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        carritoEnCurso = repository.carritoTemporalFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        historialDiario = repository.historialDiarioFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        @OptIn( kotlinx.coroutines.ExperimentalCoroutinesApi::class)
        ventasDeHoy = _fechaActualIso.flatMapLatest { fecha ->
            repository.observarVentasDeFecha(fecha)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        inicializarEstadoArranque()
        iniciarRelojYTemporizadorInactividad()
    }

    private fun inicializarEstadoArranque() {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            PosDatabase.precargarCatalogoInicialSiVacio(PosDatabase.getInstance(ctx).posDao())
            val entidadLicencia = repository.obtenerLicenciaSync()
            val estado = LicenseSecurityManager.verificarVinculacionAlArrancar(ctx, entidadLicencia)
            _estadoLicencia.value = estado

            val config = repository.obtenerConfiguracionSync()
            if (config != null) {
                withContext(Dispatchers.Main) {
                    voiceSpeaker.aplicarIdioma(config.idiomaVozPais)
                }
            }

            // Verificar si quedó una venta en curso sin cerrar de una ejecución anterior
            val carritoGuardado = repository.obtenerCarritoTemporalSync()
            if (carritoGuardado.isNotEmpty() && !verificacionRecuperacionRealizada) {
                verificacionRecuperacionRealizada = true
                _mostrarPreguntaRecuperarVenta.value = true
            }
            _cargandoInicial.value = false
        }
    }

    private fun iniciarRelojYTemporizadorInactividad() {
        viewModelScope.launch {
            while (true) {
                delay(1000L)
                _horaActualExacta.value = obtenerHoraExactaActual()
                val hoyIso = obtenerFechaIsoActual()
                if (hoyIso != _fechaActualIso.value) {
                    _fechaActualIso.value = hoyIso
                    _fechaActualMostrar.value = obtenerFechaMostrarActual()
                }

                // Verificar inactividad de sesión de administrador (5 minutos = 300 segundos)
                if (_esModoAdmin.value) {
                    val transcurridoSeg = ((System.currentTimeMillis() - ultimaActividadAdminMs) / 1000L).toInt()
                    val restantes = (300 - transcurridoSeg).coerceAtLeast(0)
                    _segundosRestantesSesionAdmin.value = restantes
                    if (restantes <= 0) {
                        _esModoAdmin.value = false
                        _mensajeBanner.value = "Sesión de administrador cerrada automáticamente tras 5 minutos de inactividad."
                    }
                }
            }
        }
    }

    fun registrarActividadAdmin() {
        ultimaActividadAdminMs = System.currentTimeMillis()
        _segundosRestantesSesionAdmin.value = 300
    }

    fun limpiarMensajeBanner() {
        _mensajeBanner.value = null
    }

    // ==================== 1. ACTIVACIÓN POR CÓDIGO ÚNICO ====================

    fun activarAplicacionConCodigo(codigoIntroducido: String): ResultadoValidacionCodigo {
        val ctx = getApplication<Application>()
        val resultado = LicenseSecurityManager.validarCodigoActivacion(codigoIntroducido)
        if (resultado is ResultadoValidacionCodigo.Valido) {
            viewModelScope.launch(Dispatchers.IO) {
                val entidadCifrada = LicenseSecurityManager.crearEntidadLicenciaCifrada(ctx, resultado)
                repository.guardarLicencia(entidadCifrada)
                _estadoLicencia.value = LicenseSecurityManager.verificarVinculacionAlArrancar(ctx, entidadCifrada)
                registrarCambioAuditoria(
                    tipo = "SEGURIDAD",
                    codigo = resultado.idLicencia,
                    detalle = "Licencia activada y vinculada al hardware (${LicenseSecurityManager.obtenerResumenHuellaDispositivo(ctx)})"
                )
            }
        }
        return resultado
    }

    // ==================== 2. CONFIGURACIÓN INICIAL (PRIMER DÍA) ====================

    fun guardarConfiguracionInicialPrimerDia(
        nombreNegocio: String,
        nombreDueno: String,
        direccion: String,
        telefono: String,
        correo: String,
        monedaCodigo: String,
        monedaSimbolo: String,
        simboloAntes: Boolean,
        separadorMiles: String,
        separadorDecimales: String,
        monedaVozSingular: String,
        monedaVozPlural: String,
        centavosVoz: String,
        aplicaImpuesto: Boolean,
        porcentajeImpuesto: Double,
        rutaLogoInterno: String?,
        passwordAdmin: String,
        preguntaSeguridad: String,
        respuestaSeguridad: String,
        idiomaVozPais: String,
        almacenamientoPreferido: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val salt = LicenseSecurityManager.generarSaltAleatorio()
            val hashPass = LicenseSecurityManager.hashConSalt(passwordAdmin, salt)
            val hashResp = LicenseSecurityManager.hashConSalt(respuestaSeguridad.lowercase(Locale.getDefault()), salt)
            val codigoMaestroPlano = LicenseSecurityManager.generarCodigoMaestroRecuperacion()
            val hashMaestro = LicenseSecurityManager.hashConSalt(codigoMaestroPlano.uppercase(Locale.getDefault()), salt)

            val config = ConfiguracionNegocioEntity(
                id = 1,
                nombreNegocio = nombreNegocio.trim(),
                nombreDueno = nombreDueno.trim(),
                direccion = direccion.trim(),
                telefono = telefono.trim(),
                correo = correo.trim(),
                monedaCodigo = monedaCodigo,
                monedaSimbolo = monedaSimbolo.trim().ifEmpty { "$" },
                simboloAntes = simboloAntes,
                separadorMiles = separadorMiles,
                separadorDecimales = separadorDecimales,
                monedaVozSingular = monedaVozSingular.trim().ifEmpty { "dólar" },
                monedaVozPlural = monedaVozPlural.trim().ifEmpty { "dólares" },
                centavosVoz = centavosVoz.trim().ifEmpty { "centavos" },
                aplicaImpuesto = aplicaImpuesto,
                porcentajeImpuesto = if (aplicaImpuesto) porcentajeImpuesto else 0.0,
                rutaLogoInterno = rutaLogoInterno,
                hashPasswordAdmin = hashPass,
                saltPassword = salt,
                preguntaSeguridad = preguntaSeguridad.trim(),
                hashRespuestaSeguridad = hashResp,
                hashCodigoMaestro = hashMaestro,
                idiomaVozPais = idiomaVozPais,
                volumenVoz = 1.0f,
                almacenamientoExportacion = almacenamientoPreferido,
                respaldoNocturnoCorreo = false,
                configuracionCompletada = true
            )
            repository.guardarConfiguracion(config)
            withContext(Dispatchers.Main) {
                voiceSpeaker.aplicarIdioma(idiomaVozPais)
            }
            registrarCambioAuditoria(
                tipo = "CONFIGURACION",
                codigo = "INICIAL",
                detalle = "Configuración inicial completada para ${config.nombreNegocio} (Dueño: ${config.nombreDueno})"
            )
            _codigoMaestroMostrarUnaVez.value = codigoMaestroPlano
        }
    }

    fun confirmarCodigoMaestroVisto() {
        _codigoMaestroMostrarUnaVez.value = null
    }

    fun procesarLogoSeleccionado(uri: Uri, onResultado: (String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = PdfAndExcelExporter.procesarYGuardarLogoNegocio(getApplication(), uri)
            withContext(Dispatchers.Main) {
                res.onSuccess { ruta ->
                    onResultado(ruta)
                }.onFailure { err ->
                    _mensajeBanner.value = "Error al procesar logo: ${err.message}"
                    onResultado(null)
                }
            }
        }
    }

    // ==================== 3. INICIO DE DÍA LABORAL ====================

    fun iniciarJornadaDelDia(nombreVendedor: String) {
        val limpio = nombreVendedor.trim()
        if (limpio.isEmpty()) {
            _mensajeBanner.value = "El nombre del vendedor del día es obligatorio."
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val jornada = JornadaActivaEntity(
                id = 1,
                fechaIso = obtenerFechaIsoActual(),
                fechaCompleta = obtenerFechaMostrarActual(),
                nombreVendedor = limpio,
                horaApertura = obtenerHoraExactaActual(),
                jornadaAbierta = true
            )
            repository.guardarJornadaActiva(jornada)
            _mensajeBanner.value = "Jornada iniciada para $limpio a las ${jornada.horaApertura}"
        }
    }

    fun cambiarVendedorReiniciarJornada() {
        viewModelScope.launch(Dispatchers.IO) {
            val actual = repository.obtenerJornadaActivaSync() ?: return@launch
            repository.guardarJornadaActiva(actual.copy(jornadaAbierta = false))
        }
    }

    // ==================== 4. RECUPERACIÓN DE VENTA TRAS CIERRE INESPERADO ====================

    fun responderRecuperacionVenta(recuperar: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            if (!recuperar) {
                repository.limpiarCarritoTemporal()
                _mensajeBanner.value = "Venta anterior descartada."
            } else {
                _mensajeBanner.value = "Venta en curso recuperada exitosamente."
            }
            _mostrarPreguntaRecuperarVenta.value = false
        }
    }

    // ==================== 5. ESCÁNER QR Y VENTA EN CURSO (VENDEDOR) ====================

    fun alternarCamaraFrontalTrasera() {
        _usarCamaraFrontal.value = !_usarCamaraFrontal.value
        val tipo = if (_usarCamaraFrontal.value) "Cámara Frontal" else "Cámara Trasera"
        _mensajeBanner.value = "Cambiado a $tipo"
    }

    fun conmutarCamaraAutomaticaPorFallo(nuevaFrontal: Boolean, motivo: String) {
        if (_usarCamaraFrontal.value != nuevaFrontal) {
            _usarCamaraFrontal.value = nuevaFrontal
            _mensajeBanner.value = motivo
        }
    }

    fun alternarVisibilidadEscaner() {
        _escanerExpandido.value = !_escanerExpandido.value
    }

    fun limpiarAlertaEscaner() {
        _alertaEscaner.value = AlertaEscaner.Ninguna
    }

    fun reportarTimeoutEscaner3Segundos() {
        _alertaEscaner.value = AlertaEscaner.TimeoutLectura
    }

    fun reportarQrDanadoIlegible() {
        _alertaEscaner.value = AlertaEscaner.CodigoIlegible
    }

    fun procesarCodigoQrEscaneado(codigoRaw: String) {
        val codigo = codigoRaw.trim().uppercase(Locale.getDefault())
        if (codigo.isEmpty() || codigo == "CORRUPTO" || codigo == "DANADO") {
            _alertaEscaner.value = AlertaEscaner.CodigoIlegible
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val producto = repository.buscarProductoPorCodigo(codigo)
            if (producto == null) {
                _alertaEscaner.value = AlertaEscaner.ProductoNoRegistrado(codigo)
            } else {
                val nuevaCant = agregarOSumarProductoAlCarritoInterno(producto, 1)
                _alertaEscaner.value = AlertaEscaner.ProductoEscaneadoExito(
                    codigo = producto.codigo,
                    nombre = producto.nombre,
                    cantidadTotal = nuevaCant
                )
            }
        }
    }

    fun avisarAdminProductoNoRegistrado(codigoNoRegistrado: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val vendedor = jornadaActiva.value?.nombreVendedor ?: "Vendedor"
            registrarCambioAuditoria(
                tipo = "ALERTA_VENDEDOR",
                codigo = codigoNoRegistrado,
                detalle = "El vendedor ($vendedor) escaneó el código '$codigoNoRegistrado' que no existe en el catálogo."
            )
            _alertaEscaner.value = AlertaEscaner.Ninguna
            _mensajeBanner.value = "Aviso enviado al administrador para registrar el código $codigoNoRegistrado."
        }
    }

    fun agregarProductoManualAVenta(producto: ProductoEntity, cantidadAgregar: Int = 1) {
        viewModelScope.launch(Dispatchers.IO) {
            val cantTotal = agregarOSumarProductoAlCarritoInterno(producto, cantidadAgregar.coerceAtLeast(1))
            _alertaEscaner.value = AlertaEscaner.ProductoEscaneadoExito(
                codigo = producto.codigo,
                nombre = producto.nombre,
                cantidadTotal = cantTotal
            )
        }
    }

    private suspend fun agregarOSumarProductoAlCarritoInterno(
        producto: ProductoEntity,
        deltaCantidad: Int
    ): Int {
        val actuales = repository.obtenerCarritoTemporalSync()
        val existente = actuales.find { it.codigo.equals(producto.codigo, ignoreCase = true) }
        val vendedor = jornadaActiva.value?.nombreVendedor ?: "Vendedor"
        val nuevaCantidad = (existente?.cantidad ?: 0) + deltaCantidad

        val item = CarritoTemporalEntity(
            codigo = producto.codigo,
            nombre = producto.nombre,
            gramaje = producto.gramaje,
            volumen = producto.volumen,
            precioUnitario = producto.precio_actual,
            cantidad = nuevaCantidad,
            vendedor = vendedor,
            fechaInicio = existente?.fechaInicio ?: obtenerFechaMostrarActual(),
            horaInicio = existente?.horaInicio ?: obtenerHoraExactaActual()
        )
        repository.guardarItemCarritoTemporal(item)
        return nuevaCantidad
    }

    fun modificarCantidadProductoEnVenta(codigo: String, nuevaCantidad: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            if (nuevaCantidad <= 0) {
                repository.eliminarItemCarritoTemporal(codigo)
            } else {
                val actuales = repository.obtenerCarritoTemporalSync()
                val item = actuales.find { it.codigo == codigo } ?: return@launch
                repository.guardarItemCarritoTemporal(item.copy(cantidad = nuevaCantidad))
            }
        }
    }

    fun eliminarProductoDeVenta(codigo: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.eliminarItemCarritoTemporal(codigo)
        }
    }

    fun cancelarVentaEnCurso() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.limpiarCarritoTemporal()
            _mostrarPantallaCobrar.value = false
            _metodoPagoSeleccionado.value = ""
            _alertaEscaner.value = AlertaEscaner.Ninguna
            _mensajeBanner.value = "Venta en curso cancelada."
        }
    }

    // ==================== 6. COBRAR, VOZ TTS Y CERRAR VENTA ====================

    fun calcularSubtotalCarrito(items: List<CarritoTemporalEntity>): Double {
        return items.sumOf { it.precioUnitario * it.cantidad }
    }

    fun calcularImpuestoCarrito(subtotal: Double, config: ConfiguracionNegocioEntity?): Double {
        if (config == null || !config.aplicaImpuesto || config.porcentajeImpuesto <= 0.0) return 0.0
        return BigDecimal.valueOf(subtotal * (config.porcentajeImpuesto / 100.0))
            .setScale(2, RoundingMode.HALF_UP)
            .toDouble()
    }

    fun calcularTotalAPagar(items: List<CarritoTemporalEntity>, config: ConfiguracionNegocioEntity?): Double {
        val sub = calcularSubtotalCarrito(items)
        val imp = calcularImpuestoCarrito(sub, config)
        return BigDecimal.valueOf(sub + imp).setScale(2, RoundingMode.HALF_UP).toDouble()
    }

    fun tocarBotonCobrar() {
        val items = carritoEnCurso.value
        if (items.isEmpty()) {
            _mensajeBanner.value = "Agrega o escanea al menos un producto antes de cobrar."
            return
        }
        _horaResumenCobro.value = obtenerHoraExactaActual()
        _mostrarPantallaCobrar.value = true
        decirTotalPorVoz()
    }

    fun repetirTotalPorVoz() {
        val items = carritoEnCurso.value
        if (items.isEmpty()) {
            _mensajeBanner.value = "No hay productos en la venta actual."
            return
        }
        decirTotalPorVoz()
    }

    private fun decirTotalPorVoz() {
        val config = configuracionNegocio.value
        val total = calcularTotalAPagar(carritoEnCurso.value, config)
        val frase = CurrencyAndVoiceFormatter.construirFraseTotalPorVoz(total, config)
        voiceSpeaker.hablarTexto(
            texto = frase,
            volumen = config?.volumenVoz ?: 1.0f,
            codigoIdioma = config?.idiomaVozPais ?: "es-MX"
        )
    }

    fun seleccionarMetodoPago(metodo: String) {
        _metodoPagoSeleccionado.value = metodo
    }

    fun volverDeCobrarAVentaEnCurso() {
        _mostrarPantallaCobrar.value = false
    }

    fun cerrarVentaActual() {
        val items = carritoEnCurso.value
        if (items.isEmpty()) {
            _mensajeBanner.value = "No hay productos para cerrar la venta."
            return
        }
        val metodo = _metodoPagoSeleccionado.value
        if (metodo.isBlank()) {
            // Si aún no está en pantalla de cobro o no eligió método de pago, abrir Cobrar
            if (!_mostrarPantallaCobrar.value) {
                tocarBotonCobrar()
            }
            _mensajeBanner.value = "Selecciona un método de pago (Efectivo, Transferencia, Tarjeta o Crédito) antes de cerrar la venta."
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val config = configuracionNegocio.value
            val fechaIso = obtenerFechaIsoActual()
            val fechaMostrar = obtenerFechaMostrarActual()
            val horaVenta = obtenerHoraExactaActual()
            val vendedor = jornadaActiva.value?.nombreVendedor ?: "Vendedor"

            val subtotal = calcularSubtotalCarrito(items)
            val impuesto = calcularImpuestoCarrito(subtotal, config)
            val total = calcularTotalAPagar(items, config)

            val resumenTexto = items.joinToString(", ") { "${it.nombre} x${it.cantidad}" }

            val venta = VentaEntity(
                fechaIso = fechaIso,
                fechaMostrar = fechaMostrar,
                hora = horaVenta,
                vendedor = vendedor,
                metodoPago = metodo,
                subtotal = subtotal,
                impuesto = impuesto,
                total = total,
                resumenItems = resumenTexto
            )

            val detalles = items.map { item ->
                val pres = if (item.gramaje != "-" && item.gramaje.isNotBlank()) item.gramaje else item.volumen
                DetalleVentaEntity(
                    ventaId = 0,
                    fechaIso = fechaIso,
                    codigoProducto = item.codigo,
                    nombreProducto = item.nombre,
                    presentacion = pres,
                    cantidad = item.cantidad,
                    precioUnitario = item.precioUnitario,
                    subtotal = BigDecimal.valueOf(item.precioUnitario * item.cantidad)
                        .setScale(2, RoundingMode.HALF_UP).toDouble()
                )
            }

            repository.registrarVentaCompleta(venta, detalles)

            withContext(Dispatchers.Main) {
                _mostrarPantallaCobrar.value = false
                _metodoPagoSeleccionado.value = ""
                _alertaEscaner.value = AlertaEscaner.Ninguna
                val totalFmt = CurrencyAndVoiceFormatter.formatearMoneda(total, config)
                _mensajeBanner.value = "Venta cerrada con éxito ($totalFmt - $metodo). Lista para el siguiente cliente."
            }
        }
    }

    // ==================== 7. ADMINISTRACIÓN, SEGURIDAD Y CATÁLOGO ====================

    fun iniciarSesionAdmin(password: String): Boolean {
        val config = configuracionNegocio.value ?: return false
        val hashIntento = LicenseSecurityManager.hashConSalt(password, config.saltPassword)
        return if (hashIntento == config.hashPasswordAdmin) {
            ultimaActividadAdminMs = System.currentTimeMillis()
            _segundosRestantesSesionAdmin.value = 300
            _esModoAdmin.value = true
            true
        } else {
            false
        }
    }

    fun cerrarSesionAdmin() {
        _esModoAdmin.value = false
    }

    fun cambiarSeccionAdmin(seccion: SeccionAdmin) {
        registrarActividadAdmin()
        _seccionAdminActual.value = seccion
    }

    fun recuperarPasswordConPreguntaSeguridad(
        respuestaSeguridad: String,
        nuevaPassword: String
    ): Boolean {
        val config = configuracionNegocio.value ?: return false
        if (nuevaPassword.trim().length < 4) return false
        val hashResp = LicenseSecurityManager.hashConSalt(
            respuestaSeguridad.trim().lowercase(Locale.getDefault()),
            config.saltPassword
        )
        if (hashResp != config.hashRespuestaSeguridad) return false

        viewModelScope.launch(Dispatchers.IO) {
            val nuevoHashPass = LicenseSecurityManager.hashConSalt(nuevaPassword.trim(), config.saltPassword)
            repository.guardarConfiguracion(config.copy(hashPasswordAdmin = nuevoHashPass))
            registrarCambioAuditoria(
                tipo = "SEGURIDAD",
                codigo = "ADMIN_PASS",
                detalle = "Contraseña de administrador restablecida mediante pregunta de seguridad."
            )
        }
        return true
    }

    fun recuperarPasswordConCodigoMaestro(
        codigoMaestro: String,
        nuevaPassword: String
    ): Boolean {
        val config = configuracionNegocio.value ?: return false
        if (nuevaPassword.trim().length < 4) return false
        val hashIntento = LicenseSecurityManager.hashConSalt(
            codigoMaestro.trim().uppercase(Locale.getDefault()),
            config.saltPassword
        )
        if (hashIntento != config.hashCodigoMaestro) return false

        viewModelScope.launch(Dispatchers.IO) {
            val nuevoHashPass = LicenseSecurityManager.hashConSalt(nuevaPassword.trim(), config.saltPassword)
            repository.guardarConfiguracion(config.copy(hashPasswordAdmin = nuevoHashPass))
            registrarCambioAuditoria(
                tipo = "SEGURIDAD",
                codigo = "ADMIN_PASS",
                detalle = "Contraseña de administrador restablecida mediante Código Maestro."
            )
        }
        return true
    }

    fun cambiarPasswordAdminDesdePanel(passwordActual: String, nuevaPassword: String, onResultado: (Boolean, String) -> Unit) {
        registrarActividadAdmin()
        val config = configuracionNegocio.value ?: return
        val hashActual = LicenseSecurityManager.hashConSalt(passwordActual, config.saltPassword)
        if (hashActual != config.hashPasswordAdmin) {
            onResultado(false, "La contraseña actual no es correcta.")
            return
        }
        if (nuevaPassword.trim().length < 4) {
            onResultado(false, "La nueva contraseña debe tener al menos 4 caracteres.")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val nuevoHash = LicenseSecurityManager.hashConSalt(nuevaPassword.trim(), config.saltPassword)
            repository.guardarConfiguracion(config.copy(hashPasswordAdmin = nuevoHash))
            registrarCambioAuditoria(
                tipo = "SEGURIDAD",
                codigo = "ADMIN_PASS",
                detalle = "Contraseña de administrador actualizada desde el panel de configuración."
            )
            withContext(Dispatchers.Main) {
                onResultado(true, "Contraseña actualizada correctamente.")
            }
        }
    }

    /**
     * Crea o edita un producto en el catálogo validando que no se repitan códigos.
     * Actualiza automáticamente fecha_ultimo_cambio y registra histórico si cambia el precio.
     */
    fun guardarProductoCatalogo(
        esCreacionNueva: Boolean,
        codigoOriginal: String,
        codigoNuevoRaw: String,
        nombreRaw: String,
        gramajeRaw: String,
        volumenRaw: String,
        precioNuevo: Double,
        onResultado: (Boolean, String) -> Unit
    ) {
        registrarActividadAdmin()
        val codigoNuevo = codigoNuevoRaw.trim().uppercase(Locale.getDefault())
        val nombre = nombreRaw.trim()
        val gramaje = gramajeRaw.trim().ifEmpty { "-" }
        val volumen = volumenRaw.trim().ifEmpty { "-" }

        if (codigoNuevo.isEmpty() || nombre.isEmpty() || precioNuevo <= 0.0) {
            onResultado(false, "Código, nombre y un precio mayor a 0 son obligatorios.")
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val existenteEnCodigoNuevo = repository.buscarProductoPorCodigo(codigoNuevo)
            if (esCreacionNueva && existenteEnCodigoNuevo != null) {
                withContext(Dispatchers.Main) {
                    onResultado(
                        false,
                        "Código duplicado: Ya existe un producto registrado con el código $codigoNuevo (${existenteEnCodigoNuevo.nombre})."
                    )
                }
                return@launch
            }
            if (!esCreacionNueva && !codigoOriginal.equals(codigoNuevo, ignoreCase = true) && existenteEnCodigoNuevo != null) {
                withContext(Dispatchers.Main) {
                    onResultado(
                        false,
                        "Código duplicado: No se puede cambiar al código $codigoNuevo porque ya pertenece a ${existenteEnCodigoNuevo.nombre}."
                    )
                }
                return@launch
            }

            val fechaHoyIso = obtenerFechaIsoActual()
            val productoPrevio = if (!esCreacionNueva) repository.buscarProductoPorCodigo(codigoOriginal) else null

            val nuevoProducto = ProductoEntity(
                codigo = codigoNuevo,
                nombre = nombre,
                gramaje = gramaje,
                volumen = volumen,
                fecha_ultimo_cambio = fechaHoyIso,
                precio_actual = BigDecimal.valueOf(precioNuevo).setScale(2, RoundingMode.HALF_UP).toDouble()
            )

            if (!esCreacionNueva && !codigoOriginal.equals(codigoNuevo, ignoreCase = true)) {
                repository.eliminarProductoPorCodigo(codigoOriginal)
            }
            repository.insertarOActualizarProducto(nuevoProducto)

            // Si había un producto previo y el precio cambió, guardar en la tabla historico_precios
            if (productoPrevio != null && kotlin.math.abs(productoPrevio.precio_actual - nuevoProducto.precio_actual) >= 0.005) {
                repository.insertarHistoricoPrecio(
                    HistoricoPrecioEntity(
                        codigo = nuevoProducto.codigo,
                        nombre = nuevoProducto.nombre,
                        precio_anterior = productoPrevio.precio_actual,
                        precio_nuevo = nuevoProducto.precio_actual,
                        fecha_cambio = fechaHoyIso
                    )
                )
            }

            val detalleCambio = if (productoPrevio == null) {
                "Alta de producto: ${nuevoProducto.codigo} - ${nuevoProducto.nombre} (${nuevoProducto.gramaje}/${nuevoProducto.volumen}) Precio: ${nuevoProducto.precio_actual}"
            } else {
                "Edición de producto ${nuevoProducto.codigo}: Antes [${productoPrevio.nombre}, ${productoPrevio.gramaje}, ${productoPrevio.volumen}, ${productoPrevio.precio_actual}] -> Ahora [${nuevoProducto.nombre}, ${nuevoProducto.gramaje}, ${nuevoProducto.volumen}, ${nuevoProducto.precio_actual}]"
            }

            registrarCambioAuditoria(
                tipo = if (productoPrevio != null && productoPrevio.precio_actual != nuevoProducto.precio_actual) "CAMBIO_PRECIO" else "EDICION_CATALOGO",
                codigo = nuevoProducto.codigo,
                detalle = detalleCambio
            )

            withContext(Dispatchers.Main) {
                onResultado(true, "Producto ${nuevoProducto.codigo} guardado correctamente.")
            }
        }
    }

    fun eliminarProductoDelCatalogo(producto: ProductoEntity) {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            repository.eliminarProductoPorCodigo(producto.codigo)
            registrarCambioAuditoria(
                tipo = "EDICION_CATALOGO",
                codigo = producto.codigo,
                detalle = "Producto eliminado del catálogo: ${producto.codigo} - ${producto.nombre}"
            )
            _mensajeBanner.value = "Producto ${producto.codigo} eliminado."
        }
    }

    fun importarCatalogoDesdeArchivo(uri: Uri) {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            val res = PdfAndExcelExporter.importarProductosDesdeUri(getApplication(), uri)
            res.onSuccess { importados ->
                if (importados.isEmpty()) {
                    _mensajeBanner.value = "No se encontraron filas válidas (codigo | nombre | gramaje | volumen | precio)."
                    return@onSuccess
                }
                val fechaHoyIso = obtenerFechaIsoActual()
                var creados = 0
                var actualizados = 0
                importados.forEach { dto ->
                    val previo = repository.buscarProductoPorCodigo(dto.codigo)
                    val entidad = ProductoEntity(
                        codigo = dto.codigo,
                        nombre = dto.nombre,
                        gramaje = dto.gramaje,
                        volumen = dto.volumen,
                        fecha_ultimo_cambio = fechaHoyIso,
                        precio_actual = BigDecimal.valueOf(dto.precio).setScale(2, RoundingMode.HALF_UP).toDouble()
                    )
                    repository.insertarOActualizarProducto(entidad)
                    if (previo == null) {
                        creados++
                    } else {
                        actualizados++
                        if (kotlin.math.abs(previo.precio_actual - entidad.precio_actual) >= 0.005) {
                            repository.insertarHistoricoPrecio(
                                HistoricoPrecioEntity(
                                    codigo = entidad.codigo,
                                    nombre = entidad.nombre,
                                    precio_anterior = previo.precio_actual,
                                    precio_nuevo = entidad.precio_actual,
                                    fecha_cambio = fechaHoyIso
                                )
                            )
                        }
                    }
                }
                registrarCambioAuditoria(
                    tipo = "IMPORTACION_EXCEL_CSV",
                    codigo = "LOTE",
                    detalle = "Importación masiva: $creados nuevos, $actualizados actualizados."
                )
                _mensajeBanner.value = "Importación completada: $creados productos nuevos y $actualizados actualizados."
            }.onFailure { e ->
                _mensajeBanner.value = "Error al importar archivo: ${e.message}"
            }
        }
    }

    // ==================== 8. GENERACIÓN DE ETIQUETAS QR, RESUMEN DEL DÍA Y RESPALDOS ====================

    fun exportarPdfEtiquetasQr(productosSeleccionados: List<ProductoEntity>, imprimirDirecto: Boolean) {
        registrarActividadAdmin()
        if (productosSeleccionados.isEmpty()) {
            _mensajeBanner.value = "No hay productos para generar etiquetas QR."
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val pref = configuracionNegocio.value?.almacenamientoExportacion ?: "INTERNO"
            val archivo = PdfAndExcelExporter.generarPdfEtiquetasQr(ctx, productosSeleccionados, pref)
            _ultimoArchivoGenerado.value = archivo
            withContext(Dispatchers.Main) {
                if (imprimirDirecto) {
                    PdfAndExcelExporter.imprimirArchivoPdf(ctx, archivo, "Etiquetas QR Catálogo")
                        .onFailure {
                            PdfAndExcelExporter.abrirOCompartirArchivo(ctx, archivo, "application/pdf")
                        }
                } else {
                    _mensajeBanner.value = "PDF de etiquetas QR guardado en: ${archivo.absolutePath}"
                    PdfAndExcelExporter.abrirOCompartirArchivo(ctx, archivo, "application/pdf")
                }
            }
        }
    }

    /**
     * Genera el Resumen del Día con arqueo de efectivo contado físicamente,
     * sella el registro diario como inmutable y genera el PDF contable completo.
     */
    fun generarYSellarResumenDelDia(
        efectivoContadoFisicamente: Double,
        observaciones: String,
        onPdfListo: (File, CierreDiarioEntity) -> Unit
    ) {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val config = repository.obtenerConfiguracionSync() ?: return@launch
            val fechaHoyIso = obtenerFechaIsoActual()
            val fechaHoyMostrar = obtenerFechaMostrarActual()
            val jornada = repository.obtenerJornadaActivaSync()
            val ventasHoy = repository.obtenerVentasPorFechaSync(fechaHoyIso)
            val detallesHoy = repository.obtenerDetallesPorFechaSync(fechaHoyIso)

            // Verificar si este día ya fue sellado previamente (inmutabilidad de días cerrados)
            val cierreExistente = repository.obtenerCierrePorFechaSync(fechaHoyIso)
            if (cierreExistente != null) {
                val pdfFile = PdfAndExcelExporter.generarPdfResumenDelDia(
                    ctx, config, cierreExistente, ventasHoy, detallesHoy
                )
                _ultimoArchivoGenerado.value = pdfFile
                withContext(Dispatchers.Main) {
                    _mensajeBanner.value = "El día $fechaHoyMostrar ya estaba sellado de forma inmutable. Se re-exportó su PDF original."
                    onPdfListo(pdfFile, cierreExistente)
                }
                return@launch
            }

            val totalVendido = ventasHoy.sumOf { it.total }
            val impuestosTotales = ventasHoy.sumOf { it.impuesto }
            val clientes = ventasHoy.size
            val ticketProm = if (clientes > 0) totalVendido / clientes.toDouble() else 0.0

            val totalEfectivo = ventasHoy.filter { it.metodoPago.equals("Efectivo", true) }.sumOf { it.total }
            val totalTransferencia = ventasHoy.filter { it.metodoPago.equals("Transferencia", true) }.sumOf { it.total }
            val totalTarjeta = ventasHoy.filter { it.metodoPago.equals("Tarjeta", true) }.sumOf { it.total }
            val totalCredito = ventasHoy.filter { it.metodoPago.equals("Crédito", true) || it.metodoPago.equals("Credito", true) }.sumOf { it.total }

            val diferenciaCaja = BigDecimal.valueOf(efectivoContadoFisicamente - totalEfectivo)
                .setScale(2, RoundingMode.HALF_UP).toDouble()
            val saldoFinal = BigDecimal.valueOf(
                efectivoContadoFisicamente + totalTransferencia + totalTarjeta + totalCredito
            ).setScale(2, RoundingMode.HALF_UP).toDouble()

            val resumenProductos = detallesHoy.groupBy { it.codigoProducto }
                .entries.joinToString("; ") { (_, lista) ->
                    "${lista.first().nombreProducto} x${lista.sumOf { it.cantidad }}"
                }.ifEmpty { "Sin ventas" }

            val preCierre = CierreDiarioEntity(
                fechaIso = fechaHoyIso,
                fechaMostrar = fechaHoyMostrar,
                vendedor = jornada?.nombreVendedor ?: "Vendedor",
                horaApertura = jornada?.horaApertura ?: "08:00:00",
                horaCierre = obtenerHoraExactaActual(),
                totalVendido = totalVendido,
                impuestosTotales = impuestosTotales,
                clientesAtendidos = clientes,
                ticketPromedio = ticketProm,
                totalEfectivo = totalEfectivo,
                totalTransferencia = totalTransferencia,
                totalTarjeta = totalTarjeta,
                totalCredito = totalCredito,
                efectivoContado = efectivoContadoFisicamente,
                diferenciaCaja = diferenciaCaja,
                saldoFinal = saldoFinal,
                observaciones = observaciones.trim(),
                productosVendidosResumen = resumenProductos,
                rutaPdf = "",
                timestampSello = System.currentTimeMillis()
            )

            val pdfGenerado = PdfAndExcelExporter.generarPdfResumenDelDia(
                ctx, config, preCierre, ventasHoy, detallesHoy
            )
            val cierreDefinitivo = preCierre.copy(rutaPdf = pdfGenerado.absolutePath)
            repository.sellarCierreDiarioInmutable(cierreDefinitivo)
            _ultimoArchivoGenerado.value = pdfGenerado

            registrarCambioAuditoria(
                tipo = "CIERRE_DIARIO",
                codigo = fechaHoyIso,
                detalle = "Cierre diario sellado e inmutable. Total: $totalVendido, Efectivo contado: $efectivoContadoFisicamente, Diferencia: $diferenciaCaja"
            )

            withContext(Dispatchers.Main) {
                _mensajeBanner.value = "Resumen del día sellado y PDF generado en: ${pdfGenerado.name}"
                onPdfListo(pdfGenerado, cierreDefinitivo)
                if (config.respaldoNocturnoCorreo) {
                    PdfAndExcelExporter.enviarRespaldoAlCorreoDueno(ctx, config, pdfGenerado)
                }
            }
        }
    }

    /**
     * Buscar por fecha: Carga las ventas, detalles y el cierre sellado de cualquier fecha seleccionada.
     */
    fun consultarHistorialPorFecha(
        fechaIso: String,
        onResultado: (CierreDiarioEntity?, List<VentaEntity>, List<DetalleVentaEntity>) -> Unit
    ) {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            val cierre = repository.obtenerCierrePorFechaSync(fechaIso)
            val ventas = repository.obtenerVentasPorFechaSync(fechaIso)
            val detalles = repository.obtenerDetallesPorFechaSync(fechaIso)
            withContext(Dispatchers.Main) {
                onResultado(cierre, ventas, detalles)
            }
        }
    }

    fun exportarOImprimirPdfDeFechaHistorica(
        fechaIso: String,
        imprimir: Boolean
    ) {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val config = repository.obtenerConfiguracionSync() ?: return@launch
            val ventas = repository.obtenerVentasPorFechaSync(fechaIso)
            val detalles = repository.obtenerDetallesPorFechaSync(fechaIso)
            val cierreGuardado = repository.obtenerCierrePorFechaSync(fechaIso)

            val cierreParaPdf = cierreGuardado ?: run {
                val Partes = fechaIso.split("-")
                val fechaMostrar = if (Partes.size == 3) "${Partes[2]}/${Partes[1]}/${Partes[0]}" else fechaIso
                val total = ventas.sumOf { it.total }
                val efec = ventas.filter { it.metodoPago.equals("Efectivo", true) }.sumOf { it.total }
                val transf = ventas.filter { it.metodoPago.equals("Transferencia", true) }.sumOf { it.total }
                val tarj = ventas.filter { it.metodoPago.equals("Tarjeta", true) }.sumOf { it.total }
                val cred = ventas.filter { it.metodoPago.contains("Cr", true) }.sumOf { it.total }
                CierreDiarioEntity(
                    fechaIso = fechaIso,
                    fechaMostrar = fechaMostrar,
                    vendedor = ventas.firstOrNull()?.vendedor ?: "Sin registro",
                    horaApertura = ventas.firstOrNull()?.hora ?: "--:--:--",
                    horaCierre = ventas.lastOrNull()?.hora ?: "--:--:--",
                    totalVendido = total,
                    impuestosTotales = ventas.sumOf { it.impuesto },
                    clientesAtendidos = ventas.size,
                    ticketPromedio = if (ventas.isNotEmpty()) total / ventas.size else 0.0,
                    totalEfectivo = efec,
                    totalTransferencia = transf,
                    totalTarjeta = tarj,
                    totalCredito = cred,
                    efectivoContado = efec,
                    diferenciaCaja = 0.0,
                    saldoFinal = total,
                    observaciones = "Consulta histórica por fecha",
                    productosVendidosResumen = "",
                    rutaPdf = "",
                    timestampSello = System.currentTimeMillis()
                )
            }

            val archivoPdf = if (cierreGuardado != null && cierreGuardado.rutaPdf.isNotBlank() && File(cierreGuardado.rutaPdf).exists()) {
                File(cierreGuardado.rutaPdf)
            } else {
                PdfAndExcelExporter.generarPdfResumenDelDia(ctx, config, cierreParaPdf, ventas, detalles)
            }

            _ultimoArchivoGenerado.value = archivoPdf
            withContext(Dispatchers.Main) {
                if (imprimir) {
                    PdfAndExcelExporter.imprimirArchivoPdf(ctx, archivoPdf, "Resumen Histórico $fechaIso")
                        .onFailure {
                            PdfAndExcelExporter.abrirOCompartirArchivo(ctx, archivoPdf, "application/pdf")
                        }
                } else {
                    _mensajeBanner.value = "PDF del día $fechaIso listo: ${archivoPdf.name}"
                    PdfAndExcelExporter.abrirOCompartirArchivo(ctx, archivoPdf, "application/pdf")
                }
            }
        }
    }

    fun exportarCatalogoAExcel() {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val pref = configuracionNegocio.value?.almacenamientoExportacion ?: "INTERNO"
            val prods = repository.obtenerTodosProductosSync()
            val file = PdfAndExcelExporter.exportarCatalogoAExcelPoi(ctx, prods, pref)
            _ultimoArchivoGenerado.value = file
            withContext(Dispatchers.Main) {
                _mensajeBanner.value = "Catálogo Excel (.xls) guardado en: ${file.absolutePath}"
                PdfAndExcelExporter.abrirOCompartirArchivo(ctx, file, "application/vnd.ms-excel")
            }
        }
    }

    fun exportarVentasAExcel() {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val pref = configuracionNegocio.value?.almacenamientoExportacion ?: "INTERNO"
            val ventas = repository.obtenerTodasVentasSync()
            val detalles = repository.obtenerTodosDetallesSync()
            val cierres = repository.obtenerTodoHistorialDiarioSync()
            val file = PdfAndExcelExporter.exportarVentasYHistorialAExcelPoi(ctx, ventas, detalles, cierres, pref)
            _ultimoArchivoGenerado.value = file
            withContext(Dispatchers.Main) {
                _mensajeBanner.value = "Reporte Excel (.xls) guardado en: ${file.absolutePath}"
                PdfAndExcelExporter.abrirOCompartirArchivo(ctx, file, "application/vnd.ms-excel")
            }
        }
    }

    fun ejecutarExportarTodoRespaldoCompleto() {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val config = repository.obtenerConfiguracionSync() ?: return@launch
            val prods = repository.obtenerTodosProductosSync()
            val hist = repository.obtenerHistoricoPreciosSync()
            val ventas = repository.obtenerTodasVentasSync()
            val detalles = repository.obtenerTodosDetallesSync()
            val cierres = repository.obtenerTodoHistorialDiarioSync()
            val cambios = repository.obtenerRegistroCambiosSync()

            val zipFile = PdfAndExcelExporter.exportarTodoRespaldoZip(
                ctx, config, prods, hist, ventas, detalles, cierres, cambios
            )
            _ultimoArchivoGenerado.value = zipFile
            registrarCambioAuditoria(
                tipo = "RESPALDO_TOTAL",
                codigo = "ZIP",
                detalle = "Respaldo completo exportado en ${zipFile.absolutePath}"
            )
            withContext(Dispatchers.Main) {
                _mensajeBanner.value = "Respaldo total (.zip) creado en: ${zipFile.absolutePath}"
                PdfAndExcelExporter.abrirOCompartirArchivo(ctx, zipFile, "application/zip")
            }
        }
    }

    fun actualizarConfiguracionAdmin(nuevaConfig: ConfiguracionNegocioEntity) {
        registrarActividadAdmin()
        viewModelScope.launch(Dispatchers.IO) {
            repository.guardarConfiguracion(nuevaConfig)
            withContext(Dispatchers.Main) {
                voiceSpeaker.aplicarIdioma(nuevaConfig.idiomaVozPais)
            }
            registrarCambioAuditoria(
                tipo = "CONFIGURACION",
                codigo = "AJUSTES",
                detalle = "Configuración actualizada (Negocio: ${nuevaConfig.nombreNegocio}, Moneda: ${nuevaConfig.monedaSimbolo}, Almacenamiento: ${nuevaConfig.almacenamientoExportacion})"
            )
            _mensajeBanner.value = "Configuración guardada correctamente."
        }
    }

    fun probarVozEnConfiguracion() {
        registrarActividadAdmin()
        val config = configuracionNegocio.value
        val frase = CurrencyAndVoiceFormatter.construirFraseTotalPorVoz(13.60, config)
        voiceSpeaker.hablarTexto(
            texto = frase,
            volumen = config?.volumenVoz ?: 1.0f,
            codigoIdioma = config?.idiomaVozPais ?: "es-MX"
        )
    }

    private suspend fun registrarCambioAuditoria(tipo: String, codigo: String, detalle: String) {
        repository.insertarRegistroCambio(
            RegistroCambioEntity(
                fecha = obtenerFechaMostrarActual(),
                hora = obtenerHoraExactaActual(),
                tipo = tipo,
                codigoProducto = codigo,
                detalle = detalle
            )
        )
    }

    override fun onCleared() {
        super.onCleared()
        voiceSpeaker.liberar()
    }

    companion object {
        fun obtenerFechaIsoActual(): String =
            SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        fun obtenerFechaMostrarActual(): String =
            SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date())

        fun obtenerHoraExactaActual(): String =
            SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    }
}
