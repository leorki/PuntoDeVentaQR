package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.security.EstadoVinculacionDispositivo
import com.example.security.LicenseSecurityManager
import com.example.security.ResultadoValidacionCodigo
import com.example.util.QrCodeBitmapGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `verificar nombre de la app en espanol`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Punto de Venta QR", appName)
    }

    @Test
    fun `verificar validacion asimetrica RSA2048 y vinculacion cifrada al dispositivo`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val codigoValido = LicenseSecurityManager.CODIGOS_DEMO_FIRMADOS.first().codigo
        val resultado = LicenseSecurityManager.validarCodigoActivacion(codigoValido, "2026-10-11")
        assertTrue(resultado is ResultadoValidacionCodigo.Valido)

        val valido = resultado as ResultadoValidacionCodigo.Valido
        assertEquals("LIC-00001", valido.idLicencia)

        val entidadCifrada = LicenseSecurityManager.crearEntidadLicenciaCifrada(context, valido)
        val estadoArranque = LicenseSecurityManager.verificarVinculacionAlArrancar(context, entidadCifrada)
        assertTrue(estadoArranque is EstadoVinculacionDispositivo.ActivadoValido)

        // Verificar que un código vencido sea rechazado
        val resVencido = LicenseSecurityManager.validarCodigoActivacion(
            LicenseSecurityManager.CODIGO_DEMO_VENCIDO,
            "2026-10-11"
        )
        assertTrue(resVencido is ResultadoValidacionCodigo.Invalido)
    }

    @Test
    fun `verificar generacion de etiqueta QR solo con codigo`() {
        val bmp = QrCodeBitmapGenerator.generarQrSoloCodigo("P001", 200)
        assertNotNull(bmp)
        assertEquals(200, bmp.width)
        assertEquals(200, bmp.height)
    }
}
