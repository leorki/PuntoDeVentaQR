package com.example

import com.example.data.local.ConfiguracionNegocioEntity
import com.example.util.CurrencyAndVoiceFormatter
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `verificar lista exacta de 6 monedas y sus formatos decimales`() {
        val monedas = CurrencyAndVoiceFormatter.MONEDAS_PREDEFINIDAS
        assertEquals(6, monedas.size)
        assertEquals(listOf("CUP", "USD", "CAD", "MXN", "EUR", "GBP"), monedas.map { it.codigo })

        fun crearConfigMoneda(codigo: String): ConfiguracionNegocioEntity {
            val preset = monedas.first { it.codigo == codigo }
            return ConfiguracionNegocioEntity(
                nombreNegocio = "Mi Tienda",
                nombreDueno = "Dueño",
                direccion = "Calle 1",
                telefono = "123",
                correo = "a@b.com",
                monedaCodigo = preset.codigo,
                monedaSimbolo = preset.simbolo,
                simboloAntes = preset.simboloAntes,
                separadorMiles = preset.separadorMiles,
                separadorDecimales = preset.separadorDecimales,
                monedaVozSingular = preset.vozSingular,
                monedaVozPlural = preset.vozPlural,
                centavosVoz = preset.centavosVoz,
                aplicaImpuesto = false,
                porcentajeImpuesto = 0.0,
                rutaLogoInterno = null,
                hashPasswordAdmin = "",
                saltPassword = "",
                preguntaSeguridad = "",
                hashRespuestaSeguridad = "",
                hashCodigoMaestro = "",
                idiomaVozPais = "es-ES"
            )
        }

        // 1. Peso Cubano (CUP): $1,234.56
        assertEquals("$1,234.56", CurrencyAndVoiceFormatter.formatearMoneda(1234.56, crearConfigMoneda("CUP")))
        // 2. Dólar Americano (USD): $1,234.56
        assertEquals("$1,234.56", CurrencyAndVoiceFormatter.formatearMoneda(1234.56, crearConfigMoneda("USD")))
        // 3. Dólar Canadiense (CAD): C$1,234.56
        assertEquals("C$1,234.56", CurrencyAndVoiceFormatter.formatearMoneda(1234.56, crearConfigMoneda("CAD")))
        // 4. Peso Mexicano (MXN): $1,234.56
        assertEquals("$1,234.56", CurrencyAndVoiceFormatter.formatearMoneda(1234.56, crearConfigMoneda("MXN")))
        // 5. Euro (EUR): 1.234,56 €
        assertEquals("1.234,56 €", CurrencyAndVoiceFormatter.formatearMoneda(1234.56, crearConfigMoneda("EUR")))
        // 6. Libra Esterlina (GBP): £1,234.56
        assertEquals("£1,234.56", CurrencyAndVoiceFormatter.formatearMoneda(1234.56, crearConfigMoneda("GBP")))
    }

    @Test
    fun `verificar conversion de total a voz en espanol`() {
        val frase = CurrencyAndVoiceFormatter.construirFraseTotalPorVoz(13.60, null)
        assertEquals("Total a pagar: trece dólares con sesenta centavos", frase)
    }
}
